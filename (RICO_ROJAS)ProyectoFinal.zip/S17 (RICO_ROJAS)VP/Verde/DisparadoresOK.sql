/*============================================================
DISPARADORES_OK
============================================================ */

---------------------------------------------------------------
-- OK 1: trg_incidente_fecha
-- Si no se envía FechaIncidente, el trigger asigna SYSDATE.
---------------------------------------------------------------
INSERT INTO Incidente (
  IncidenteID, CodigoIncidente, Descripcion, Severidad, Estado, DelitoID, UbicacionID
) VALUES (
  990, 'I990',
  'Incidente sin fecha explícita',
  'Media', 'Abierto',
  1, 1
);

-- Verificar que la FechaIncidente fue asignada
SELECT IncidenteID, FechaIncidente
FROM Incidente
WHERE IncidenteID = 990;



---------------------------------------------------------------
-- OK 2: trg_incidente_estado_default
-- Si no se envía Estado, el trigger asigna 'Abierto'.
---------------------------------------------------------------
INSERT INTO Incidente (
  IncidenteID, CodigoIncidente, FechaIncidente, Descripcion, Severidad, DelitoID, UbicacionID
) VALUES (
  991, 'I991',
  DATE '2025-11-20',
  'Incidente sin estado explícito',
  'Media',
  1, 1
);

-- Verificar que el Estado fue asignado como 'Abierto'
SELECT IncidenteID, Estado
FROM Incidente
WHERE IncidenteID = 991;



---------------------------------------------------------------
-- OK 3: trg_denuncia_fecha_valida
-- FechaDenuncia >= FechaIncidente → válido.
---------------------------------------------------------------

-- Primero aseguramos un incidente válido
INSERT INTO Incidente VALUES (
  992, 'I992',
  DATE '2025-11-01',
  'Incidente base para denuncia válida',
  'Alta', 'En proceso',
  1, 1
);

-- Insertar denuncia con fecha correcta (posterior a FechaIncidente)
INSERT INTO Denuncia VALUES (
  993, 'DN993',
  DATE '2025-11-02',  -- posterior al incidente
  'Denuncia válida',
  1,                 -- CiudadanoID (ya existente)
  1,                 -- AutoridadID (ya existente)
  992                -- IncidenteID
);

-- Verificar que se insertó correctamente
SELECT DenunciaID, FechaDenuncia
FROM Denuncia
WHERE DenunciaID = 993;

COMMIT;
