/*============================================================
POBLAROK
============================================================ */


-- DELITOS
INSERT INTO Delito VALUES (1, 'D001', 'Robo', 'Hurto de pertenencias', 'Hurto', 'Alta');
INSERT INTO Delito VALUES (2, 'D002', 'Lesiones', 'Agresión física', 'Violencia', 'Media');
INSERT INTO Delito VALUES (3, 'D003', 'Homicidio', 'Muerte intencional', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (4,  'D004', 'Extorsión', 'Cobro de dinero mediante amenaza', 'Delitos económicos', 'Alta');
INSERT INTO Delito VALUES (5,  'D005', 'Fraude bancario', 'Acceso indebido a cuentas', 'Delitos económicos', 'Media');
INSERT INTO Delito VALUES (6,  'D006', 'Vandalismo', 'Daño a bienes públicos', 'Daño a la propiedad', 'Media');
INSERT INTO Delito VALUES (7,  'D007', 'Amenazas', 'Intimidación verbal o escrita', 'Violencia', 'Baja');
INSERT INTO Delito VALUES (8,  'D008', 'Hurto de vehículo', 'Robo de automóvil o motocicleta', 'Hurto', 'Alta');
INSERT INTO Delito VALUES (9,  'D009', 'Secuestro', 'Privación ilegal de la libertad', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (10, 'D010', 'Estafa', 'Engaño para obtener beneficio económico', 'Delitos económicos', 'Media');
INSERT INTO Delito VALUES (11, 'D011', 'Acoso', 'Hostigamiento reiterado', 'Violencia', 'Media');
INSERT INTO Delito VALUES (12, 'D012', 'Abuso de confianza', 'Apropiación indebida de bienes', 'Hurto', 'Media');
INSERT INTO Delito VALUES (13, 'D013', 'Incendio', 'Provocar fuego intencional', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (14, 'D014', 'Contrabando', 'Ingreso ilegal de mercancía', 'Delitos económicos', 'Media');
INSERT INTO Delito VALUES (15, 'D015', 'Violencia intrafamiliar', 'Agresión en entorno familiar', 'Violencia', 'Alta');
INSERT INTO Delito VALUES (16, 'D016', 'Lesiones culposas', 'Daño físico por imprudencia', 'Violencia', 'Baja');
INSERT INTO Delito VALUES (17, 'D017', 'Robo a establecimiento', 'Hurto en negocio comercial', 'Hurto', 'Alta');
INSERT INTO Delito VALUES (18, 'D018', 'Daño en propiedad privada', 'Afectación a bienes de terceros', 'Daño a la propiedad', 'Media');
INSERT INTO Delito VALUES (19, 'D019', 'Falsificación documental', 'Crear documentos falsos', 'Delitos económicos', 'Media');
INSERT INTO Delito VALUES (20, 'D020', 'Lavado de activos', 'Dinero de origen ilícito', 'Delitos económicos', 'Alta');
INSERT INTO Delito VALUES (21, 'D021', 'Tráfico de drogas', 'Distribución de sustancias ilegales', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (22, 'D022', 'Consumo de drogas', 'Consumo en espacio público', 'Crimen', 'Baja');
INSERT INTO Delito VALUES (23, 'D023', 'Porte ilegal de armas', 'Portar armas sin permiso', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (24, 'D024', 'Hurtos menores', 'Pequeños robos sin violencia', 'Hurto', 'Baja');
INSERT INTO Delito VALUES (25, 'D025', 'Ciberacoso', 'Hostigamiento digital', 'Violencia', 'Media');
INSERT INTO Delito VALUES (26, 'D026', 'Ciberfraude', 'Estafas por internet', 'Delitos económicos', 'Alta');
INSERT INTO Delito VALUES (27, 'D027', 'Estafa telefónica', 'Engaño vía llamada', 'Delitos económicos', 'Media');
INSERT INTO Delito VALUES (28, 'D028', 'Corrupción', 'Abuso de poder para beneficio', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (29, 'D029', 'Soborno', 'Ofrecer dinero por favores ilegales', 'Delitos económicos', 'Alta');
INSERT INTO Delito VALUES (30, 'D030', 'Lesiones con arma blanca', 'Agresión con objeto cortante', 'Violencia', 'Alta');
INSERT INTO Delito VALUES (31, 'D031', 'Lesiones con arma de fuego', 'Agresión con arma', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (32, 'D032', 'Hurto a vivienda', 'Robo en propiedad residencial', 'Hurto', 'Alta');
INSERT INTO Delito VALUES (33, 'D033', 'Delitos informáticos', 'Acceso no autorizado a sistemas', 'Delitos económicos', 'Media');
INSERT INTO Delito VALUES (34, 'D034', 'Usurpación de identidad', 'Uso ilegal de datos de otro', 'Delitos económicos', 'Media');
INSERT INTO Delito VALUES (35, 'D035', 'Violación de domicilio', 'Entrar a vivienda sin permiso', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (36, 'D036', 'Riña callejera', 'Pelea en espacio público', 'Violencia', 'Media');
INSERT INTO Delito VALUES (37, 'D037', 'Exhibicionismo', 'Actos sexuales en público', 'Crimen', 'Baja');
INSERT INTO Delito VALUES (38, 'D038', 'Actos obscenos', 'Conductas sexualmente inapropiadas', 'Crimen', 'Media');
INSERT INTO Delito VALUES (39, 'D039', 'Abandono de menor', 'Dejar sin cuidado a un niño', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (40, 'D040', 'Explotación infantil', 'Trabajo o abuso de niños', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (41, 'D041', 'Violencia psicológica', 'Afectación emocional severa', 'Violencia', 'Media');
INSERT INTO Delito VALUES (42, 'D042', 'Persecución', 'Seguimiento hostigante', 'Violencia', 'Media');
INSERT INTO Delito VALUES (43, 'D043', 'Abuso sexual', 'Afectación sexual sin consentimiento', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (44, 'D044', 'Proxenetismo', 'Explotación sexual ajena', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (45, 'D045', 'Alteración del orden público', 'Interrupción de convivencia', 'Violencia', 'Baja');
INSERT INTO Delito VALUES (46, 'D046', 'Contaminación ambiental', 'Afectar ilegalmente el medio ambiente', 'Crimen', 'Media');
INSERT INTO Delito VALUES (47, 'D047', 'Cohecho', 'Delito contra la administración pública', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (48, 'D048', 'Interferencia en transporte', 'Bloquear vías o transporte', 'Daño a la propiedad', 'Media');
INSERT INTO Delito VALUES (49, 'D049', 'Hurtos en transporte público', 'Robo a pasajeros', 'Hurto', 'Alta');
INSERT INTO Delito VALUES (50, 'D050', 'Robo con intimidación', 'Hurto con amenaza', 'Hurto', 'Alta');
INSERT INTO Delito VALUES (51, 'D051', 'Extorsión digital', 'Amenazas mediante redes', 'Delitos económicos', 'Alta');
INSERT INTO Delito VALUES (52, 'D052', 'Estafa empresarial', 'Fraude a compañías', 'Delitos económicos', 'Alta');
INSERT INTO Delito VALUES (53, 'D053', 'Hurto de bicicleta', 'Robo de bicicleta', 'Hurto', 'Media');

-- UBICACIONES
INSERT INTO Ubicacion VALUES (1, 'U001', 'Calle 10 #5-20', 'Centro', 'Usaquén', '4.676', '-74.045');
INSERT INTO Ubicacion VALUES (2, 'U002', 'Cra 15 #90-40', 'Chicó', 'Chapinero', '4.673', '-74.055');
INSERT INTO Ubicacion VALUES (3, 'U003', 'Av. Boyacá #45-12', 'Kennedy Central', 'Kennedy', '4.612', '-74.165');
INSERT INTO Ubicacion VALUES (4,  'U004', 'Cll 72 #13-50',      'Zona Financiera', 'Barrios Unidos', '4.658', '-74.062');
INSERT INTO Ubicacion VALUES (5,  'U005', 'Cll 26 #68-80',      'Aeropuerto',      'Fontibón',       '4.701', '-74.146');
INSERT INTO Ubicacion VALUES (6,  'U006', 'Cra 30 #45-20',      'Universitaria',   'Teusaquillo',    '4.642', '-74.083');
INSERT INTO Ubicacion VALUES (7,  'U007', 'Cll 53 Sur #80-15',  'Bosa La Libertad','Bosa',           '4.603', '-74.191');
INSERT INTO Ubicacion VALUES (8,  'U008', 'Av. Ciudad de Cali', 'Centro Comercial','Suba',           '4.736', '-74.093');
INSERT INTO Ubicacion VALUES (9,  'U009', 'Cll 100 #19-30',     'Santa Bibiana',   'Usaquén',        '4.682', '-74.048');
INSERT INTO Ubicacion VALUES (10, 'U010', 'Cll 134 #45-18',     'Niza',            'Suba',           '4.721', '-74.077');
INSERT INTO Ubicacion VALUES (11, 'U011', 'Cll 45 #20-10',      'La Soledad',      'Teusaquillo',    '4.642', '-74.072');
INSERT INTO Ubicacion VALUES (12, 'U012', 'Cra 7 #116-40',      'Usaquén Centro',  'Usaquén',        '4.694', '-74.033');
INSERT INTO Ubicacion VALUES (13, 'U013', 'Cll 19 #4-20',       'San Victorino',   'Santa Fe',       '4.605', '-74.075');
INSERT INTO Ubicacion VALUES (14, 'U014', 'Av. 1 de Mayo #70',  'Carvajal',        'Kennedy',        '4.617', '-74.157');
INSERT INTO Ubicacion VALUES (15, 'U015', 'Cll 80 #90-12',      'Robledo',         'Engativá',       '4.719', '-74.114');
INSERT INTO Ubicacion VALUES (16, 'U016', 'Cra 50 #22-20',      'Zona Industrial', 'Puente Aranda',  '4.620', '-74.096');
INSERT INTO Ubicacion VALUES (17, 'U017', 'Cll 40 Sur #10-58',  'Restrepo',        'Antonio Nariño', '4.580', '-74.107');
INSERT INTO Ubicacion VALUES (18, 'U018', 'Cll 170 #70-25',     'Tierra Buena',    'Suba',           '4.764', '-74.102');
INSERT INTO Ubicacion VALUES (19, 'U019', 'Cll 6 #30',          'Zona Centro',     'Santa Fe',       '4.596', '-74.078');
INSERT INTO Ubicacion VALUES (20, 'U020', 'Cra 24 #48-30',      'Campín',          'Teusaquillo',    '4.648', '-74.082');
INSERT INTO Ubicacion VALUES (21, 'U021', 'Cll 52 #30-15',      'Galerías',        'Teusaquillo',    '4.641', '-74.074');
INSERT INTO Ubicacion VALUES (22, 'U022', 'Cra 68 #21-55',      'Salitre',         'Fontibón',       '4.647', '-74.123');
INSERT INTO Ubicacion VALUES (23, 'U023', 'Cll 17 Sur #32-51',  'Ciudad Montes',   'Puente Aranda',  '4.597', '-74.120');
INSERT INTO Ubicacion VALUES (24, 'U024', 'Cll 86 #12-20',      'El Retiro',       'Chapinero',      '4.669', '-74.052');
INSERT INTO Ubicacion VALUES (25, 'U025', 'Cll 94 #14-45',      'Parque de la 93', 'Chapinero',      '4.676', '-74.052');
INSERT INTO Ubicacion VALUES (26, 'U026', 'Cll 57 #27-14',      'Las Torres',      'Teusaquillo',    '4.638', '-74.075');
INSERT INTO Ubicacion VALUES (27, 'U027', 'Cll 170 #24-40',     'Tibabuyes',       'Suba',           '4.756', '-74.093');
INSERT INTO Ubicacion VALUES (28, 'U028', 'Cll 138 #55-50',     'Colina Campestre','Suba',           '4.730', '-74.076');
INSERT INTO Ubicacion VALUES (29, 'U029', 'Cra 10 #14-40',      'San Bernardo',    'Santa Fe',       '4.597', '-74.078');
INSERT INTO Ubicacion VALUES (30, 'U030', 'Cll 152 #45-20',     'Mazurén',         'Suba',           '4.738', '-74.067');
INSERT INTO Ubicacion VALUES (31, 'U031', 'Cll 22 #68-20',      'Normandía',       'Engativá',       '4.676', '-74.111');
INSERT INTO Ubicacion VALUES (32, 'U032', 'Cll 145 #16-20',     'Cedritos',        'Usaquén',        '4.722', '-74.048');
INSERT INTO Ubicacion VALUES (33, 'U033', 'Cll 100 #50-20',     'La Castellana',   'Suba',           '4.698', '-74.070');
INSERT INTO Ubicacion VALUES (34, 'U034', 'Cra 73 #62-20',      'Garces Navas',    'Engativá',       '4.689', '-74.107');
INSERT INTO Ubicacion VALUES (35, 'U035', 'Cll 44 #22-70',      'La Esmeralda',    'Teusaquillo',    '4.645', '-74.078');
INSERT INTO Ubicacion VALUES (36, 'U036', 'Cra 50 #2-60',       'Villa Mayor',     'Antonio Nariño', '4.586', '-74.116');
INSERT INTO Ubicacion VALUES (37, 'U037', 'Cll 27 #18-40',      'Santa Isabel',    'Antonio Nariño', '4.600', '-74.110');
INSERT INTO Ubicacion VALUES (38, 'U038', 'Cll 165 #80-30',     'Pinar',           'Suba',           '4.755', '-74.096');
INSERT INTO Ubicacion VALUES (39, 'U039', 'Cra 54 #24-50',      'Modelia',         'Fontibón',       '4.662', '-74.118');
INSERT INTO Ubicacion VALUES (40, 'U040', 'Cll 80 #71-30',      'Minuto de Dios',  'Engativá',       '4.705', '-74.112');
INSERT INTO Ubicacion VALUES (41, 'U041', 'Cll 2 #20-30',       'San Cristóbal',   'San Cristóbal',  '4.567', '-74.090');
INSERT INTO Ubicacion VALUES (42, 'U042', 'Cll 5 Sur #30-15',   'Quiroga',         'Rafael Uribe',   '4.578', '-74.116');
INSERT INTO Ubicacion VALUES (43, 'U043', 'Cll 45 Sur #5-30',   'Molinos',         'Ciudad Bolívar', '4.566', '-74.135');
INSERT INTO Ubicacion VALUES (44, 'U044', 'Cra 18 #145-20',     'Cedro Golf',      'Usaquén',        '4.732', '-74.047');
INSERT INTO Ubicacion VALUES (45, 'U045', 'Cll 51 #13-20',      'Chapinero Alto',  'Chapinero',      '4.648', '-74.062');
INSERT INTO Ubicacion VALUES (46, 'U046', 'Cll 16 #34-30',      'Ciudad Salitre',  'Fontibón',       '4.660', '-74.108');
INSERT INTO Ubicacion VALUES (47, 'U047', 'Cll 72 #20-40',      'Siete de Agosto', 'Barrios Unidos', '4.661', '-74.072');
INSERT INTO Ubicacion VALUES (48, 'U048', 'Cll 170 #52-15',     'La Campiña',      'Suba',           '4.761', '-74.077');
INSERT INTO Ubicacion VALUES (49, 'U049', 'Cll 106 #15-30',     'Santa Bárbara',   'Usaquén',        '4.691', '-74.044');
INSERT INTO Ubicacion VALUES (50, 'U050', 'Cra 59 #22-50',      'Ricaurte',        'Los Mártires',   '4.609', '-74.092');

-- INCIDENTES
INSERT INTO Incidente VALUES (1, 'I001', DATE '2025-01-15', 'Robo de celular', 'Alta', 'Cerrado', 1, 1);
INSERT INTO Incidente VALUES (2, 'I002', DATE '2025-02-10', 'Agresión en parque', 'Media', 'En proceso', 2, 2);
INSERT INTO Incidente VALUES (3, 'I003', DATE '2025-03-20', 'Homicidio con arma blanca', 'Alta', 'Cerrado', 3, 3);
INSERT INTO Incidente VALUES (4, 'I004', DATE '2025-04-05', 'Robo en bus', 'Alta', 'Abierto', 1, 2);
INSERT INTO Incidente VALUES (5, 'I005', DATE '2025-05-18', 'Lesiones leves en vía pública', 'Media', 'Cerrado', 2, 1);
INSERT INTO Incidente VALUES (6,  'I006', DATE '2025-05-20', 'Robo de bicicleta en parque',         'Media', 'Abierto',      1, 2);
INSERT INTO Incidente VALUES (7,  'I007', DATE '2025-06-01', 'Lesiones en riña callejera',          'Alta',  'En proceso',   2, 3);
INSERT INTO Incidente VALUES (8,  'I008', DATE '2025-06-10', 'Intento de hurto de bolso',           'Baja',  'Cerrado',      1, 1);
INSERT INTO Incidente VALUES (9,  'I009', DATE '2025-06-22', 'Homicidio en vía pública',            'Alta',  'Abierto',      3, 3);
INSERT INTO Incidente VALUES (10, 'I010', DATE '2025-07-03', 'Agresión en estación de bus',         'Media', 'En proceso',   2, 2);
INSERT INTO Incidente VALUES (11, 'I011', DATE '2025-07-15', 'Robo de cartera a transeúnte',        'Alta',  'Cerrado',      1, 1);
INSERT INTO Incidente VALUES (12, 'I012', DATE '2025-07-28', 'Lesiones leves en barrio residencial','Baja',  'Abierto',      2, 3);
INSERT INTO Incidente VALUES (13, 'I013', DATE '2025-08-05', 'Robo de celular en transporte público','Alta', 'En proceso',   1, 2);
INSERT INTO Incidente VALUES (14, 'I014', DATE '2025-08-16', 'Homicidio con arma de fuego',         'Alta',  'Cerrado',      3, 3);
INSERT INTO Incidente VALUES (15, 'I015', DATE '2025-08-25', 'Agresión en establecimiento comercial','Media','Abierto',      2, 1);
INSERT INTO Incidente VALUES (16, 'I016', DATE '2025-09-02', 'Hurto de pertenencias en parque',     'Baja',  'Cerrado',      1, 2);
INSERT INTO Incidente VALUES (17, 'I017', DATE '2025-09-10', 'Lesiones en fiesta barrial',          'Media', 'En proceso',   2, 3);
INSERT INTO Incidente VALUES (18, 'I018', DATE '2025-09-18', 'Intento de homicidio con arma blanca','Alta',  'Abierto',      3, 1);
INSERT INTO Incidente VALUES (19, 'I019', DATE '2025-09-27', 'Robo masivo en bus urbano',           'Alta',  'En proceso',   1, 2);
INSERT INTO Incidente VALUES (20, 'I020', DATE '2025-10-04', 'Lesiones leves en colegio',           'Baja',  'Cerrado',      2, 1);
INSERT INTO Incidente VALUES (21, 'I021', DATE '2025-10-12', 'Homicidio en zona comercial',         'Alta',  'Abierto',      3, 3);
INSERT INTO Incidente VALUES (22, 'I022', DATE '2025-10-19', 'Hurto de bolso en zona céntrica',     'Media', 'Cerrado',      1, 1);
INSERT INTO Incidente VALUES (23, 'I023', DATE '2025-10-27', 'Agresión física en bar nocturno',     'Alta',  'En proceso',   2, 2);
INSERT INTO Incidente VALUES (24, 'I024', DATE '2025-11-03', 'Robo de reloj en vía principal',      'Media', 'Abierto',      1, 3);
INSERT INTO Incidente VALUES (25, 'I025', DATE '2025-11-11', 'Homicidio en zona residencial',       'Alta',  'Cerrado',      3, 2);

-- CIUDADANOS
INSERT INTO Ciudadano VALUES (1, 'CC10000001', 'Juan', 'Pérez', '3001111111', 'juan@mail.com', 'Calle 10 #5-20');
INSERT INTO Ciudadano VALUES (2, 'CC10000002', 'María', 'Gómez', '3002222222', 'maria@mail.com', 'Cra 15 #90-40');
INSERT INTO Ciudadano VALUES (3, 'CC10000003', 'Carlos', 'Rojas', '3003333333', 'carlos@mail.com', 'Av. Boyacá #45-12');
INSERT INTO Ciudadano VALUES (4, 'CC10000004', 'Ana', 'Ramírez', '3004444444', 'ana@mail.com', 'Cll 72 #13-50');
INSERT INTO Ciudadano VALUES (5, 'CC10000005', 'Laura', 'Martínez', '3005555555', 'laura@mail.com', 'Cll 26 #68-80');
INSERT INTO Ciudadano VALUES (6, 'CC10000006', 'Pedro', 'Correa', '3006666666', 'pedro@mail.com', 'Cra 30 #45-20');
INSERT INTO Ciudadano VALUES (7, 'CC10000007', 'Andrés', 'Mora', '3007777777', 'andres@mail.com', 'Cll 53 Sur #80-15');
INSERT INTO Ciudadano VALUES (8, 'CC10000008', 'Julia', 'Nieto', '3008888888', 'julia@mail.com', 'Av. Ciudad de Cali');
INSERT INTO Ciudadano VALUES (9, 'CC10000009', 'Sofía', 'Rincón', '3009999999', 'sofia@mail.com', 'Cll 100 #19-30');
INSERT INTO Ciudadano VALUES (10, 'CC10000010', 'Miguel', 'Lozano', '3001234567', 'miguel@mail.com', 'Cll 134 #45-18');

-- SOSPECHOSOS
INSERT INTO Sospechoso VALUES (1, 'SC90000001', 'El Toro', 'Javier', 'López', 'Antecedentes por hurto');
INSERT INTO Sospechoso VALUES (2, 'SC90000002', 'La Sombra', 'Felipe', 'García', 'Movimientos nocturnos');
INSERT INTO Sospechoso VALUES (3, 'SC90000003', 'Rayo', 'Daniel', 'Contreras', 'Conocido por vandalismo');
INSERT INTO Sospechoso VALUES (4, 'SC90000004', 'El Zurdo', 'Camilo', 'Mejía', 'Sospechoso habitual');
INSERT INTO Sospechoso VALUES (5, 'SC90000005', 'Mono', 'Ricardo', 'Uribe', 'Reporte de amenazas');
INSERT INTO Sospechoso VALUES (6, 'SC90000006', 'Flecha', 'Oscar', 'Vega', 'Relacionado con robo callejero');
INSERT INTO Sospechoso VALUES (7, 'SC90000007', 'Chino', 'Mateo', 'Fuentes', 'Historial de riñas');
INSERT INTO Sospechoso VALUES (8, 'SC90000008', 'Negro', 'Héctor', 'Pérez', 'Investigado por extorsión');
INSERT INTO Sospechoso VALUES (9, 'SC90000009', 'Gato', 'Manuel', 'Rico', 'Se esconde en zonas residenciales');
INSERT INTO Sospechoso VALUES (10, 'SC90000010', 'Topo', 'Esteban', 'Céspedes', 'Conocido por robos en buses');

-- AUTORIDADES
INSERT INTO Autoridad VALUES (1, 'A001', 'Policía Metropolitana', 'Policía', '3101111111', 'pm001@policia.gov');
INSERT INTO Autoridad VALUES (2, 'A002', 'SIJIN Bogotá', 'Investigación', '3102222222', 'sijin@policia.gov');
INSERT INTO Autoridad VALUES (3, 'A003', 'Fiscalía Local 12', 'Fiscalía', '3103333333', 'f12@fiscalia.gov');
INSERT INTO Autoridad VALUES (4, 'A004', 'CTI Bogotá', 'Investigación', '3104444444', 'cti@fiscalia.gov');
INSERT INTO Autoridad VALUES (5, 'A005', 'Secretaría de Seguridad', 'Administrativo', '3105555555', 'seguridad@bogota.gov');
INSERT INTO Autoridad VALUES (6, 'A006', 'Policía Ambiental', 'Policía', '3106666666', 'ambiental@policia.gov');
INSERT INTO Autoridad VALUES (7, 'A007', 'Policía de Tránsito', 'Tránsito', '3107777777', 'transito@policia.gov');
INSERT INTO Autoridad VALUES (8, 'A008', 'Migración Colombia', 'Control', '3108888888', 'migracion@colombia.gov');
INSERT INTO Autoridad VALUES (9, 'A009', 'Gaula', 'Antiextorsión', '3109999999', 'gaula@policia.gov');
INSERT INTO Autoridad VALUES (10, 'A010', 'Policía Judicial', 'Investigación', '3101234567', 'judicial@policia.gov');

-- UNIDADES POLICIALES
INSERT INTO UnidadPolicial VALUES (1, 'UP01', 'Estación Usaquén', 'Calle 120 #5-20', 1);
INSERT INTO UnidadPolicial VALUES (2, 'UP02', 'Estación Chapinero', 'Cra 13 #60-40', 2);
INSERT INTO UnidadPolicial VALUES (3, 'UP03', 'Estación Kennedy', 'Av 1 de Mayo #70-15', 1);
INSERT INTO UnidadPolicial VALUES (4, 'UP04', 'Estación Suba', 'Cll 145 #98-45', 3);
INSERT INTO UnidadPolicial VALUES (5, 'UP05', 'Estación Teusaquillo', 'Calle 45 #20-20', 4);
INSERT INTO UnidadPolicial VALUES (6, 'UP06', 'Estación Engativá', 'Cll 80 #90-40', 1);
INSERT INTO UnidadPolicial VALUES (7, 'UP07', 'Estación Fontibón', 'Cll 26 #65-30', 5);
INSERT INTO UnidadPolicial VALUES (8, 'UP08', 'Estación Barrios Unidos', 'Cll 72 #15-40', 6);
INSERT INTO UnidadPolicial VALUES (9, 'UP09', 'Estación Los Mártires', 'Cll 10 #15-80', 7);
INSERT INTO UnidadPolicial VALUES (10, 'UP10', 'Estación Bosa', 'Cll 57 Sur #80-15', 8);

-- ACTUACIONES
INSERT INTO Actuacion VALUES (1, 'Registro del incidente', DATE '2025-01-15', 'Se toma reporte inicial', 1, 1);
INSERT INTO Actuacion VALUES (2, 'Inspección del lugar', DATE '2025-01-15', 'Patrulla verifica zona', 1, 1);
INSERT INTO Actuacion VALUES (3, 'Entrevista a ciudadanos', DATE '2025-02-10', 'Se recopilan testimonios', 2, 2);
INSERT INTO Actuacion VALUES (4, 'Captura del sospechoso', DATE '2025-03-20', 'Detención realizada', 3, 3);
INSERT INTO Actuacion VALUES (5, 'Revisión de cámaras', DATE '2025-04-05', 'Cámaras evidencian hurto', 1, 4);
INSERT INTO Actuacion VALUES (6, 'Patrullaje reforzado', DATE '2025-05-20', 'Zona con vigilancia', 1, 6);
INSERT INTO Actuacion VALUES (7, 'Información a Fiscalía', DATE '2025-06-10', 'Caso remitido', 3, 8);
INSERT INTO Actuacion VALUES (8, 'Seguimiento a víctima', DATE '2025-06-22', 'Acompañamiento psicológico', 5, 9);
INSERT INTO Actuacion VALUES (9, 'Verificación de pruebas', DATE '2025-07-03', 'Evidencias analizadas', 3, 10);
INSERT INTO Actuacion VALUES (10, 'Reporte final', DATE '2025-07-15', 'Informe completo entregado', 2, 11);
INSERT INTO Actuacion VALUES (11, 'Llamado de atención', DATE '2025-07-20', 'Advertencia preventiva', 1, 12);
INSERT INTO Actuacion VALUES (12, 'Investigación ampliada', DATE '2025-08-10', 'Profundización del caso', 4, 14);
INSERT INTO Actuacion VALUES (13, 'Control de área', DATE '2025-09-05', 'Zona acordonada', 1, 15);
INSERT INTO Actuacion VALUES (14, 'Ingreso de denuncia', DATE '2025-09-18', 'Ciudadano formaliza queja', 3, 18);
INSERT INTO Actuacion VALUES (15, 'Entrega de evidencia', DATE '2025-09-27', 'Se registra nueva prueba', 5, 19);
INSERT INTO Actuacion VALUES (16, 'Captura del responsable', DATE '2025-10-12', 'Operativo exitoso', 9, 21);
INSERT INTO Actuacion VALUES (17, 'Control preventivo', DATE '2025-10-27', 'Verificación rutinaria', 7, 23);
INSERT INTO Actuacion VALUES (18, 'Cierre del caso', DATE '2025-11-03', 'Caso archivado', 3, 24);
INSERT INTO Actuacion VALUES (19, 'Investigación adicional', DATE '2025-11-11', 'Nueva evidencia encontrada', 1, 25);
INSERT INTO Actuacion VALUES (20, 'Entrega a Fiscalía', DATE '2025-11-20', 'Caso remitido oficialmente', 2, 20);

-- DENUNCIAS
INSERT INTO Denuncia VALUES (1, 'DN001', DATE '2025-01-15', 'Denuncia inicial por hurto', 1, 1, 1);
INSERT INTO Denuncia VALUES (2, 'DN002', DATE '2025-02-10', 'Denuncia por agresión', 2, 2, 2);
INSERT INTO Denuncia VALUES (3, 'DN003', DATE '2025-03-20', 'Denuncia por homicidio', 3, 3, 3);
INSERT INTO Denuncia VALUES (4, 'DN004', DATE '2025-04-05', 'Robo en bus denunciado', 4, 1, 4);
INSERT INTO Denuncia VALUES (5, 'DN005', DATE '2025-05-18', 'Lesiones leves denunciadas', 5, 2, 5);
INSERT INTO Denuncia VALUES (6, 'DN006', DATE '2025-06-01', 'Robo de bicicleta', 6, 1, 6);
INSERT INTO Denuncia VALUES (7, 'DN007', DATE '2025-06-10', 'Agresión en vía pública', 7, 2, 7);
INSERT INTO Denuncia VALUES (8, 'DN008', DATE '2025-06-22', 'Homicidio en la noche', 8, 3, 9);
INSERT INTO Denuncia VALUES (9, 'DN009', DATE '2025-07-03', 'Hurto en comercio', 9, 1, 10);
INSERT INTO Denuncia VALUES (10, 'DN010', DATE '2025-07-15', 'Lesiones en barrio', 10, 2, 12);
INSERT INTO Denuncia VALUES (11, 'DN011', DATE '2025-08-05', 'Robo de celular', 11, 1, 13);
INSERT INTO Denuncia VALUES (12, 'DN012', DATE '2025-08-25', 'Agresión física', 12, 2, 15);
INSERT INTO Denuncia VALUES (13, 'DN013', DATE '2025-09-10', 'Intento de homicidio', 13, 3, 18);
INSERT INTO Denuncia VALUES (14, 'DN014', DATE '2025-09-27', 'Robo masivo en bus', 14, 1, 19);
INSERT INTO Denuncia VALUES (15, 'DN015', DATE '2025-10-12', 'Homicidio confirmado', 15, 3, 21);


-- EVIDENCIAS
INSERT INTO Evidencia VALUES (1, 'Video', 'Grabación del hurto', DATE '2025-01-15', 1);
INSERT INTO Evidencia VALUES (2, 'Fotografía', 'Foto de sospechoso', DATE '2025-02-10', 2);
INSERT INTO Evidencia VALUES (3, 'Arma blanca', 'Cuchillo hallado', DATE '2025-03-20', 3);
INSERT INTO Evidencia VALUES (4, 'Objeto recuperado', 'Celular robado', DATE '2025-04-05', 4);
INSERT INTO Evidencia VALUES (5, 'Historia clínica', 'Informe de lesiones', DATE '2025-05-18', 5);
INSERT INTO Evidencia VALUES (6, 'Video', 'Grabación de la riña', DATE '2025-06-01', 6);
INSERT INTO Evidencia VALUES (7, 'Testimonio', 'Declaración de víctima', DATE '2025-06-10', 7);
INSERT INTO Evidencia VALUES (8, 'Arma de fuego', 'Pistola incautada', DATE '2025-06-22', 8);
INSERT INTO Evidencia VALUES (9, 'Objeto robado', 'Bolso recuperado', DATE '2025-07-03', 9);
INSERT INTO Evidencia VALUES (10, 'Audio', 'Amenaza grabada', DATE '2025-07-15', 10);
INSERT INTO Evidencia VALUES (11, 'Testimonio', 'Relato del incidente', DATE '2025-08-05', 1);
INSERT INTO Evidencia VALUES (12, 'Fotografía', 'Daños en local', DATE '2025-08-25', 2);
INSERT INTO Evidencia VALUES (13, 'Video', 'Cámara de seguridad', DATE '2025-09-10', 3);
INSERT INTO Evidencia VALUES (14, 'Objeto', 'Reloj recuperado', DATE '2025-09-27', 4);
INSERT INTO Evidencia VALUES (15, 'Documento', 'Informe pericial', DATE '2025-10-12', 5);

--Puentes 

INSERT INTO Incidente_Ciudadano VALUES (1,1);
INSERT INTO Incidente_Ciudadano VALUES (2,2);
INSERT INTO Incidente_Ciudadano VALUES (3,3);
INSERT INTO Incidente_Ciudadano VALUES (4,4);
INSERT INTO Incidente_Ciudadano VALUES (5,5);
INSERT INTO Incidente_Ciudadano VALUES (6,1);
INSERT INTO Incidente_Ciudadano VALUES (7,2);
INSERT INTO Incidente_Ciudadano VALUES (8,3);
INSERT INTO Incidente_Ciudadano VALUES (9,4);
INSERT INTO Incidente_Ciudadano VALUES (10,5);
INSERT INTO Incidente_Ciudadano VALUES (11,6);
INSERT INTO Incidente_Ciudadano VALUES (12,7);
INSERT INTO Incidente_Ciudadano VALUES (13,8);
INSERT INTO Incidente_Ciudadano VALUES (14,9);
INSERT INTO Incidente_Ciudadano VALUES (15,10);

INSERT INTO Incidente_Sospechoso VALUES (1,1);
INSERT INTO Incidente_Sospechoso VALUES (2,2);
INSERT INTO Incidente_Sospechoso VALUES (3,3);
INSERT INTO Incidente_Sospechoso VALUES (4,4);
INSERT INTO Incidente_Sospechoso VALUES (5,5);
INSERT INTO Incidente_Sospechoso VALUES (6,6);
INSERT INTO Incidente_Sospechoso VALUES (7,7);
INSERT INTO Incidente_Sospechoso VALUES (8,8);
INSERT INTO Incidente_Sospechoso VALUES (9,9);
INSERT INTO Incidente_Sospechoso VALUES (10,10);
INSERT INTO Incidente_Sospechoso VALUES (11,1);
INSERT INTO Incidente_Sospechoso VALUES (12,2);
INSERT INTO Incidente_Sospechoso VALUES (13,3);
INSERT INTO Incidente_Sospechoso VALUES (14,4);
INSERT INTO Incidente_Sospechoso VALUES (15,5);


COMMIT;

/*============================================================
VERIFICAR POBLAR
============================================================ */
SELECT COUNT(*) AS c_incidentes FROM Incidente;
SELECT COUNT(*) AS c_ubicaciones FROM Ubicacion;
SELECT COUNT(*) AS c_delitos FROM Delito;
SELECT COUNT(*) AS c_ciudadanos FROM Ciudadano;
SELECT COUNT(*) AS c_sospechosos FROM Sospechoso;
SELECT COUNT(*) AS c_autoridades FROM Autoridad;
SELECT COUNT(*) AS c_unidades_policiales FROM UnidadPolicial;
SELECT COUNT(*) AS c_actuaciones FROM Actuacion;
SELECT COUNT(*) AS c_denuncias FROM Denuncia;
SELECT COUNT(*) AS c_evidencias FROM Evidencia;

-- Tablas puente
SELECT COUNT(*) AS c_incidente_ciudadano FROM Incidente_Ciudadano;
SELECT COUNT(*) AS c_incidente_sospechoso FROM Incidente_Sospechoso;
