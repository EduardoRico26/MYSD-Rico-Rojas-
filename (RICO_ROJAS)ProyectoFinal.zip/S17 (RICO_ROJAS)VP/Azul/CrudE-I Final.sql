/*============================================================
CRUD E y I 
Especificacion e Implementancion de los paquetes 
    ============================================================*/

/*============================================================
1) PC_MantenerAutoridad
============================================================*/
CREATE OR REPLACE PACKAGE PC_MantenerAutoridad AS
  PROCEDURE ad_autoridad(
    p_autoridad_id IN NUMBER,
    p_codigo       IN VARCHAR2,
    p_nombre       IN VARCHAR2,
    p_tipo         IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2
  );

  PROCEDURE mod_autoridad(
    p_autoridad_id IN NUMBER,
    p_nombre       IN VARCHAR2,
    p_tipo         IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2
  );

  PROCEDURE del_autoridad(
    p_autoridad_id IN NUMBER
  );

  FUNCTION fc_get_autoridad_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_autoridades RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_por_tipo(p_tipo IN VARCHAR2) RETURN SYS_REFCURSOR;

  FUNCTION fn_existe_autoridad(p_codigo IN VARCHAR2) RETURN BOOLEAN;
  FUNCTION fn_count_autoridades RETURN NUMBER;
END PC_MantenerAutoridad;
/

CREATE OR REPLACE PACKAGE BODY PC_MantenerAutoridad AS
  PROCEDURE ad_autoridad(
    p_autoridad_id IN NUMBER,
    p_codigo       IN VARCHAR2,
    p_nombre       IN VARCHAR2,
    p_tipo         IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2
  ) IS
  BEGIN
    INSERT INTO Autoridad(
      AutoridadID, CodigoAutoridad, Nombre, TipoAutoridad, Telefono, Correo
    ) VALUES (
      p_autoridad_id, p_codigo, p_nombre, p_tipo, p_telefono, p_correo
    );
  END ad_autoridad;

  PROCEDURE mod_autoridad(
    p_autoridad_id IN NUMBER,
    p_nombre       IN VARCHAR2,
    p_tipo         IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2
  ) IS
  BEGIN
    UPDATE Autoridad
    SET Nombre        = p_nombre,
        TipoAutoridad = p_tipo,
        Telefono      = p_telefono,
        Correo        = p_correo
    WHERE AutoridadID = p_autoridad_id;
  END mod_autoridad;

  PROCEDURE del_autoridad(
    p_autoridad_id IN NUMBER
  ) IS
  BEGIN
    DELETE FROM Autoridad
    WHERE AutoridadID = p_autoridad_id;
  END del_autoridad;

  FUNCTION fc_get_autoridad_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT AutoridadID, CodigoAutoridad, Nombre, TipoAutoridad, Telefono, Correo
      FROM Autoridad
      WHERE AutoridadID = p_id;
    RETURN rc;
  END fc_get_autoridad_by_id;

  FUNCTION fc_listar_autoridades RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT AutoridadID, CodigoAutoridad, Nombre, TipoAutoridad, Telefono, Correo
      FROM Autoridad
      ORDER BY Nombre;
    RETURN rc;
  END fc_listar_autoridades;

  FUNCTION fc_listar_por_tipo(p_tipo IN VARCHAR2) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT AutoridadID, CodigoAutoridad, Nombre, TipoAutoridad, Telefono, Correo
      FROM Autoridad
      WHERE TipoAutoridad = p_tipo
      ORDER BY Nombre;
    RETURN rc;
  END fc_listar_por_tipo;

  FUNCTION fn_existe_autoridad(p_codigo IN VARCHAR2) RETURN BOOLEAN IS
    v_cnt NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_cnt
    FROM Autoridad
    WHERE CodigoAutoridad = p_codigo;
    RETURN v_cnt > 0;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END fn_existe_autoridad;

  FUNCTION fn_count_autoridades RETURN NUMBER IS
    v_cnt NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_cnt FROM Autoridad;
    RETURN v_cnt;
  END fn_count_autoridades;
END PC_MantenerAutoridad;
/

/*============================================================
) PC_MantenerCiudadano
============================================================*/
CREATE OR REPLACE PACKAGE PC_MantenerCiudadano AS
  PROCEDURE ad_ciudadano(
    p_id_ciudadano IN NUMBER,
    p_documento    IN VARCHAR2,
    p_nombres      IN VARCHAR2,
    p_apellidos    IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2,
    p_direccion    IN VARCHAR2
  );

  PROCEDURE mod_ciudadano(
    p_id_ciudadano IN NUMBER,
    p_nombres      IN VARCHAR2,
    p_apellidos    IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2,
    p_direccion    IN VARCHAR2
  );

  PROCEDURE del_ciudadano(
    p_id_ciudadano IN NUMBER
  );

  FUNCTION fc_get_ciudadano_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_ciudadanos RETURN SYS_REFCURSOR;
  FUNCTION fc_buscar_por_documento(p_documento IN VARCHAR2) RETURN SYS_REFCURSOR;

  FUNCTION fn_existe_ciudadano(p_documento IN VARCHAR2) RETURN BOOLEAN;
  FUNCTION fn_count_ciudadanos RETURN NUMBER;
END PC_MantenerCiudadano;
/

CREATE OR REPLACE PACKAGE BODY PC_MantenerCiudadano AS
  PROCEDURE ad_ciudadano(
    p_id_ciudadano IN NUMBER,
    p_documento    IN VARCHAR2,
    p_nombres      IN VARCHAR2,
    p_apellidos    IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2,
    p_direccion    IN VARCHAR2
  ) IS
  BEGIN
    INSERT INTO Ciudadano(
      CiudadanoID, Documento, Nombres, Apellidos, Telefono, Correo, Direccion
    ) VALUES (
      p_id_ciudadano, p_documento, p_nombres, p_apellidos, p_telefono, p_correo, p_direccion
    );
  END ad_ciudadano;

  PROCEDURE mod_ciudadano(
    p_id_ciudadano IN NUMBER,
    p_nombres      IN VARCHAR2,
    p_apellidos    IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2,
    p_direccion    IN VARCHAR2
  ) IS
  BEGIN
    UPDATE Ciudadano
    SET Nombres   = p_nombres,
        Apellidos = p_apellidos,
        Telefono  = p_telefono,
        Correo    = p_correo,
        Direccion = p_direccion
    WHERE CiudadanoID = p_id_ciudadano;
  END mod_ciudadano;

  PROCEDURE del_ciudadano(
    p_id_ciudadano IN NUMBER
  ) IS
  BEGIN
    DELETE FROM Ciudadano
    WHERE CiudadanoID = p_id_ciudadano;
  END del_ciudadano;

  FUNCTION fc_get_ciudadano_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT CiudadanoID, Documento, Nombres, Apellidos, Telefono, Correo, Direccion
      FROM Ciudadano
      WHERE CiudadanoID = p_id;
    RETURN rc;
  END fc_get_ciudadano_by_id;

  FUNCTION fc_listar_ciudadanos RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT CiudadanoID, Documento, Nombres, Apellidos, Telefono, Correo, Direccion
      FROM Ciudadano
      ORDER BY Apellidos, Nombres;
    RETURN rc;
  END fc_listar_ciudadanos;

  FUNCTION fc_buscar_por_documento(p_documento IN VARCHAR2) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT CiudadanoID, Documento, Nombres, Apellidos, Telefono, Correo, Direccion
      FROM Ciudadano
      WHERE Documento = p_documento;
    RETURN rc;
  END fc_buscar_por_documento;

  FUNCTION fn_existe_ciudadano(p_documento IN VARCHAR2) RETURN BOOLEAN IS
    v_cnt NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_cnt
    FROM Ciudadano
    WHERE Documento = p_documento;
    RETURN v_cnt > 0;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END fn_existe_ciudadano;

  FUNCTION fn_count_ciudadanos RETURN NUMBER IS
    v_cnt NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_cnt FROM Ciudadano;
    RETURN v_cnt;
  END fn_count_ciudadanos;
END PC_MantenerCiudadano;
/

/*============================================================
3) PC_MantenerSospechoso
============================================================*/
CREATE OR REPLACE PACKAGE PC_MantenerSospechoso AS
  PROCEDURE ad_sospechoso(
    p_id_sospechoso IN NUMBER,
    p_documento     IN VARCHAR2,
    p_alias         IN VARCHAR2,
    p_nombres       IN VARCHAR2,
    p_apellidos     IN VARCHAR2,
    p_observaciones IN VARCHAR2
  );

  PROCEDURE mod_sospechoso(
    p_id_sospechoso IN NUMBER,
    p_alias         IN VARCHAR2,
    p_observaciones IN VARCHAR2
  );

  PROCEDURE del_sospechoso(
    p_id_sospechoso IN NUMBER
  );

  FUNCTION fc_get_sospechoso_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_sospechosos RETURN SYS_REFCURSOR;
  FUNCTION fc_buscar_por_documento(p_documento IN VARCHAR2) RETURN SYS_REFCURSOR;

  FUNCTION fn_existe_sospechoso(p_documento IN VARCHAR2) RETURN BOOLEAN;
  FUNCTION fn_count_sospechosos RETURN NUMBER;
END PC_MantenerSospechoso;
/

CREATE OR REPLACE PACKAGE BODY PC_MantenerSospechoso AS
  PROCEDURE ad_sospechoso(
    p_id_sospechoso IN NUMBER,
    p_documento     IN VARCHAR2,
    p_alias         IN VARCHAR2,
    p_nombres       IN VARCHAR2,
    p_apellidos     IN VARCHAR2,
    p_observaciones IN VARCHAR2
  ) IS
  BEGIN
    INSERT INTO Sospechoso(
      SospechosoID, Documento, Alias, Nombres, Apellidos, Observaciones
    ) VALUES (
      p_id_sospechoso, p_documento, p_alias, p_nombres, p_apellidos, p_observaciones
    );
  END ad_sospechoso;

  PROCEDURE mod_sospechoso(
    p_id_sospechoso IN NUMBER,
    p_alias         IN VARCHAR2,
    p_observaciones IN VARCHAR2
  ) IS
  BEGIN
    UPDATE Sospechoso
    SET Alias = p_alias,
        Observaciones = p_observaciones
    WHERE SospechosoID = p_id_sospechoso;
  END mod_sospechoso;

  PROCEDURE del_sospechoso(
    p_id_sospechoso IN NUMBER
  ) IS
  BEGIN
    DELETE FROM Sospechoso
    WHERE SospechosoID = p_id_sospechoso;
  END del_sospechoso;

  FUNCTION fc_get_sospechoso_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT SospechosoID, Documento, Alias, Nombres, Apellidos, Observaciones
      FROM Sospechoso
      WHERE SospechosoID = p_id;
    RETURN rc;
  END fc_get_sospechoso_by_id;

  FUNCTION fc_listar_sospechosos RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT SospechosoID, Documento, Alias, Nombres, Apellidos, Observaciones
      FROM Sospechoso
      ORDER BY Apellidos, Nombres;
    RETURN rc;
  END fc_listar_sospechosos;

  FUNCTION fc_buscar_por_documento(p_documento IN VARCHAR2) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT SospechosoID, Documento, Alias, Nombres, Apellidos, Observaciones
      FROM Sospechoso
      WHERE Documento = p_documento;
    RETURN rc;
  END fc_buscar_por_documento;

  FUNCTION fn_existe_sospechoso(p_documento IN VARCHAR2) RETURN BOOLEAN IS
    v_cnt NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_cnt
    FROM Sospechoso
    WHERE Documento = p_documento;
    RETURN v_cnt > 0;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END fn_existe_sospechoso;

  FUNCTION fn_count_sospechosos RETURN NUMBER IS
    v_cnt NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_cnt FROM Sospechoso;
    RETURN v_cnt;
  END fn_count_sospechosos;
END PC_MantenerSospechoso;
/

/*============================================================
4) PC_MantenerDelito
============================================================*/
CREATE OR REPLACE PACKAGE PC_MantenerDelito AS
  PROCEDURE ad_delito(
    p_delito_id   IN NUMBER,
    p_codigo      IN VARCHAR2,
    p_nombre      IN VARCHAR2,
    p_descripcion IN VARCHAR2,
    p_categoria   IN VARCHAR2,
    p_gravedad    IN VARCHAR2
  );

  PROCEDURE mod_delito(
    p_delito_id   IN NUMBER,
    p_descripcion IN VARCHAR2,
    p_categoria   IN VARCHAR2,
    p_gravedad    IN VARCHAR2
  );

  PROCEDURE del_delito(
    p_delito_id IN NUMBER
  );

  FUNCTION fc_get_delito_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR;
  FUNCTION fc_buscar_por_codigo(p_codigo IN VARCHAR2) RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_por_categoria(p_categoria IN VARCHAR2) RETURN SYS_REFCURSOR;

  FUNCTION fn_existe_delito(p_codigo IN VARCHAR2) RETURN BOOLEAN;
  FUNCTION fn_count_delitos RETURN NUMBER;
END PC_MantenerDelito;
/

CREATE OR REPLACE PACKAGE BODY PC_MantenerDelito AS
  PROCEDURE ad_delito(
    p_delito_id   IN NUMBER,
    p_codigo      IN VARCHAR2,
    p_nombre      IN VARCHAR2,
    p_descripcion IN VARCHAR2,
    p_categoria   IN VARCHAR2,
    p_gravedad    IN VARCHAR2
  ) IS
  BEGIN
    INSERT INTO Delito(
      DelitoID, CodigoDelito, NombreDelito, Descripcion, Categoria, Gravedad
    ) VALUES (
      p_delito_id, p_codigo, p_nombre, p_descripcion, p_categoria, p_gravedad
    );
  END ad_delito;

  PROCEDURE mod_delito(
    p_delito_id   IN NUMBER,
    p_descripcion IN VARCHAR2,
    p_categoria   IN VARCHAR2,
    p_gravedad    IN VARCHAR2
  ) IS
  BEGIN
    UPDATE Delito
    SET Descripcion = p_descripcion,
        Categoria   = p_categoria,
        Gravedad    = p_gravedad
    WHERE DelitoID = p_delito_id;
  END mod_delito;

  PROCEDURE del_delito(
    p_delito_id IN NUMBER
  ) IS
  BEGIN
    DELETE FROM Delito
    WHERE DelitoID = p_delito_id;
  END del_delito;

  FUNCTION fc_get_delito_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT DelitoID, CodigoDelito, NombreDelito, Descripcion, Categoria, Gravedad
      FROM Delito
      WHERE DelitoID = p_id;
    RETURN rc;
  END fc_get_delito_by_id;

  FUNCTION fc_buscar_por_codigo(p_codigo IN VARCHAR2) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT DelitoID, CodigoDelito, NombreDelito, Descripcion, Categoria, Gravedad
      FROM Delito
      WHERE CodigoDelito = p_codigo;
    RETURN rc;
  END fc_buscar_por_codigo;

  FUNCTION fc_listar_por_categoria(p_categoria IN VARCHAR2) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT DelitoID, CodigoDelito, NombreDelito, Categoria, Gravedad
      FROM Delito
      WHERE Categoria = p_categoria
      ORDER BY NombreDelito;
    RETURN rc;
  END fc_listar_por_categoria;

  FUNCTION fn_existe_delito(p_codigo IN VARCHAR2) RETURN BOOLEAN IS
    v_cnt NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_cnt
    FROM Delito
    WHERE CodigoDelito = p_codigo;
    RETURN v_cnt > 0;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END fn_existe_delito;

  FUNCTION fn_count_delitos RETURN NUMBER IS
    v_cnt NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_cnt FROM Delito;
    RETURN v_cnt;
  END fn_count_delitos;
END PC_MantenerDelito;
/

/*============================================================
5) PC_MantenerUbicacion
============================================================*/
CREATE OR REPLACE PACKAGE PC_MantenerUbicacion AS
  PROCEDURE ad_ubicacion(
    p_ubicacion_id IN NUMBER,
    p_codigo       IN VARCHAR2,
    p_direccion    IN VARCHAR2,
    p_barrio       IN VARCHAR2,
    p_localidad    IN VARCHAR2,
    p_lat          IN VARCHAR2,
    p_lon          IN VARCHAR2
  );

  PROCEDURE mod_ubicacion(
    p_ubicacion_id IN NUMBER,
    p_direccion    IN VARCHAR2,
    p_barrio       IN VARCHAR2,
    p_localidad    IN VARCHAR2,
    p_lat          IN VARCHAR2,
    p_lon          IN VARCHAR2
  );

  PROCEDURE del_ubicacion(
    p_ubicacion_id IN NUMBER
  );

  FUNCTION fc_get_ubicacion_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR;
  FUNCTION fc_buscar_por_codigo(p_codigo IN VARCHAR2) RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_por_localidad(p_localidad IN VARCHAR2) RETURN SYS_REFCURSOR;

  FUNCTION fn_existe_ubicacion(p_codigo IN VARCHAR2) RETURN BOOLEAN;
  FUNCTION fn_count_ubicaciones RETURN NUMBER;
END PC_MantenerUbicacion;
/

CREATE OR REPLACE PACKAGE BODY PC_MantenerUbicacion AS
  PROCEDURE ad_ubicacion(
    p_ubicacion_id IN NUMBER,
    p_codigo       IN VARCHAR2,
    p_direccion    IN VARCHAR2,
    p_barrio       IN VARCHAR2,
    p_localidad    IN VARCHAR2,
    p_lat          IN VARCHAR2,
    p_lon          IN VARCHAR2
  ) IS
  BEGIN
    INSERT INTO Ubicacion(
      UbicacionID, CodigoUbicacion, Direccion, Barrio, Localidad, CoordenadaLat, CoordenadaLon
    ) VALUES (
      p_ubicacion_id, p_codigo, p_direccion, p_barrio, p_localidad, p_lat, p_lon
    );
  END ad_ubicacion;

  PROCEDURE mod_ubicacion(
    p_ubicacion_id IN NUMBER,
    p_direccion    IN VARCHAR2,
    p_barrio       IN VARCHAR2,
    p_localidad    IN VARCHAR2,
    p_lat          IN VARCHAR2,
    p_lon          IN VARCHAR2
  ) IS
  BEGIN
    UPDATE Ubicacion
    SET Direccion     = p_direccion,
        Barrio        = p_barrio,
        Localidad     = p_localidad,
        CoordenadaLat = p_lat,
        CoordenadaLon = p_lon
    WHERE UbicacionID = p_ubicacion_id;
  END mod_ubicacion;

  PROCEDURE del_ubicacion(
    p_ubicacion_id IN NUMBER
  ) IS
  BEGIN
    DELETE FROM Ubicacion
    WHERE UbicacionID = p_ubicacion_id;
  END del_ubicacion;

  FUNCTION fc_get_ubicacion_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT UbicacionID, CodigoUbicacion, Direccion, Barrio, Localidad, CoordenadaLat, CoordenadaLon
      FROM Ubicacion
      WHERE UbicacionID = p_id;
    RETURN rc;
  END fc_get_ubicacion_by_id;

  FUNCTION fc_buscar_por_codigo(p_codigo IN VARCHAR2) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT UbicacionID, CodigoUbicacion, Direccion, Barrio, Localidad, CoordenadaLat, CoordenadaLon
      FROM Ubicacion
      WHERE CodigoUbicacion = p_codigo;
    RETURN rc;
  END fc_buscar_por_codigo;

  FUNCTION fc_listar_por_localidad(p_localidad IN VARCHAR2) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT UbicacionID, CodigoUbicacion, Direccion, Barrio, Localidad, CoordenadaLat, CoordenadaLon
      FROM Ubicacion
      WHERE Localidad = p_localidad
      ORDER BY Barrio, Direccion;
    RETURN rc;
  END fc_listar_por_localidad;

  FUNCTION fn_existe_ubicacion(p_codigo IN VARCHAR2) RETURN BOOLEAN IS
    v_cnt NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_cnt
    FROM Ubicacion
    WHERE CodigoUbicacion = p_codigo;
    RETURN v_cnt > 0;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END fn_existe_ubicacion;

  FUNCTION fn_count_ubicaciones RETURN NUMBER IS
    v_cnt NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_cnt FROM Ubicacion;
    RETURN v_cnt;
  END fn_count_ubicaciones;
END PC_MantenerUbicacion;
/

/*============================================================
6) PC_RegistrarIncidente
============================================================*/
CREATE OR REPLACE PACKAGE PC_RegistrarIncidente AS
  PROCEDURE ad_incidente(
    p_incidente_id IN NUMBER,
    p_codigo       IN VARCHAR2,
    p_fecha        IN DATE,
    p_descripcion  IN VARCHAR2,
    p_severidad    IN VARCHAR2,
    p_estado       IN VARCHAR2,
    p_delito_id    IN NUMBER,
    p_ubicacion_id IN NUMBER
  );

  PROCEDURE mod_incidente(
    p_incidente_id IN NUMBER,
    p_descripcion  IN VARCHAR2,
    p_severidad    IN VARCHAR2,
    p_estado       IN VARCHAR2,
    p_delito_id    IN NUMBER,
    p_ubicacion_id IN NUMBER
  );

  PROCEDURE mod_estado_incidente(
    p_incidente_id IN NUMBER,
    p_estado       IN VARCHAR2
  );

  PROCEDURE del_incidente(
    p_incidente_id IN NUMBER
  );

  PROCEDURE ad_incidente_ciudadano(
    p_incidente_id IN NUMBER,
    p_ciudadano_id IN NUMBER
  );

  PROCEDURE ad_incidente_sospechoso(
    p_incidente_id  IN NUMBER,
    p_sospechoso_id IN NUMBER
  );
END PC_RegistrarIncidente;
/

CREATE OR REPLACE PACKAGE BODY PC_RegistrarIncidente AS
  PROCEDURE ad_incidente(
    p_incidente_id IN NUMBER,
    p_codigo       IN VARCHAR2,
    p_fecha        IN DATE,
    p_descripcion  IN VARCHAR2,
    p_severidad    IN VARCHAR2,
    p_estado       IN VARCHAR2,
    p_delito_id    IN NUMBER,
    p_ubicacion_id IN NUMBER
  ) IS
  BEGIN
    INSERT INTO Incidente(
      IncidenteID, CodigoIncidente, FechaIncidente, Descripcion,
      Severidad, Estado, DelitoID, UbicacionID
    ) VALUES (
      p_incidente_id, p_codigo, p_fecha, p_descripcion,
      p_severidad, p_estado, p_delito_id, p_ubicacion_id
    );
  END ad_incidente;

  PROCEDURE mod_incidente(
    p_incidente_id IN NUMBER,
    p_descripcion  IN VARCHAR2,
    p_severidad    IN VARCHAR2,
    p_estado       IN VARCHAR2,
    p_delito_id    IN NUMBER,
    p_ubicacion_id IN NUMBER
  ) IS
  BEGIN
    UPDATE Incidente
    SET Descripcion = p_descripcion,
        Severidad   = p_severidad,
        Estado      = p_estado,
        DelitoID    = p_delito_id,
        UbicacionID = p_ubicacion_id
    WHERE IncidenteID = p_incidente_id;
  END mod_incidente;

  PROCEDURE mod_estado_incidente(
    p_incidente_id IN NUMBER,
    p_estado       IN VARCHAR2
  ) IS
  BEGIN
    UPDATE Incidente
    SET Estado = p_estado
    WHERE IncidenteID = p_incidente_id;
  END mod_estado_incidente;

  PROCEDURE del_incidente(
    p_incidente_id IN NUMBER
  ) IS
  BEGIN
    DELETE FROM Incidente
    WHERE IncidenteID = p_incidente_id;
  END del_incidente;

  PROCEDURE ad_incidente_ciudadano(
    p_incidente_id IN NUMBER,
    p_ciudadano_id IN NUMBER
  ) IS
  BEGIN
    INSERT INTO Incidente_Ciudadano(IncidenteID, CiudadanoID)
    VALUES (p_incidente_id, p_ciudadano_id);
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      NULL;
  END ad_incidente_ciudadano;

  PROCEDURE ad_incidente_sospechoso(
    p_incidente_id  IN NUMBER,
    p_sospechoso_id IN NUMBER
  ) IS
  BEGIN
    INSERT INTO Incidente_Sospechoso(IncidenteID, SospechosoID)
    VALUES (p_incidente_id, p_sospechoso_id);
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      NULL;
  END ad_incidente_sospechoso;
END PC_RegistrarIncidente;
/

/*============================================================
7) PC_ConsultarIncidentes
============================================================*/
CREATE OR REPLACE PACKAGE PC_ConsultarIncidentes AS
  FUNCTION fc_get_incidente_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_incidentes RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_por_estado(p_estado IN VARCHAR2) RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_por_localidad(p_localidad IN VARCHAR2) RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_por_delito(p_delito_id IN NUMBER) RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_por_rango_fecha(p_fecha_ini IN DATE, p_fecha_fin IN DATE) RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_por_ciudadano(p_ciudadano_id IN NUMBER) RETURN SYS_REFCURSOR;
END PC_ConsultarIncidentes;
/

CREATE OR REPLACE PACKAGE BODY PC_ConsultarIncidentes AS
  FUNCTION fc_get_incidente_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT i.IncidenteID, i.CodigoIncidente, i.FechaIncidente, i.Descripcion,
             i.Severidad, i.Estado,
             d.DelitoID, d.NombreDelito, d.Categoria, d.Gravedad,
             u.UbicacionID, u.Direccion, u.Barrio, u.Localidad, u.CoordenadaLat, u.CoordenadaLon
      FROM Incidente i
      LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
      LEFT JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
      WHERE i.IncidenteID = p_id;
    RETURN rc;
  END fc_get_incidente_by_id;

  FUNCTION fc_listar_incidentes RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT i.IncidenteID, i.CodigoIncidente, i.FechaIncidente, i.Severidad, i.Estado,
             d.NombreDelito, u.Localidad, u.Barrio
      FROM Incidente i
      LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
      LEFT JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
      ORDER BY i.FechaIncidente DESC;
    RETURN rc;
  END fc_listar_incidentes;

  FUNCTION fc_listar_por_estado(p_estado IN VARCHAR2) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT i.IncidenteID, i.CodigoIncidente, i.FechaIncidente, i.Severidad, i.Estado,
             d.NombreDelito, u.Localidad, u.Barrio
      FROM Incidente i
      LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
      LEFT JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
      WHERE i.Estado = p_estado
      ORDER BY i.FechaIncidente DESC;
    RETURN rc;
  END fc_listar_por_estado;

  FUNCTION fc_listar_por_localidad(p_localidad IN VARCHAR2) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT i.IncidenteID, i.CodigoIncidente, i.FechaIncidente, i.Severidad, i.Estado,
             d.NombreDelito, u.Localidad, u.Barrio
      FROM Incidente i
      LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
      LEFT JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
      WHERE u.Localidad = p_localidad
      ORDER BY i.FechaIncidente DESC;
    RETURN rc;
  END fc_listar_por_localidad;

  FUNCTION fc_listar_por_delito(p_delito_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT i.IncidenteID, i.CodigoIncidente, i.FechaIncidente, i.Severidad, i.Estado,
             d.NombreDelito, u.Localidad, u.Barrio
      FROM Incidente i
      LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
      LEFT JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
      WHERE i.DelitoID = p_delito_id
      ORDER BY i.FechaIncidente DESC;
    RETURN rc;
  END fc_listar_por_delito;

  FUNCTION fc_listar_por_rango_fecha(p_fecha_ini IN DATE, p_fecha_fin IN DATE) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT i.IncidenteID, i.CodigoIncidente, i.FechaIncidente, i.Severidad, i.Estado,
             d.NombreDelito, u.Localidad, u.Barrio
      FROM Incidente i
      LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
      LEFT JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
      WHERE i.FechaIncidente BETWEEN p_fecha_ini AND p_fecha_fin
      ORDER BY i.FechaIncidente DESC;
    RETURN rc;
  END fc_listar_por_rango_fecha;

  FUNCTION fc_listar_por_ciudadano(p_ciudadano_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT i.IncidenteID, i.CodigoIncidente, i.FechaIncidente, i.Severidad, i.Estado,
             d.NombreDelito, u.Localidad, u.Barrio
      FROM Incidente_Ciudadano ic
      JOIN Incidente i ON i.IncidenteID = ic.IncidenteID
      LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
      LEFT JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
      WHERE ic.CiudadanoID = p_ciudadano_id
      ORDER BY i.FechaIncidente DESC;
    RETURN rc;
  END fc_listar_por_ciudadano;
END PC_ConsultarIncidentes;
/

/*============================================================
8) PC_RegistrarEvidencia
============================================================*/
CREATE OR REPLACE PACKAGE PC_RegistrarEvidencia AS
  PROCEDURE ad_evidencia(
    p_evidencia_id   IN NUMBER,
    p_tipo           IN VARCHAR2,
    p_descripcion    IN VARCHAR2,
    p_fecha_registro IN DATE,
    p_ciudadano_id   IN NUMBER
  );

  PROCEDURE mod_evidencia(
    p_evidencia_id IN NUMBER,
    p_tipo         IN VARCHAR2,
    p_descripcion  IN VARCHAR2
  );

  PROCEDURE del_evidencia(
    p_evidencia_id IN NUMBER
  );

  FUNCTION fc_get_evidencia_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_por_ciudadano(p_ciudadano_id IN NUMBER) RETURN SYS_REFCURSOR;
  FUNCTION fc_listar_por_rango_fecha(p_fecha_ini IN DATE, p_fecha_fin IN DATE) RETURN SYS_REFCURSOR;
  FUNCTION fn_count_evidencias RETURN NUMBER;
END PC_RegistrarEvidencia;
/

CREATE OR REPLACE PACKAGE BODY PC_RegistrarEvidencia AS
  PROCEDURE ad_evidencia(
    p_evidencia_id   IN NUMBER,
    p_tipo           IN VARCHAR2,
    p_descripcion    IN VARCHAR2,
    p_fecha_registro IN DATE,
    p_ciudadano_id   IN NUMBER
  ) IS
  BEGIN
    INSERT INTO Evidencia(
      EvidenciaID, TipoEvidencia, Descripcion, FechaRegistro, CiudadanoID
    ) VALUES (
      p_evidencia_id, p_tipo, p_descripcion, p_fecha_registro, p_ciudadano_id
    );
  END ad_evidencia;

  PROCEDURE mod_evidencia(
    p_evidencia_id IN NUMBER,
    p_tipo         IN VARCHAR2,
    p_descripcion  IN VARCHAR2
  ) IS
  BEGIN
    UPDATE Evidencia
    SET TipoEvidencia = p_tipo,
        Descripcion   = p_descripcion
    WHERE EvidenciaID = p_evidencia_id;
  END mod_evidencia;

  PROCEDURE del_evidencia(
    p_evidencia_id IN NUMBER
  ) IS
  BEGIN
    DELETE FROM Evidencia
    WHERE EvidenciaID = p_evidencia_id;
  END del_evidencia;

  FUNCTION fc_get_evidencia_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT e.EvidenciaID, e.TipoEvidencia, e.Descripcion, e.FechaRegistro,
             e.CiudadanoID, c.Documento, c.Nombres, c.Apellidos
      FROM Evidencia e
      LEFT JOIN Ciudadano c ON c.CiudadanoID = e.CiudadanoID
      WHERE e.EvidenciaID = p_id;
    RETURN rc;
  END fc_get_evidencia_by_id;

  FUNCTION fc_listar_por_ciudadano(p_ciudadano_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT EvidenciaID, TipoEvidencia, Descripcion, FechaRegistro, CiudadanoID
      FROM Evidencia
      WHERE CiudadanoID = p_ciudadano_id
      ORDER BY FechaRegistro DESC;
    RETURN rc;
  END fc_listar_por_ciudadano;

  FUNCTION fc_listar_por_rango_fecha(p_fecha_ini IN DATE, p_fecha_fin IN DATE) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT EvidenciaID, TipoEvidencia, Descripcion, FechaRegistro, CiudadanoID
      FROM Evidencia
      WHERE FechaRegistro BETWEEN p_fecha_ini AND p_fecha_fin
      ORDER BY FechaRegistro DESC;
    RETURN rc;
  END fc_listar_por_rango_fecha;

  FUNCTION fn_count_evidencias RETURN NUMBER IS
    v_cnt NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_cnt FROM Evidencia;
    RETURN v_cnt;
  END fn_count_evidencias;
END PC_RegistrarEvidencia;
/

/*============================================================
9) PC_ConsultarProcesosJudiciales
Nota: En este modelo, proceso judicial se representa con Denuncia y Actuacion
============================================================*/
CREATE OR REPLACE PACKAGE PC_ConsultarProcesosJudiciales AS
  FUNCTION fc_resumen_proceso_por_incidente(p_incidente_id IN NUMBER) RETURN SYS_REFCURSOR;
  FUNCTION fc_denuncias_por_incidente(p_incidente_id IN NUMBER) RETURN SYS_REFCURSOR;
  FUNCTION fc_actuaciones_por_incidente(p_incidente_id IN NUMBER) RETURN SYS_REFCURSOR;
  FUNCTION fc_sospechosos_por_incidente(p_incidente_id IN NUMBER) RETURN SYS_REFCURSOR;
  FUNCTION fc_procesos_por_ciudadano(p_ciudadano_id IN NUMBER) RETURN SYS_REFCURSOR;
END PC_ConsultarProcesosJudiciales;
/

CREATE OR REPLACE PACKAGE BODY PC_ConsultarProcesosJudiciales AS
  FUNCTION fc_resumen_proceso_por_incidente(p_incidente_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT i.IncidenteID, i.CodigoIncidente, i.FechaIncidente, i.Severidad, i.Estado,
             d.NombreDelito,
             u.Localidad, u.Barrio, u.Direccion,
             (SELECT COUNT(*) FROM Denuncia dn WHERE dn.IncidenteID = i.IncidenteID) AS CantDenuncias,
             (SELECT COUNT(*) FROM Actuacion ac WHERE ac.IncidenteID = i.IncidenteID) AS CantActuaciones,
             (SELECT COUNT(*) FROM Incidente_Ciudadano ic WHERE ic.IncidenteID = i.IncidenteID) AS CantCiudadanos,
             (SELECT COUNT(*) FROM Incidente_Sospechoso isx WHERE isx.IncidenteID = i.IncidenteID) AS CantSospechosos
      FROM Incidente i
      LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
      LEFT JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
      WHERE i.IncidenteID = p_incidente_id;
    RETURN rc;
  END fc_resumen_proceso_por_incidente;

  FUNCTION fc_denuncias_por_incidente(p_incidente_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT dn.DenunciaID, dn.NumeroDenuncia, dn.FechaDenuncia, dn.Detalle,
             dn.CiudadanoID, c.Documento, c.Nombres, c.Apellidos,
             dn.AutoridadID, a.Nombre AS AutoridadNombre
      FROM Denuncia dn
      LEFT JOIN Ciudadano c ON c.CiudadanoID = dn.CiudadanoID
      LEFT JOIN Autoridad a ON a.AutoridadID = dn.AutoridadID
      WHERE dn.IncidenteID = p_incidente_id
      ORDER BY dn.FechaDenuncia DESC;
    RETURN rc;
  END fc_denuncias_por_incidente;

  FUNCTION fc_actuaciones_por_incidente(p_incidente_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT ac.ActuacionID, ac.TipoActuacion, ac.FechaActuacion, ac.Detalle,
             ac.AutoridadID, a.Nombre AS AutoridadNombre
      FROM Actuacion ac
      LEFT JOIN Autoridad a ON a.AutoridadID = ac.AutoridadID
      WHERE ac.IncidenteID = p_incidente_id
      ORDER BY ac.FechaActuacion DESC;
    RETURN rc;
  END fc_actuaciones_por_incidente;

  FUNCTION fc_sospechosos_por_incidente(p_incidente_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT s.SospechosoID, s.Documento, s.Alias, s.Nombres, s.Apellidos, s.Observaciones
      FROM Incidente_Sospechoso isx
      JOIN Sospechoso s ON s.SospechosoID = isx.SospechosoID
      WHERE isx.IncidenteID = p_incidente_id
      ORDER BY s.Apellidos, s.Nombres;
    RETURN rc;
  END fc_sospechosos_por_incidente;

  FUNCTION fc_procesos_por_ciudadano(p_ciudadano_id IN NUMBER) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT i.IncidenteID, i.CodigoIncidente, i.FechaIncidente, i.Severidad, i.Estado,
             d.NombreDelito, u.Localidad, u.Barrio,
             dn.NumeroDenuncia, dn.FechaDenuncia
      FROM Incidente_Ciudadano ic
      JOIN Incidente i ON i.IncidenteID = ic.IncidenteID
      LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
      LEFT JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
      LEFT JOIN Denuncia dn ON dn.IncidenteID = i.IncidenteID AND dn.CiudadanoID = p_ciudadano_id
      WHERE ic.CiudadanoID = p_ciudadano_id
      ORDER BY i.FechaIncidente DESC;
    RETURN rc;
  END fc_procesos_por_ciudadano;
END PC_ConsultarProcesosJudiciales;
/
