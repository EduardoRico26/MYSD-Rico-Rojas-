/*============================================================
POBLAR BASE DE DATOS SEGURIDAD BOGOTA
============================================================*/

BEGIN
  DBMS_RANDOM.SEED(20251216);
END;
/

BEGIN
  DELETE FROM Incidente_Sospechoso;
  DELETE FROM Incidente_Ciudadano;
  DELETE FROM Evidencia;
  DELETE FROM Denuncia;
  DELETE FROM Actuacion;
  DELETE FROM Incidente;
  DELETE FROM UnidadPolicial;
  DELETE FROM Autoridad;
  DELETE FROM Ubicacion;
  DELETE FROM Sospechoso;
  DELETE FROM Ciudadano;
  DELETE FROM Delito;
  COMMIT;
END;
/

/*============================================================
DELITOS
============================================================*/
INSERT INTO Delito VALUES (1,  'D001', 'Robo', 'Hurto de pertenencias', 'Hurto', 'Alta');
INSERT INTO Delito VALUES (2,  'D002', 'Lesiones', 'Agresion fisica', 'Violencia', 'Media');
INSERT INTO Delito VALUES (3,  'D003', 'Homicidio', 'Muerte intencional', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (4,  'D004', 'Extorsion', 'Cobro de dinero mediante amenaza', 'Delitos economicos', 'Alta');
INSERT INTO Delito VALUES (5,  'D005', 'Fraude bancario', 'Acceso indebido a cuentas', 'Delitos economicos', 'Media');
INSERT INTO Delito VALUES (6,  'D006', 'Vandalismo', 'Dano a bienes publicos', 'Dano a la propiedad', 'Media');
INSERT INTO Delito VALUES (7,  'D007', 'Amenazas', 'Intimidacion verbal o escrita', 'Violencia', 'Baja');
INSERT INTO Delito VALUES (8,  'D008', 'Hurto de vehiculo', 'Robo de automovil o motocicleta', 'Hurto', 'Alta');
INSERT INTO Delito VALUES (9,  'D009', 'Secuestro', 'Privacion ilegal de la libertad', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (10, 'D010', 'Estafa', 'Engano para obtener beneficio economico', 'Delitos economicos', 'Media');
INSERT INTO Delito VALUES (11, 'D011', 'Acoso', 'Hostigamiento reiterado', 'Violencia', 'Media');
INSERT INTO Delito VALUES (12, 'D012', 'Abuso de confianza', 'Apropiacion indebida de bienes', 'Hurto', 'Media');
INSERT INTO Delito VALUES (13, 'D013', 'Incendio', 'Provocar fuego intencional', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (14, 'D014', 'Contrabando', 'Ingreso ilegal de mercancia', 'Delitos economicos', 'Media');
INSERT INTO Delito VALUES (15, 'D015', 'Violencia intrafamiliar', 'Agresion en entorno familiar', 'Violencia', 'Alta');
INSERT INTO Delito VALUES (16, 'D016', 'Lesiones culposas', 'Dano fisico por imprudencia', 'Violencia', 'Baja');
INSERT INTO Delito VALUES (17, 'D017', 'Robo a establecimiento', 'Hurto en negocio comercial', 'Hurto', 'Alta');
INSERT INTO Delito VALUES (18, 'D018', 'Dano en propiedad privada', 'Afectacion a bienes de terceros', 'Dano a la propiedad', 'Media');
INSERT INTO Delito VALUES (19, 'D019', 'Falsificacion documental', 'Crear documentos falsos', 'Delitos economicos', 'Media');
INSERT INTO Delito VALUES (20, 'D020', 'Lavado de activos', 'Dinero de origen ilicito', 'Delitos economicos', 'Alta');
INSERT INTO Delito VALUES (21, 'D021', 'Trafico de drogas', 'Distribucion de sustancias ilegales', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (22, 'D022', 'Consumo de drogas', 'Consumo en espacio publico', 'Crimen', 'Baja');
INSERT INTO Delito VALUES (23, 'D023', 'Porte ilegal de armas', 'Portar armas sin permiso', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (24, 'D024', 'Hurtos menores', 'Pequenos robos sin violencia', 'Hurto', 'Baja');
INSERT INTO Delito VALUES (25, 'D025', 'Ciberacoso', 'Hostigamiento digital', 'Violencia', 'Media');
INSERT INTO Delito VALUES (26, 'D026', 'Ciberfraude', 'Estafas por internet', 'Delitos economicos', 'Alta');
INSERT INTO Delito VALUES (27, 'D027', 'Estafa telefonica', 'Engano via llamada', 'Delitos economicos', 'Media');
INSERT INTO Delito VALUES (28, 'D028', 'Corrupcion', 'Abuso de poder para beneficio', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (29, 'D029', 'Soborno', 'Ofrecer dinero por favores ilegales', 'Delitos economicos', 'Alta');
INSERT INTO Delito VALUES (30, 'D030', 'Lesiones con arma blanca', 'Agresion con objeto cortante', 'Violencia', 'Alta');
INSERT INTO Delito VALUES (31, 'D031', 'Lesiones con arma de fuego', 'Agresion con arma', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (32, 'D032', 'Hurto a vivienda', 'Robo en propiedad residencial', 'Hurto', 'Alta');
INSERT INTO Delito VALUES (33, 'D033', 'Delitos informaticos', 'Acceso no autorizado a sistemas', 'Delitos economicos', 'Media');
INSERT INTO Delito VALUES (34, 'D034', 'Usurpacion de identidad', 'Uso ilegal de datos de otro', 'Delitos economicos', 'Media');
INSERT INTO Delito VALUES (35, 'D035', 'Violacion de domicilio', 'Entrar a vivienda sin permiso', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (36, 'D036', 'Rina callejera', 'Pelea en espacio publico', 'Violencia', 'Media');
INSERT INTO Delito VALUES (37, 'D037', 'Exhibicionismo', 'Actos sexuales en publico', 'Crimen', 'Baja');
INSERT INTO Delito VALUES (38, 'D038', 'Actos obscenos', 'Conductas sexualmente inapropiadas', 'Crimen', 'Media');
INSERT INTO Delito VALUES (39, 'D039', 'Abandono de menor', 'Dejar sin cuidado a un nino', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (40, 'D040', 'Explotacion infantil', 'Trabajo o abuso de ninos', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (41, 'D041', 'Violencia psicologica', 'Afectacion emocional severa', 'Violencia', 'Media');
INSERT INTO Delito VALUES (42, 'D042', 'Persecucion', 'Seguimiento hostigante', 'Violencia', 'Media');
INSERT INTO Delito VALUES (43, 'D043', 'Abuso sexual', 'Afectacion sexual sin consentimiento', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (44, 'D044', 'Proxenetismo', 'Explotacion sexual ajena', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (45, 'D045', 'Alteracion del orden publico', 'Interrupcion de convivencia', 'Violencia', 'Baja');
INSERT INTO Delito VALUES (46, 'D046', 'Contaminacion ambiental', 'Afectar ilegalmente el medio ambiente', 'Crimen', 'Media');
INSERT INTO Delito VALUES (47, 'D047', 'Cohecho', 'Delito contra la administracion publica', 'Crimen', 'Alta');
INSERT INTO Delito VALUES (48, 'D048', 'Interferencia en transporte', 'Bloquear vias o transporte', 'Dano a la propiedad', 'Media');
INSERT INTO Delito VALUES (49, 'D049', 'Hurtos en transporte publico', 'Robo a pasajeros', 'Hurto', 'Alta');
INSERT INTO Delito VALUES (50, 'D050', 'Robo con intimidacion', 'Hurto con amenaza', 'Hurto', 'Alta');
INSERT INTO Delito VALUES (51, 'D051', 'Extorsion digital', 'Amenazas mediante redes', 'Delitos economicos', 'Alta');
INSERT INTO Delito VALUES (52, 'D052', 'Estafa empresarial', 'Fraude a companias', 'Delitos economicos', 'Alta');
INSERT INTO Delito VALUES (53, 'D053', 'Hurto de bicicleta', 'Robo de bicicleta', 'Hurto', 'Media');

COMMIT;

/*============================================================
AUTORIDADES
============================================================*/
INSERT INTO Autoridad VALUES (1,  'A001', 'Policia Metropolitana de Bogota', 'Policia', '3101111111', 'pm001@policia.gov.co');
INSERT INTO Autoridad VALUES (2,  'A002', 'SIJIN Bogota', 'Investigacion', '3102222222', 'sijin@policia.gov.co');
INSERT INTO Autoridad VALUES (3,  'A003', 'Fiscalia Local', 'Fiscalia', '3103333333', 'contacto@fiscalia.gov.co');
INSERT INTO Autoridad VALUES (4,  'A004', 'CTI Bogota', 'Investigacion', '3104444444', 'cti@fiscalia.gov.co');
INSERT INTO Autoridad VALUES (5,  'A005', 'Secretaria Distrital de Seguridad', 'Administrativo', '3105555555', 'seguridad@bogota.gov.co');
INSERT INTO Autoridad VALUES (6,  'A006', 'Policia de Transito Bogota', 'Transito', '3106666666', 'transito@policia.gov.co');
INSERT INTO Autoridad VALUES (7,  'A007', 'GAULA Bogota', 'Antiextorsion', '3107777777', 'gaula@policia.gov.co');
INSERT INTO Autoridad VALUES (8,  'A008', 'Defensoria del Pueblo', 'Administrativo', '3108888888', 'atencion@defensoria.gov.co');
INSERT INTO Autoridad VALUES (9,  'A009', 'Bomberos Bogota', 'Emergencias', '3109999999', 'central@bomberosbogota.gov.co');
INSERT INTO Autoridad VALUES (10, 'A010', 'Linea 123 Bogota', 'Emergencias', '3101234567', 'linea123@bogota.gov.co');

COMMIT;

/*============================================================
UNIDADES POLICIALES
============================================================*/
INSERT INTO UnidadPolicial VALUES (1,  'UP001', 'Estacion Usaquen', 'Calle 121 # 6 30', 1);
INSERT INTO UnidadPolicial VALUES (2,  'UP002', 'Estacion Chapinero', 'Carrera 13 # 60 40', 1);
INSERT INTO UnidadPolicial VALUES (3,  'UP003', 'Estacion Kennedy', 'Avenida Primero de Mayo # 70 15', 1);
INSERT INTO UnidadPolicial VALUES (4,  'UP004', 'Estacion Suba', 'Calle 145 # 98 45', 1);
INSERT INTO UnidadPolicial VALUES (5,  'UP005', 'Estacion Teusaquillo', 'Calle 45 # 20 20', 1);
INSERT INTO UnidadPolicial VALUES (6,  'UP006', 'Estacion Engativa', 'Calle 80 # 90 40', 1);
INSERT INTO UnidadPolicial VALUES (7,  'UP007', 'Estacion Fontibon', 'Calle 26 # 68 30', 1);
INSERT INTO UnidadPolicial VALUES (8,  'UP008', 'Estacion Barrios Unidos', 'Calle 72 # 15 40', 1);
INSERT INTO UnidadPolicial VALUES (9,  'UP009', 'Estacion Los Martires', 'Calle 10 # 15 80', 1);
INSERT INTO UnidadPolicial VALUES (10, 'UP010', 'Estacion Bosa', 'Calle 57 Sur # 80 15', 1);
INSERT INTO UnidadPolicial VALUES (11, 'UP011', 'CAI Santa Fe', 'Carrera 7 # 19 10', 1);
INSERT INTO UnidadPolicial VALUES (12, 'UP012', 'CAI Ciudad Bolivar', 'Calle 70 Sur # 20 10', 1);

COMMIT;

/*============================================================
UBICACIONES
Genera 120 ubicaciones con barrios y localidades de Bogota
CoordenadaLon se guarda con signo negativo usando CHR(45)
============================================================*/
DECLARE
  TYPE t_vc IS TABLE OF VARCHAR2(100);

  v_localidades t_vc := t_vc(
    'Usaquen','Chapinero','Santa Fe','San Cristobal','Usme','Tunjuelito','Bosa',
    'Kennedy','Fontibon','Engativa','Suba','Barrios Unidos','Teusaquillo',
    'Los Martires','Antonio Narino','Puente Aranda','La Candelaria',
    'Rafael Uribe Uribe','Ciudad Bolivar','Sumapaz'
  );

  v_barrios t_vc := t_vc(
    'Chico','Chico Norte','Cedritos','Santa Barbara','San Patricio','Bella Suiza',
    'Chapinero Alto','Chapinero Central','La Soledad','Galerias','Teusaquillo',
    'Centro Internacional','San Victorino','Las Cruces','Las Nieves',
    'Modelia','Hayuelos','Salitre','Ciudad Salitre','Normandia','Minuto de Dios',
    'Alamos','Villas de Granada','Bolivia','Garcés Navas','La Estrada',
    'Castilla','Marsella','Tintal','Patio Bonito','Kenndy Central','Timiza',
    'Bosa La Libertad','Bosa Centro','Porvenir','El Recreo',
    'Tibabuyes','Niza','Colina Campestre','Pinar','La Campina','La Gaitana',
    'Restrepo','Santa Isabel','Quiroga','Molinos','Villa Mayor','San Bernardo',
    'Ricaurte','Siete de Agosto','Doce de Octubre','La Castellana',
    'Ciudad Montes','Industrial','Muzu','El Tunal','20 de Julio','Ciudad Jardin',
    'Perdomo','Lucero','Meissen','Arborizadora Alta'
  );

  TYPE t_vc_short IS TABLE OF VARCHAR2(40);
  v_tipos_via t_vc_short := t_vc_short('Calle','Carrera','Avenida','Diagonal','Transversal');

  v_id NUMBER;
  v_cod VARCHAR2(20);
  v_dir VARCHAR2(150);
  v_barrio VARCHAR2(100);
  v_loc VARCHAR2(100);
  v_lat NUMBER;
  v_lon NUMBER;
BEGIN
  FOR i IN 1..120 LOOP
    v_id := i;
    v_cod := 'U' || LPAD(i,3,'0');

    v_loc := v_localidades(TRUNC(DBMS_RANDOM.VALUE(1, v_localidades.COUNT + 1)));
    v_barrio := v_barrios(TRUNC(DBMS_RANDOM.VALUE(1, v_barrios.COUNT + 1)));

    v_dir :=
      v_tipos_via(TRUNC(DBMS_RANDOM.VALUE(1, v_tipos_via.COUNT + 1))) || ' ' ||
      TO_CHAR(TRUNC(DBMS_RANDOM.VALUE(1, 181))) || ' # ' ||
      TO_CHAR(TRUNC(DBMS_RANDOM.VALUE(1, 100))) || ' ' ||
      TO_CHAR(TRUNC(DBMS_RANDOM.VALUE(1, 100)));

    v_lat := 4.56 + DBMS_RANDOM.VALUE(0, 0.22);
    v_lon := 74.02 + DBMS_RANDOM.VALUE(0, 0.22);

    INSERT INTO Ubicacion
    (UbicacionID, CodigoUbicacion, Direccion, Barrio, Localidad, CoordenadaLat, CoordenadaLon)
    VALUES
    (v_id, v_cod, v_dir, v_barrio, v_loc,
     TO_CHAR(v_lat, 'FM9D999999'),
     CHR(45) || TO_CHAR(v_lon, 'FM99D999999')
    );
  END LOOP;

  COMMIT;
END;
/

/*============================================================
CIUDADANOS
Genera 4500 ciudadanos
============================================================*/
DECLARE
  TYPE t_vc IS TABLE OF VARCHAR2(100);

  v_nombres t_vc := t_vc(
    'Juan','Maria','Carlos','Ana','Laura','Pedro','Andres','Juliana','Sofia','Miguel',
    'Camila','Daniel','Felipe','Valentina','Sebastian','David','Natalia','Paula','Sara','Santiago',
    'Jorge','Oscar','Ricardo','Manuel','Hector','Esteban','Mateo','Nicolas','Alejandro','Tatiana',
    'Carolina','Luisa','Diana','Angela','Sandra','Claudia','Catalina','Manuela','Gabriela','Isabella',
    'Kevin','Brayan','Jhon','Stiven','Yeison','Wilson','Edwin','Harold','Hernan','Ivan'
  );

  v_apellidos t_vc := t_vc(
    'Perez','Gomez','Rodriguez','Garcia','Martinez','Lopez','Hernandez','Gonzalez','Ramirez','Torres',
    'Rojas','Vargas','Diaz','Sanchez','Castro','Romero','Suarez','Moreno','Alvarez','Ruiz',
    'Jimenez','Muñoz','Herrera','Medina','Ortega','Gutierrez','Navarro','Cortes','Mendoza','Reyes',
    'Silva','Cabrera','Pineda','Valencia','Arias','Acosta','Santos','Bautista','Ospina','Fonseca'
  );

  v_nom VARCHAR2(100);
  v_ape VARCHAR2(100);
  v_tel VARCHAR2(20);
  v_cor VARCHAR2(100);
  v_dir VARCHAR2(150);
  v_ubi NUMBER;
BEGIN
  FOR i IN 1..4500 LOOP
    v_nom := v_nombres(TRUNC(DBMS_RANDOM.VALUE(1, v_nombres.COUNT + 1)));
    v_ape := v_apellidos(TRUNC(DBMS_RANDOM.VALUE(1, v_apellidos.COUNT + 1)));

    v_tel := '3' || LPAD(TRUNC(DBMS_RANDOM.VALUE(0, 1000000000)), 9, '0');

    v_cor := LOWER(REPLACE(v_nom,' ',''))
             || '.' || LOWER(REPLACE(v_ape,' ',''))
             || TO_CHAR(i) || '@mail.com';

    v_ubi := TRUNC(DBMS_RANDOM.VALUE(1, 121));
    SELECT Direccion INTO v_dir FROM Ubicacion WHERE UbicacionID = v_ubi;

    INSERT INTO Ciudadano
    (CiudadanoID, Documento, Nombres, Apellidos, Telefono, Correo, Direccion)
    VALUES
    (i, 'CC' || LPAD(i, 8, '0'), v_nom, v_ape, v_tel, v_cor, v_dir);
  END LOOP;

  COMMIT;
END;
/

/*============================================================
SOSPECHOSOS
Genera 1400 sospechosos
============================================================*/
DECLARE
  TYPE t_vc IS TABLE OF VARCHAR2(100);
  TYPE t_vc50 IS TABLE OF VARCHAR2(50);

  v_nombres t_vc := t_vc(
    'Javier','Felipe','Daniel','Camilo','Ricardo','Oscar','Mateo','Hector','Manuel','Esteban',
    'Harold','Wilson','Edwin','Ivan','Sebastian','Santiago','Nicolas','Andres','Kevin','Brayan'
  );

  v_apellidos t_vc := t_vc(
    'Lopez','Garcia','Contreras','Mejia','Uribe','Vega','Fuentes','Perez','Rico','Cespedes',
    'Castro','Diaz','Sanchez','Vargas','Romero','Suarez','Torres','Rojas','Moreno','Herrera'
  );

  v_alias t_vc50 := t_vc50(
    'El Toro','La Sombra','Rayo','El Zurdo','Mono','Flecha','Chino','Negro','Gato','Topo',
    'Lince','Cobra','Machete','Zorro','Tigre','Barbas','Trueno','Garra','Rastro','Fantasma'
  );

  v_obs t_vc := t_vc(
    'Antecedentes por hurto','Investigado por intimidacion','Relacionado con rinas',
    'Reportes en zona comercial','Vinculado a transporte publico','Sospechoso habitual',
    'Posible uso de arma blanca','Posible uso de arma de fuego','Se moviliza en motocicleta',
    'Opera en horarios nocturnos'
  );

  v_nom VARCHAR2(100);
  v_ape VARCHAR2(100);
  v_al  VARCHAR2(50);
  v_ob  VARCHAR2(300);
BEGIN
  FOR i IN 1..1400 LOOP
    v_nom := v_nombres(TRUNC(DBMS_RANDOM.VALUE(1, v_nombres.COUNT + 1)));
    v_ape := v_apellidos(TRUNC(DBMS_RANDOM.VALUE(1, v_apellidos.COUNT + 1)));
    v_al  := v_alias(TRUNC(DBMS_RANDOM.VALUE(1, v_alias.COUNT + 1)));
    v_ob  := v_obs(TRUNC(DBMS_RANDOM.VALUE(1, v_obs.COUNT + 1)));

    INSERT INTO Sospechoso
    (SospechosoID, Documento, Alias, Nombres, Apellidos, Observaciones)
    VALUES
    (i, 'SC' || LPAD(i, 8, '0'), v_al, v_nom, v_ape, v_ob);
  END LOOP;

  COMMIT;
END;
/

/*============================================================
INCIDENTES
Genera 7000 incidentes
============================================================*/
DECLARE
  v_fecha_base DATE := TO_DATE('20230101', 'YYYYMMDD');
  v_fecha DATE;
  v_sev VARCHAR2(10);
  v_est VARCHAR2(12);
  v_del NUMBER;
  v_ubi NUMBER;

  v_del_nom VARCHAR2(100);
  v_barrio VARCHAR2(100);
  v_loc VARCHAR2(100);

  v_desc VARCHAR2(500);

  FUNCTION pick_severidad RETURN VARCHAR2 IS
    r NUMBER;
  BEGIN
    r := DBMS_RANDOM.VALUE(0, 1);
    IF r < 0.25 THEN
      RETURN 'Alta';
    ELSIF r < 0.70 THEN
      RETURN 'Media';
    ELSE
      RETURN 'Baja';
    END IF;
  END;

  FUNCTION pick_estado RETURN VARCHAR2 IS
    r NUMBER;
  BEGIN
    r := DBMS_RANDOM.VALUE(0, 1);
    IF r < 0.35 THEN
      RETURN 'Abierto';
    ELSIF r < 0.75 THEN
      RETURN 'En proceso';
    ELSE
      RETURN 'Cerrado';
    END IF;
  END;
BEGIN
  FOR i IN 1..7000 LOOP
    v_fecha := v_fecha_base + TRUNC(DBMS_RANDOM.VALUE(0, 1095));
    v_sev := pick_severidad;
    v_est := pick_estado;

    v_del := TRUNC(DBMS_RANDOM.VALUE(1, 54));
    v_ubi := TRUNC(DBMS_RANDOM.VALUE(1, 121));

    SELECT NombreDelito INTO v_del_nom FROM Delito WHERE DelitoID = v_del;
    SELECT Barrio, Localidad INTO v_barrio, v_loc FROM Ubicacion WHERE UbicacionID = v_ubi;

    v_desc :=
      'Reporte en Bogota. ' || v_del_nom ||
      '. Barrio ' || NVL(v_barrio,'Sin dato') ||
      '. Localidad ' || NVL(v_loc,'Sin dato') ||
      '. Se solicita atencion de autoridad competente.';

    INSERT INTO Incidente
    (IncidenteID, CodigoIncidente, FechaIncidente, Descripcion, Severidad, Estado, DelitoID, UbicacionID)
    VALUES
    (i, 'I' || LPAD(i, 6, '0'), v_fecha, v_desc, v_sev, v_est, v_del, v_ubi);
  END LOOP;

  COMMIT;
END;
/

/*============================================================
PUENTE INCIDENTE CIUDADANO
Asigna 1 o 2 ciudadanos por incidente
============================================================*/
DECLARE
  v_c1 NUMBER;
  v_c2 NUMBER;
BEGIN
  FOR i IN 1..7000 LOOP
    v_c1 := TRUNC(DBMS_RANDOM.VALUE(1, 4501));
    INSERT INTO Incidente_Ciudadano (IncidenteID, CiudadanoID) VALUES (i, v_c1);

    IF DBMS_RANDOM.VALUE(0, 1) < 0.35 THEN
      v_c2 := TRUNC(DBMS_RANDOM.VALUE(1, 4501));
      IF v_c2 = v_c1 THEN
        v_c2 := v_c2 + 1;
        IF v_c2 > 4500 THEN
          v_c2 := 1;
        END IF;
      END IF;
      INSERT INTO Incidente_Ciudadano (IncidenteID, CiudadanoID) VALUES (i, v_c2);
    END IF;
  END LOOP;

  COMMIT;
END;
/

/*============================================================
PUENTE INCIDENTE SOSPECHOSO
Asigna sospechoso a parte de los incidentes
============================================================*/
DECLARE
  v_s1 NUMBER;
BEGIN
  FOR i IN 1..7000 LOOP
    IF DBMS_RANDOM.VALUE(0, 1) < 0.40 THEN
      v_s1 := TRUNC(DBMS_RANDOM.VALUE(1, 1401));
      INSERT INTO Incidente_Sospechoso (IncidenteID, SospechosoID) VALUES (i, v_s1);
    END IF;
  END LOOP;

  COMMIT;
END;
/

/*============================================================
ACTUACIONES
Genera entre 1 y 3 actuaciones por incidente
============================================================*/
DECLARE
  v_act_id NUMBER := 0;
  v_cnt NUMBER;
  v_aut NUMBER;
  v_fecha_inc DATE;
  v_fecha_act DATE;
  v_tipo VARCHAR2(80);
  v_det VARCHAR2(400);

  FUNCTION pick_tipo(n NUMBER) RETURN VARCHAR2 IS
  BEGIN
    IF n = 1 THEN RETURN 'Registro del incidente'; END IF;
    IF n = 2 THEN RETURN 'Inspeccion del lugar'; END IF;
    IF n = 3 THEN RETURN 'Revision de camaras'; END IF;
    IF n = 4 THEN RETURN 'Entrevista a ciudadanos'; END IF;
    IF n = 5 THEN RETURN 'Patrullaje reforzado'; END IF;
    IF n = 6 THEN RETURN 'Remision a Fiscalia'; END IF;
    IF n = 7 THEN RETURN 'Captura en operacion'; END IF;
    IF n = 8 THEN RETURN 'Verificacion de evidencias'; END IF;
    RETURN 'Seguimiento del caso';
  END;
BEGIN
  FOR i IN 1..7000 LOOP
    SELECT FechaIncidente INTO v_fecha_inc FROM Incidente WHERE IncidenteID = i;

    v_cnt := TRUNC(DBMS_RANDOM.VALUE(1, 4));

    FOR j IN 1..v_cnt LOOP
      v_act_id := v_act_id + 1;
      v_aut := TRUNC(DBMS_RANDOM.VALUE(1, 11));
      v_fecha_act := v_fecha_inc + TRUNC(DBMS_RANDOM.VALUE(0, 11));

      v_tipo := pick_tipo(TRUNC(DBMS_RANDOM.VALUE(1, 10)));
      v_det := 'Actuacion registrada en Bogota para el incidente ' || 'I' || LPAD(i, 6, '0') || '.';

      INSERT INTO Actuacion
      (ActuacionID, TipoActuacion, FechaActuacion, Detalle, AutoridadID, IncidenteID)
      VALUES
      (v_act_id, v_tipo, v_fecha_act, v_det, v_aut, i);
    END LOOP;
  END LOOP;

  COMMIT;
END;
/

/*============================================================
DENUNCIAS
Genera denuncias para parte de los incidentes
============================================================*/
DECLARE
  v_den_id NUMBER := 0;
  v_ciu NUMBER;
  v_aut NUMBER;
  v_fecha_inc DATE;
  v_fecha_den DATE;
  v_det VARCHAR2(400);
BEGIN
  FOR i IN 1..7000 LOOP
    IF DBMS_RANDOM.VALUE(0, 1) < 0.70 THEN
      v_den_id := v_den_id + 1;

      SELECT FechaIncidente INTO v_fecha_inc FROM Incidente WHERE IncidenteID = i;

      v_ciu := TRUNC(DBMS_RANDOM.VALUE(1, 4501));
      v_aut := TRUNC(DBMS_RANDOM.VALUE(1, 11));
      v_fecha_den := v_fecha_inc + TRUNC(DBMS_RANDOM.VALUE(0, 6));

      v_det := 'Denuncia formal asociada al incidente ' || 'I' || LPAD(i, 6, '0') || ' en Bogota.';

      INSERT INTO Denuncia
      (DenunciaID, NumeroDenuncia, FechaDenuncia, Detalle, CiudadanoID, AutoridadID, IncidenteID)
      VALUES
      (v_den_id, 'DN' || LPAD(v_den_id, 6, '0'), v_fecha_den, v_det, v_ciu, v_aut, i);
    END IF;
  END LOOP;

  COMMIT;
END;
/

/*============================================================
EVIDENCIAS
Genera evidencias asociadas a ciudadanos
============================================================*/
DECLARE
  v_evi_id NUMBER := 0;
  v_ciu NUMBER;
  v_tipo VARCHAR2(80);
  v_desc VARCHAR2(400);
  v_fecha DATE;

  FUNCTION pick_tipo RETURN VARCHAR2 IS
    r NUMBER;
  BEGIN
    r := DBMS_RANDOM.VALUE(0, 1);
    IF r < 0.18 THEN RETURN 'Video'; END IF;
    IF r < 0.36 THEN RETURN 'Fotografia'; END IF;
    IF r < 0.52 THEN RETURN 'Testimonio'; END IF;
    IF r < 0.68 THEN RETURN 'Documento'; END IF;
    IF r < 0.84 THEN RETURN 'Audio'; END IF;
    RETURN 'Objeto recuperado';
  END;
BEGIN
  FOR i IN 1..6500 LOOP
    v_evi_id := v_evi_id + 1;
    v_ciu := TRUNC(DBMS_RANDOM.VALUE(1, 4501));
    v_tipo := pick_tipo;

    v_fecha := TO_DATE('20230101', 'YYYYMMDD') + TRUNC(DBMS_RANDOM.VALUE(0, 1095));

    v_desc := 'Evidencia registrada en Bogota para soporte de investigacion.';

    INSERT INTO Evidencia
    (EvidenciaID, TipoEvidencia, Descripcion, FechaRegistro, CiudadanoID)
    VALUES
    (v_evi_id, v_tipo, v_desc, v_fecha, v_ciu);
  END LOOP;

  COMMIT;
END;
/

/*============================================================
VERIFICAR POBLAR
============================================================*/
SELECT COUNT(*) AS c_incidentes FROM Incidente;
SELECT COUNT(*) AS c_ubicaciones FROM Ubicacion;
SELECT COUNT(*) AS c_delitos FROM Delito;
SELECT COUNT(*) AS c_ciudadanos FROM Ciudadano;
SELECT COUNT(*) AS c_sospechosos FROM Sospechoso;
SELECT COUNT(*) AS c_autoridades FROM Autoridad;
SELECT COUNT(*) AS c_unidades_policiales FROM UnidadPolicial;
SELECT COUNT(*) AS c_actuaciones FROM Actuacion;
SELECT COUNT(*) AS c_denuncias FROM Denuncia;
SELECT COUNT(*) AS c_evidencias FROM Evidencia;

SELECT COUNT(*) AS c_incidente_ciudadano FROM Incidente_Ciudadano;
SELECT COUNT(*) AS c_incidente_sospechoso FROM Incidente_Sospechoso;

COMMIT;
