/*=============================================
POBLAR NO OK
============================================= */

-- ERROR: Código de delito duplicado (viola UNIQUE)
INSERT INTO Delito VALUES (4, 'D001', 'Hurto simple', 'Duplicado de código', 'Hurto', 'Baja');

-- ERROR: Estado inválido (no está en el CHECK)
INSERT INTO Incidente VALUES (4, 'I004', TO_DATE('2025-03-10','YYYY-MM-DD'), 'Caso extraño', 'Media', 'Suspendido', 1, 1);

-- ERROR: Clave foránea inválida (no existe DelitoID = 99)
INSERT INTO Incidente VALUES (5, 'I005', TO_DATE('2025-03-11','YYYY-MM-DD'), 'Delito inexistente', 'Alta', 'Abierto', 99, 1);