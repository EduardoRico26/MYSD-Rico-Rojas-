/*============================================================
SIMULACIONES DE INGRESO DE DATOS CORRECTOS
Usando procedimientos de los paquetes creados
Registros nuevos calculando IDs con MAX + 1
============================================================*/

/* Ejemplo 1 Reporte de hurto de celular en Chapinero */
DECLARE
  v_autoridad_id  NUMBER;
  v_delito_id     NUMBER;
  v_ubicacion_id  NUMBER;
  v_ciudadano_id  NUMBER;
  v_sospechoso_id NUMBER;
  v_incidente_id  NUMBER;
  v_evidencia_id  NUMBER;

  v_cod_autoridad VARCHAR2(20);
  v_cod_delito    VARCHAR2(20);
  v_cod_ubicacion VARCHAR2(20);
  v_cod_incidente VARCHAR2(20);
BEGIN
  SELECT NVL(MAX(AutoridadID),0) + 1 INTO v_autoridad_id FROM Autoridad;
  SELECT NVL(MAX(DelitoID),0) + 1 INTO v_delito_id FROM Delito;
  SELECT NVL(MAX(UbicacionID),0) + 1 INTO v_ubicacion_id FROM Ubicacion;
  SELECT NVL(MAX(CiudadanoID),0) + 1 INTO v_ciudadano_id FROM Ciudadano;
  SELECT NVL(MAX(SospechosoID),0) + 1 INTO v_sospechoso_id FROM Sospechoso;
  SELECT NVL(MAX(IncidenteID),0) + 1 INTO v_incidente_id FROM Incidente;
  SELECT NVL(MAX(EvidenciaID),0) + 1 INTO v_evidencia_id FROM Evidencia;

  v_cod_autoridad := 'A' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISSFF3');
  v_cod_delito    := 'D' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISSFF3');
  v_cod_ubicacion := 'U' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISSFF3');
  v_cod_incidente := 'I' || LPAD(TO_CHAR(v_incidente_id),5,'0');

  PC_MantenerAutoridad.ad_autoridad(
    v_autoridad_id, v_cod_autoridad, 'Policia Metropolitana de Bogota', 'Policia', '6011234520', 'pm_bogota20@policia.gov'
  );

  PC_MantenerDelito.ad_delito(
    v_delito_id, v_cod_delito, 'Hurto de celular', 'Hurto de telefono movil en via publica', 'Hurto', 'Alta'
  );

  PC_MantenerUbicacion.ad_ubicacion(
    v_ubicacion_id, v_cod_ubicacion, 'Carrera 11 72 18', 'Chapinero Alto', 'Chapinero', '4.6580', '74.0610W'
  );

  PC_MantenerCiudadano.ad_ciudadano(
    v_ciudadano_id, 'CC' || LPAD(TO_CHAR(v_ciudadano_id),8,'0'),
    'Manuela', 'Castillo Rojas', '3007200101', 'manuela.castillo@mail.com', 'Carrera 11 72 18'
  );

  PC_MantenerSospechoso.ad_sospechoso(
    v_sospechoso_id, 'SC' || LPAD(TO_CHAR(v_sospechoso_id),8,'0'),
    'El Veloz', 'Jeison', 'Patiño', 'Reportado por hurtos rapidos en zonas de rumba'
  );

  PC_RegistrarIncidente.ad_incidente(
    v_incidente_id, v_cod_incidente, DATE '2025-03-12',
    'Hurto de celular en andenes concurridos, la victima reporta distraccion y fuga',
    'Alta', 'Abierto', v_delito_id, v_ubicacion_id
  );

  PC_RegistrarIncidente.ad_incidente_ciudadano(v_incidente_id, v_ciudadano_id);
  PC_RegistrarIncidente.ad_incidente_sospechoso(v_incidente_id, v_sospechoso_id);

  PC_RegistrarEvidencia.ad_evidencia(
    v_evidencia_id, 'Video', 'Camara de seguridad de local cercano, se observa al presunto responsable',
    DATE '2025-03-12', v_ciudadano_id
  );

  COMMIT;
END;
/

/* Ejemplo 2 Vandalismo en Suba con sospechoso identificado */
DECLARE
  v_delito_id     NUMBER;
  v_ubicacion_id  NUMBER;
  v_ciudadano_id  NUMBER;
  v_sospechoso_id NUMBER;
  v_incidente_id  NUMBER;
  v_evidencia_id  NUMBER;

  v_cod_delito    VARCHAR2(20);
  v_cod_ubicacion VARCHAR2(20);
  v_cod_incidente VARCHAR2(20);
BEGIN
  SELECT NVL(MAX(DelitoID),0) + 1 INTO v_delito_id FROM Delito;
  SELECT NVL(MAX(UbicacionID),0) + 1 INTO v_ubicacion_id FROM Ubicacion;
  SELECT NVL(MAX(CiudadanoID),0) + 1 INTO v_ciudadano_id FROM Ciudadano;
  SELECT NVL(MAX(SospechosoID),0) + 1 INTO v_sospechoso_id FROM Sospechoso;
  SELECT NVL(MAX(IncidenteID),0) + 1 INTO v_incidente_id FROM Incidente;
  SELECT NVL(MAX(EvidenciaID),0) + 1 INTO v_evidencia_id FROM Evidencia;

  v_cod_delito    := 'D' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISSFF3');
  v_cod_ubicacion := 'U' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISSFF3');
  v_cod_incidente := 'I' || LPAD(TO_CHAR(v_incidente_id),5,'0');

  PC_MantenerDelito.ad_delito(
    v_delito_id, v_cod_delito, 'Vandalismo', 'Daño a paradero y mobiliario urbano', 'Daño a la propiedad', 'Media'
  );

  PC_MantenerUbicacion.ad_ubicacion(
    v_ubicacion_id, v_cod_ubicacion, 'Calle 145 91 22', 'Compartir', 'Suba', '4.7585', '74.0935W'
  );

  PC_MantenerCiudadano.ad_ciudadano(
    v_ciudadano_id, 'CC' || LPAD(TO_CHAR(v_ciudadano_id),8,'0'),
    'Sebastian', 'Quintero Medina', '3007210202', 'sebastian.quintero@mail.com', 'Calle 145 91 22'
  );

  PC_MantenerSospechoso.ad_sospechoso(
    v_sospechoso_id, 'SC' || LPAD(TO_CHAR(v_sospechoso_id),8,'0'),
    'Tizon', 'Cristian', 'Bermudez', 'Se observa con pintura en aerosol y guantes en video'
  );

  PC_RegistrarIncidente.ad_incidente(
    v_incidente_id, v_cod_incidente, DATE '2025-04-07',
    'Paradero con rayones y pintura fresca, vecinos reportan actividad nocturna',
    'Media', 'En proceso', v_delito_id, v_ubicacion_id
  );

  PC_RegistrarIncidente.ad_incidente_ciudadano(v_incidente_id, v_ciudadano_id);
  PC_RegistrarIncidente.ad_incidente_sospechoso(v_incidente_id, v_sospechoso_id);

  PC_RegistrarEvidencia.ad_evidencia(
    v_evidencia_id, 'Fotografia', 'Registro fotografico del daño y del grafiti con fecha del celular',
    DATE '2025-04-07', v_ciudadano_id
  );

  COMMIT;
END;
/

/* Ejemplo 3 Violencia intrafamiliar en Bosa */
DECLARE
  v_delito_id     NUMBER;
  v_ubicacion_id  NUMBER;
  v_ciudadano_id  NUMBER;
  v_sospechoso_id NUMBER;
  v_incidente_id  NUMBER;
  v_evidencia_id  NUMBER;

  v_cod_delito    VARCHAR2(20);
  v_cod_ubicacion VARCHAR2(20);
  v_cod_incidente VARCHAR2(20);
BEGIN
  SELECT NVL(MAX(DelitoID),0) + 1 INTO v_delito_id FROM Delito;
  SELECT NVL(MAX(UbicacionID),0) + 1 INTO v_ubicacion_id FROM Ubicacion;
  SELECT NVL(MAX(CiudadanoID),0) + 1 INTO v_ciudadano_id FROM Ciudadano;
  SELECT NVL(MAX(SospechosoID),0) + 1 INTO v_sospechoso_id FROM Sospechoso;
  SELECT NVL(MAX(IncidenteID),0) + 1 INTO v_incidente_id FROM Incidente;
  SELECT NVL(MAX(EvidenciaID),0) + 1 INTO v_evidencia_id FROM Evidencia;

  v_cod_delito    := 'D' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISSFF3');
  v_cod_ubicacion := 'U' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISSFF3');
  v_cod_incidente := 'I' || LPAD(TO_CHAR(v_incidente_id),5,'0');

  PC_MantenerDelito.ad_delito(
    v_delito_id, v_cod_delito, 'Violencia intrafamiliar', 'Agresion en entorno familiar reportada por vecinos', 'Violencia', 'Alta'
  );

  PC_MantenerUbicacion.ad_ubicacion(
    v_ubicacion_id, v_cod_ubicacion, 'Carrera 100 64 Sur 10', 'El Porvenir', 'Bosa', '4.5882', '74.2020W'
  );

  PC_MantenerCiudadano.ad_ciudadano(
    v_ciudadano_id, 'CC' || LPAD(TO_CHAR(v_ciudadano_id),8,'0'),
    'Yuliana', 'Buitrago Parra', '3007220303', 'yuliana.buitrago@mail.com', 'Carrera 100 64 Sur 10'
  );

  PC_MantenerSospechoso.ad_sospechoso(
    v_sospechoso_id, 'SC' || LPAD(TO_CHAR(v_sospechoso_id),8,'0'),
    'El Duro', 'Harold', 'Chaparro', 'Mencionado en llamadas previas por comportamiento agresivo'
  );

  PC_RegistrarIncidente.ad_incidente(
    v_incidente_id, v_cod_incidente, DATE '2025-05-02',
    'Vecinos reportan gritos y golpes, patrulla realiza verificacion en vivienda',
    'Alta', 'Abierto', v_delito_id, v_ubicacion_id
  );

  PC_RegistrarIncidente.ad_incidente_ciudadano(v_incidente_id, v_ciudadano_id);
  PC_RegistrarIncidente.ad_incidente_sospechoso(v_incidente_id, v_sospechoso_id);

  PC_RegistrarEvidencia.ad_evidencia(
    v_evidencia_id, 'Audio', 'Audio aportado por vecino donde se escuchan amenazas y forcejeo',
    DATE '2025-05-02', v_ciudadano_id
  );

  COMMIT;
END;
/

/* Ejemplo 4 Ciberfraude con evidencia digital, ubicacion en Usaquen */
DECLARE
  v_delito_id     NUMBER;
  v_ubicacion_id  NUMBER;
  v_ciudadano_id  NUMBER;
  v_incidente_id  NUMBER;
  v_evidencia_id1 NUMBER;
  v_evidencia_id2 NUMBER;

  v_cod_delito    VARCHAR2(20);
  v_cod_ubicacion VARCHAR2(20);
  v_cod_incidente VARCHAR2(20);
BEGIN
  SELECT NVL(MAX(DelitoID),0) + 1 INTO v_delito_id FROM Delito;
  SELECT NVL(MAX(UbicacionID),0) + 1 INTO v_ubicacion_id FROM Ubicacion;
  SELECT NVL(MAX(CiudadanoID),0) + 1 INTO v_ciudadano_id FROM Ciudadano;
  SELECT NVL(MAX(IncidenteID),0) + 1 INTO v_incidente_id FROM Incidente;

  SELECT NVL(MAX(EvidenciaID),0) + 1 INTO v_evidencia_id1 FROM Evidencia;
  v_evidencia_id2 := v_evidencia_id1 + 1;

  v_cod_delito    := 'D' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISSFF3');
  v_cod_ubicacion := 'U' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISSFF3');
  v_cod_incidente := 'I' || LPAD(TO_CHAR(v_incidente_id),5,'0');

  PC_MantenerDelito.ad_delito(
    v_delito_id, v_cod_delito, 'Ciberfraude', 'Suplantacion y transacciones no autorizadas por mensajeria', 'Delitos economicos', 'Alta'
  );

  PC_MantenerUbicacion.ad_ubicacion(
    v_ubicacion_id, v_cod_ubicacion, 'Calle 127 19 36', 'Santa Barbara', 'Usaquen', '4.7055', '74.0335W'
  );

  PC_MantenerCiudadano.ad_ciudadano(
    v_ciudadano_id, 'CC' || LPAD(TO_CHAR(v_ciudadano_id),8,'0'),
    'Felipe', 'Navarro Peña', '3007230404', 'felipe.navarro@mail.com', 'Calle 127 19 36'
  );

  PC_RegistrarIncidente.ad_incidente(
    v_incidente_id, v_cod_incidente, DATE '2025-06-18',
    'Transferencias no autorizadas luego de abrir enlace falso, se reporta suplantacion de soporte',
    'Alta', 'En proceso', v_delito_id, v_ubicacion_id
  );

  PC_RegistrarIncidente.ad_incidente_ciudadano(v_incidente_id, v_ciudadano_id);

  PC_RegistrarEvidencia.ad_evidencia(
    v_evidencia_id1, 'Documento', 'Extractos bancarios y comprobantes asociados al evento',
    DATE '2025-06-18', v_ciudadano_id
  );

  PC_RegistrarEvidencia.ad_evidencia(
    v_evidencia_id2, 'Captura', 'Capturas del chat, del enlace y del perfil usado para suplantacion',
    DATE '2025-06-18', v_ciudadano_id
  );

  COMMIT;
END;
/

/* Ejemplo 5 Hurto de bicicleta en Teusaquillo con victima y testigo, sospechoso vinculado */
DECLARE
  v_delito_id      NUMBER;
  v_ubicacion_id   NUMBER;
  v_ciudadano_id1  NUMBER;
  v_ciudadano_id2  NUMBER;
  v_sospechoso_id  NUMBER;
  v_incidente_id   NUMBER;
  v_evidencia_id   NUMBER;

  v_cod_delito     VARCHAR2(20);
  v_cod_ubicacion  VARCHAR2(20);
  v_cod_incidente  VARCHAR2(20);
BEGIN
  SELECT NVL(MAX(DelitoID),0) + 1 INTO v_delito_id FROM Delito;
  SELECT NVL(MAX(UbicacionID),0) + 1 INTO v_ubicacion_id FROM Ubicacion;

  SELECT NVL(MAX(CiudadanoID),0) + 1 INTO v_ciudadano_id1 FROM Ciudadano;
  v_ciudadano_id2 := v_ciudadano_id1 + 1;

  SELECT NVL(MAX(SospechosoID),0) + 1 INTO v_sospechoso_id FROM Sospechoso;
  SELECT NVL(MAX(IncidenteID),0) + 1 INTO v_incidente_id FROM Incidente;
  SELECT NVL(MAX(EvidenciaID),0) + 1 INTO v_evidencia_id FROM Evidencia;

  v_cod_delito    := 'D' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISSFF3');
  v_cod_ubicacion := 'U' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISSFF3');
  v_cod_incidente := 'I' || LPAD(TO_CHAR(v_incidente_id),5,'0');

  PC_MantenerDelito.ad_delito(
    v_delito_id, v_cod_delito, 'Hurto de bicicleta', 'Robo de bicicleta en parque y huida por via secundaria', 'Hurto', 'Media'
  );

  PC_MantenerUbicacion.ad_ubicacion(
    v_ubicacion_id, v_cod_ubicacion, 'Calle 39 26 08', 'La Soledad', 'Teusaquillo', '4.6398', '74.0745W'
  );

  PC_MantenerCiudadano.ad_ciudadano(
    v_ciudadano_id1, 'CC' || LPAD(TO_CHAR(v_ciudadano_id1),8,'0'),
    'Natalia', 'Mendoza Ruiz', '3007240505', 'natalia.mendoza@mail.com', 'Calle 39 26 08'
  );

  PC_MantenerCiudadano.ad_ciudadano(
    v_ciudadano_id2, 'CC' || LPAD(TO_CHAR(v_ciudadano_id2),8,'0'),
    'Juan', 'Esteban Salazar', '3007240606', 'juan.salazar@mail.com', 'Calle 39 26 10'
  );

  PC_MantenerSospechoso.ad_sospechoso(
    v_sospechoso_id, 'SC' || LPAD(TO_CHAR(v_sospechoso_id),8,'0'),
    'Rueda', 'Brayan', 'Cortes', 'Coincide con descripcion, visto rondando el parque dias antes'
  );

  PC_RegistrarIncidente.ad_incidente(
    v_incidente_id, v_cod_incidente, DATE '2025-07-09',
    'Hurto de bicicleta en zona de parque, testigo indica ruta de escape y caracteristicas del sospechoso',
    'Media', 'Abierto', v_delito_id, v_ubicacion_id
  );

  PC_RegistrarIncidente.ad_incidente_ciudadano(v_incidente_id, v_ciudadano_id1);
  PC_RegistrarIncidente.ad_incidente_ciudadano(v_incidente_id, v_ciudadano_id2);
  PC_RegistrarIncidente.ad_incidente_sospechoso(v_incidente_id, v_sospechoso_id);

  PC_RegistrarEvidencia.ad_evidencia(
    v_evidencia_id, 'Testimonio', 'Declaracion del testigo con descripcion del sujeto y hora aproximada',
    DATE '2025-07-09', v_ciudadano_id2
  );

  COMMIT;
END;
/

