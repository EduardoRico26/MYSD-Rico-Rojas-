/*============================================================
ELIMINAR PAQUETES CREADOS
Elimina especificacion y cuerpo
============================================================*/

DROP PACKAGE PC_MantenerAutoridad;
DROP PACKAGE PC_MantenerCiudadano;
DROP PACKAGE PC_MantenerSospechoso;
DROP PACKAGE PC_MantenerDelito;
DROP PACKAGE PC_MantenerUbicacion;
DROP PACKAGE PC_RegistrarIncidente;
DROP PACKAGE PC_ConsultarIncidentes;
DROP PACKAGE PC_RegistrarEvidencia;
DROP PACKAGE PC_ConsultarProcesosJudiciales;


SELECT object_name, object_type 
FROM user_objects
WHERE object_type IN ('PACKAGE', 'PACKAGE BODY');
