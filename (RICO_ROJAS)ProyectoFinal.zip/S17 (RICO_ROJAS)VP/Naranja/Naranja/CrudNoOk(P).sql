/*============================================================
    CRUDNOOK
============================================================*/

/* Ejemplo 1
Operador registra un ciudadano nuevo pero repite un Documento ya existente
Debe fallar por restriccion unica uq_ciudadano_documento */
DECLARE
  v_ciudadano_id NUMBER;
BEGIN
  SELECT NVL(MAX(CiudadanoID),0) + 1 INTO v_ciudadano_id FROM Ciudadano;

  PC_MantenerCiudadano.ad_ciudadano(
    v_ciudadano_id,
    'CC10000001',
    'Juliana',
    'Pineda Torres',
    '3008001111',
    'juliana.pineda@mail.com',
    'Calle 147 54 20'
  );

  COMMIT;
END;
/

/* Ejemplo 2
Registro de incidente con severidad mal diligenciada en el formulario
Debe fallar por chk_incidente_severidad */
DECLARE
  v_incidente_id NUMBER;
  v_codigo       VARCHAR2(20);
BEGIN
  SELECT NVL(MAX(IncidenteID),0) + 1 INTO v_incidente_id FROM Incidente;
  v_codigo := 'I' || LPAD(TO_CHAR(v_incidente_id),5,'0');

  PC_RegistrarIncidente.ad_incidente(
    v_incidente_id,
    v_codigo,
    TO_DATE('20251011','YYYYMMDD'),
    'Atraco reportado en zona comercial, se diligencio severidad como Critica',
    'Critica',
    'Abierto',
    1,
    1
  );

  COMMIT;
END;
/

/* Ejemplo 3
Registro de incidente con DelitoID inexistente por error al digitar el codigo interno
Debe fallar por fk_incidente_delito */
DECLARE
  v_incidente_id NUMBER;
  v_codigo       VARCHAR2(20);
BEGIN
  SELECT NVL(MAX(IncidenteID),0) + 1 INTO v_incidente_id FROM Incidente;
  v_codigo := 'I' || LPAD(TO_CHAR(v_incidente_id),5,'0');

  PC_RegistrarIncidente.ad_incidente(
    v_incidente_id,
    v_codigo,
    TO_DATE('20251103','YYYYMMDD'),
    'Se intenta registrar el caso, pero el delito referenciado no existe en el catalogo',
    'Media',
    'Abierto',
    999999,
    1
  );

  COMMIT;
END;
/

