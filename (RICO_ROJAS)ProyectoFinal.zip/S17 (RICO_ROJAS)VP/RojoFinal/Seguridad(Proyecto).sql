/*============================================================
Seguridad
Definicion de roles y permisos
============================================================*/

/* Creacion de roles */
CREATE ROLE ROL_OPERADOR;
CREATE ROLE ROL_CIUDADANO;

/*============================================================
Permisos ROL_OPERADOR
Puede registrar y gestionar informacion operativa
============================================================*/
GRANT SELECT ON Autoridad TO ROL_OPERADOR;
GRANT SELECT ON Delito TO ROL_OPERADOR;
GRANT SELECT ON Ubicacion TO ROL_OPERADOR;

GRANT INSERT, UPDATE, SELECT ON Ciudadano TO ROL_OPERADOR;
GRANT INSERT, UPDATE, SELECT ON Sospechoso TO ROL_OPERADOR;
GRANT INSERT, UPDATE, SELECT ON Incidente TO ROL_OPERADOR;
GRANT INSERT, UPDATE, SELECT ON Evidencia TO ROL_OPERADOR;
GRANT INSERT, UPDATE, SELECT ON Denuncia TO ROL_OPERADOR;
GRANT INSERT, UPDATE, SELECT ON Actuacion TO ROL_OPERADOR;
GRANT INSERT, SELECT ON Incidente_Ciudadano TO ROL_OPERADOR;
GRANT INSERT, SELECT ON Incidente_Sospechoso TO ROL_OPERADOR;

GRANT EXECUTE ON PA_OPERADOR TO ROL_OPERADOR;

/*============================================================
Permisos ROL_CIUDADANO
Solo puede registrar su perfil y consultar su informacion
============================================================*/
GRANT SELECT ON Ciudadano TO ROL_CIUDADANO;
GRANT UPDATE(Telefono, Correo, Direccion) ON Ciudadano TO ROL_CIUDADANO;

GRANT SELECT ON Incidente TO ROL_CIUDADANO;
GRANT SELECT ON Incidente_Ciudadano TO ROL_CIUDADANO;
GRANT SELECT ON Delito TO ROL_CIUDADANO;
GRANT SELECT ON Ubicacion TO ROL_CIUDADANO;
GRANT SELECT ON Evidencia TO ROL_CIUDADANO;

GRANT SELECT ON vw_resumen_proceso_incidente TO ROL_CIUDADANO;

GRANT EXECUTE ON PA_CIUDADANO TO ROL_CIUDADANO;

