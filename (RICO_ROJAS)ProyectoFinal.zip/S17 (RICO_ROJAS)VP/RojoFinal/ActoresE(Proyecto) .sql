/*============================================================
ActoresE
============================================================*/

/*============================================================
PA_OPERADOR
============================================================*/
CREATE OR REPLACE PACKAGE PA_OPERADOR AS

  PROCEDURE ad_autoridad(
    p_autoridad_id IN NUMBER,
    p_codigo       IN VARCHAR2,
    p_nombre       IN VARCHAR2,
    p_tipo         IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2
  );

  PROCEDURE ad_delito(
    p_delito_id   IN NUMBER,
    p_codigo      IN VARCHAR2,
    p_nombre      IN VARCHAR2,
    p_descripcion IN VARCHAR2,
    p_categoria   IN VARCHAR2,
    p_gravedad    IN VARCHAR2
  );

  PROCEDURE ad_ubicacion(
    p_ubicacion_id IN NUMBER,
    p_codigo       IN VARCHAR2,
    p_direccion    IN VARCHAR2,
    p_barrio       IN VARCHAR2,
    p_localidad    IN VARCHAR2,
    p_lat          IN VARCHAR2,
    p_lon          IN VARCHAR2
  );

  PROCEDURE ad_ciudadano(
    p_ciudadano_id IN NUMBER,
    p_documento    IN VARCHAR2,
    p_nombres      IN VARCHAR2,
    p_apellidos    IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2,
    p_direccion    IN VARCHAR2
  );

  PROCEDURE ad_sospechoso(
    p_sospechoso_id IN NUMBER,
    p_documento     IN VARCHAR2,
    p_alias         IN VARCHAR2,
    p_nombres       IN VARCHAR2,
    p_apellidos     IN VARCHAR2,
    p_observaciones IN VARCHAR2
  );

  PROCEDURE ad_incidente(
    p_incidente_id IN NUMBER,
    p_codigo       IN VARCHAR2,
    p_fecha        IN DATE,
    p_descripcion  IN VARCHAR2,
    p_severidad    IN VARCHAR2,
    p_estado       IN VARCHAR2,
    p_delito_id    IN NUMBER,
    p_ubicacion_id IN NUMBER
  );

  PROCEDURE vincular_ciudadano_incidente(
    p_incidente_id IN NUMBER,
    p_ciudadano_id IN NUMBER
  );

  PROCEDURE vincular_sospechoso_incidente(
    p_incidente_id  IN NUMBER,
    p_sospechoso_id IN NUMBER
  );

  PROCEDURE ad_evidencia(
    p_evidencia_id   IN NUMBER,
    p_tipo           IN VARCHAR2,
    p_descripcion    IN VARCHAR2,
    p_fecha_registro IN DATE,
    p_ciudadano_id   IN NUMBER
  );

  PROCEDURE ad_denuncia(
    p_denuncia_id     IN NUMBER,
    p_numero_denuncia IN VARCHAR2,
    p_fecha_denuncia  IN DATE,
    p_detalle         IN VARCHAR2,
    p_ciudadano_id    IN NUMBER,
    p_autoridad_id    IN NUMBER,
    p_incidente_id    IN NUMBER
  );

  PROCEDURE ad_actuacion(
    p_actuacion_id   IN NUMBER,
    p_tipo_actuacion IN VARCHAR2,
    p_fecha          IN DATE,
    p_detalle        IN VARCHAR2,
    p_autoridad_id   IN NUMBER,
    p_incidente_id   IN NUMBER
  );

END PA_OPERADOR;
/

/*============================================================
PA_CIUDADANO
============================================================*/
CREATE OR REPLACE PACKAGE PA_CIUDADANO AS

  PROCEDURE registrar_ciudadano(
    p_ciudadano_id IN NUMBER,
    p_documento    IN VARCHAR2,
    p_nombres      IN VARCHAR2,
    p_apellidos    IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2,
    p_direccion    IN VARCHAR2
  );

  PROCEDURE actualizar_contacto(
    p_ciudadano_id IN NUMBER,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2,
    p_direccion    IN VARCHAR2
  );

  FUNCTION co_mis_incidentes(
    p_ciudadano_id IN NUMBER
  ) RETURN SYS_REFCURSOR;

  FUNCTION co_mis_evidencias(
    p_ciudadano_id IN NUMBER
  ) RETURN SYS_REFCURSOR;

  FUNCTION co_resumen_proceso_incidente(
    p_incidente_id IN NUMBER
  ) RETURN SYS_REFCURSOR;

END PA_CIUDADANO;
/
