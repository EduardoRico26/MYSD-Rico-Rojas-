/*============================================================
Seguridad OK 
============================================================*/

/*============================================================
Prueba 1
Operador registra caso con autoridad, delito, ubicacion, ciudadano, sospechoso, incidente, evidencia, denuncia y actuacion
============================================================*/
DECLARE
  v_autoridad_id  NUMBER;
  v_delito_id     NUMBER;
  v_ubicacion_id  NUMBER;
  v_ciudadano_id  NUMBER;
  v_sospechoso_id NUMBER;
  v_incidente_id  NUMBER;
  v_evidencia_id  NUMBER;
  v_denuncia_id   NUMBER;
  v_actuacion_id  NUMBER;

  v_cod_autoridad VARCHAR2(30);
  v_cod_delito    VARCHAR2(30);
  v_cod_ubicacion VARCHAR2(30);
  v_cod_incidente VARCHAR2(30);

  v_cnt NUMBER;
BEGIN
  SELECT NVL(MAX(AutoridadID),0) + 1 INTO v_autoridad_id FROM Autoridad;
  SELECT NVL(MAX(DelitoID),0) + 1 INTO v_delito_id FROM Delito;
  SELECT NVL(MAX(UbicacionID),0) + 1 INTO v_ubicacion_id FROM Ubicacion;
  SELECT NVL(MAX(CiudadanoID),0) + 1 INTO v_ciudadano_id FROM Ciudadano;
  SELECT NVL(MAX(SospechosoID),0) + 1 INTO v_sospechoso_id FROM Sospechoso;
  SELECT NVL(MAX(IncidenteID),0) + 1 INTO v_incidente_id FROM Incidente;
  SELECT NVL(MAX(EvidenciaID),0) + 1 INTO v_evidencia_id FROM Evidencia;
  SELECT NVL(MAX(DenunciaID),0) + 1 INTO v_denuncia_id FROM Denuncia;
  SELECT NVL(MAX(ActuacionID),0) + 1 INTO v_actuacion_id FROM Actuacion;

  v_cod_autoridad := 'A' || TO_CHAR(v_autoridad_id);
  v_cod_delito    := 'D' || TO_CHAR(v_delito_id);
  v_cod_ubicacion := 'U' || TO_CHAR(v_ubicacion_id);
  v_cod_incidente := 'I' || LPAD(TO_CHAR(v_incidente_id),6,'0');

  PA_OPERADOR.ad_autoridad(
    v_autoridad_id, v_cod_autoridad,
    'Policia Metropolitana de Bogota', 'Policia',
    '6011234588', 'pm_bogota88@policia.gov'
  );

  PA_OPERADOR.ad_delito(
    v_delito_id, v_cod_delito,
    'Hurto de celular',
    'Hurto de telefono movil en via publica',
    'Hurto', 'Alta'
  );

  PA_OPERADOR.ad_ubicacion(
    v_ubicacion_id, v_cod_ubicacion,
    'Carrera 13 63 20', 'Chapinero Central', 'Chapinero',
    '4.6510', '74.0640W'
  );

  PA_OPERADOR.ad_ciudadano(
    v_ciudadano_id,
    'CC' || LPAD(TO_CHAR(v_ciudadano_id),10,'0'),
    'Andres Felipe', 'Castro Rodriguez',
    '3007010101', 'andres.castro01@mail.com', 'Carrera 13 63 20'
  );

  PA_OPERADOR.ad_sospechoso(
    v_sospechoso_id,
    'SC' || LPAD(TO_CHAR(v_sospechoso_id),10,'0'),
    'El Rapido', 'Kevin', 'Ramirez',
    'Identificado por camara de local cercano'
  );

  PA_OPERADOR.ad_incidente(
    v_incidente_id, v_cod_incidente,
    TO_DATE('20250312','YYYYMMDD'),
    'Hurto de celular a la salida de estacion de transporte, la victima reporta distraccion y fuga',
    'Alta', 'Abierto',
    v_delito_id, v_ubicacion_id
  );

  PA_OPERADOR.vincular_ciudadano_incidente(v_incidente_id, v_ciudadano_id);
  PA_OPERADOR.vincular_sospechoso_incidente(v_incidente_id, v_sospechoso_id);

  PA_OPERADOR.ad_evidencia(
    v_evidencia_id,
    'Video',
    'Grabacion de camara de seguridad con rostro parcial y ruta de escape',
    TO_DATE('20250312','YYYYMMDD'),
    v_ciudadano_id
  );

  PA_OPERADOR.ad_denuncia(
    v_denuncia_id,
    'DN' || LPAD(TO_CHAR(v_denuncia_id),8,'0'),
    TO_DATE('20250312','YYYYMMDD'),
    'Denuncia formal por hurto, se anexa video y se solicita acompanamiento policial',
    v_ciudadano_id,
    v_autoridad_id,
    v_incidente_id
  );

  PA_OPERADOR.ad_actuacion(
    v_actuacion_id,
    'Verificacion en sitio',
    TO_DATE('20250312','YYYYMMDD'),
    'Patrulla verifica camaras del sector y recolecta informacion de testigos',
    v_autoridad_id,
    v_incidente_id
  );

  SELECT COUNT(*) INTO v_cnt
  FROM Incidente
  WHERE IncidenteID = v_incidente_id;

  IF v_cnt = 0 THEN
    RAISE_APPLICATION_ERROR(20001, 'No se registro el incidente');
  END IF;

  COMMIT;
END;
/

/*============================================================
Prueba 2
Operador registra caso con dos ciudadanos vinculados al mismo incidente y evidencia asociada a uno de ellos
============================================================*/
DECLARE
  v_delito_id      NUMBER;
  v_ubicacion_id   NUMBER;
  v_ciudadano_id1  NUMBER;
  v_ciudadano_id2  NUMBER;
  v_incidente_id   NUMBER;
  v_evidencia_id   NUMBER;

  v_cod_delito     VARCHAR2(30);
  v_cod_ubicacion  VARCHAR2(30);
  v_cod_incidente  VARCHAR2(30);

  v_cnt NUMBER;
BEGIN
  SELECT NVL(MAX(DelitoID),0) + 1 INTO v_delito_id FROM Delito;
  SELECT NVL(MAX(UbicacionID),0) + 1 INTO v_ubicacion_id FROM Ubicacion;

  SELECT NVL(MAX(CiudadanoID),0) + 1 INTO v_ciudadano_id1 FROM Ciudadano;
  v_ciudadano_id2 := v_ciudadano_id1 + 1;

  SELECT NVL(MAX(IncidenteID),0) + 1 INTO v_incidente_id FROM Incidente;
  SELECT NVL(MAX(EvidenciaID),0) + 1 INTO v_evidencia_id FROM Evidencia;

  v_cod_delito    := 'D' || TO_CHAR(v_delito_id);
  v_cod_ubicacion := 'U' || TO_CHAR(v_ubicacion_id);
  v_cod_incidente := 'I' || LPAD(TO_CHAR(v_incidente_id),6,'0');

  PA_OPERADOR.ad_delito(
    v_delito_id, v_cod_delito,
    'Lesiones personales',
    'Agresion fisica en via publica con afectacion leve',
    'Violencia', 'Media'
  );

  PA_OPERADOR.ad_ubicacion(
    v_ubicacion_id, v_cod_ubicacion,
    'Avenida 1 de Mayo 38 10', 'Carvajal', 'Kennedy',
    '4.6150', '74.1300W'
  );

  PA_OPERADOR.ad_ciudadano(
    v_ciudadano_id1,
    'CC' || LPAD(TO_CHAR(v_ciudadano_id1),10,'0'),
    'Diana Carolina', 'Gonzalez Mora',
    '3007020202', 'diana.gonzalez02@mail.com', 'Avenida 1 de Mayo 38 10'
  );

  PA_OPERADOR.ad_ciudadano(
    v_ciudadano_id2,
    'CC' || LPAD(TO_CHAR(v_ciudadano_id2),10,'0'),
    'Juan Esteban', 'Salazar Nino',
    '3007060606', 'juan.salazar06@mail.com', 'Avenida 1 de Mayo 38 12'
  );

  PA_OPERADOR.ad_incidente(
    v_incidente_id, v_cod_incidente,
    TO_DATE('20250421','YYYYMMDD'),
    'Pelea en exterior de establecimiento, una persona lesionada y un testigo aporta datos',
    'Media', 'En proceso',
    v_delito_id, v_ubicacion_id
  );

  PA_OPERADOR.vincular_ciudadano_incidente(v_incidente_id, v_ciudadano_id1);
  PA_OPERADOR.vincular_ciudadano_incidente(v_incidente_id, v_ciudadano_id2);

  PA_OPERADOR.ad_evidencia(
    v_evidencia_id,
    'Testimonio',
    'Declaracion del testigo con descripcion de vestimenta y hora aproximada',
    TO_DATE('20250421','YYYYMMDD'),
    v_ciudadano_id2
  );

  SELECT COUNT(*) INTO v_cnt
  FROM Incidente_Ciudadano
  WHERE IncidenteID = v_incidente_id
    AND CiudadanoID = v_ciudadano_id1;

  IF v_cnt = 0 THEN
    RAISE_APPLICATION_ERROR(20002, 'No se vinculo el ciudadano al incidente');
  END IF;

  COMMIT;
END;
/

/*============================================================
Prueba 3
Ciudadano actualiza su contacto y ejecuta consultas por paquetes
Las consultas solo se abren y se cierran para validar ejecucion
============================================================*/
DECLARE
  v_ciudadano_id NUMBER;
  v_incidente_id NUMBER;

  rc1 SYS_REFCURSOR;
  rc2 SYS_REFCURSOR;
  rc3 SYS_REFCURSOR;
BEGIN
  SELECT MAX(CiudadanoID) INTO v_ciudadano_id FROM Ciudadano;
  SELECT MAX(IncidenteID) INTO v_incidente_id FROM Incidente;

  PA_CIUDADANO.actualizar_contacto(
    v_ciudadano_id,
    '3007999900',
    'contacto.actualizado@mail.com',
    'Direccion actualizada 100 10'
  );

  rc1 := PA_CIUDADANO.co_mis_incidentes(v_ciudadano_id);
  CLOSE rc1;

  rc2 := PA_CIUDADANO.co_mis_evidencias(v_ciudadano_id);
  CLOSE rc2;

  rc3 := PA_CIUDADANO.co_resumen_proceso_incidente(v_incidente_id);
  CLOSE rc3;

  COMMIT;
END;
/

/*============================================================
Consultas verificacion con SELECT
============================================================*/
SELECT IncidenteID, CodigoIncidente, FechaIncidente, Severidad, Estado
FROM Incidente
WHERE IncidenteID = (SELECT MAX(IncidenteID) FROM Incidente);

SELECT CiudadanoID, Documento, Nombres, Apellidos, Telefono, Correo, Direccion
FROM Ciudadano
WHERE CiudadanoID = (SELECT MAX(CiudadanoID) FROM Ciudadano);

SELECT *
FROM vw_resumen_proceso_incidente
WHERE IncidenteID = (SELECT MAX(IncidenteID) FROM Incidente);
