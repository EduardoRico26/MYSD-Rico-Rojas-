/*============================================================
ActoresI
============================================================*/

/*============================================================
PA_OPERADOR
============================================================*/
CREATE OR REPLACE PACKAGE BODY PA_OPERADOR AS

  PROCEDURE ad_autoridad(
    p_autoridad_id IN NUMBER,
    p_codigo       IN VARCHAR2,
    p_nombre       IN VARCHAR2,
    p_tipo         IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2
  ) IS
  BEGIN
    PC_MantenerAutoridad.ad_autoridad(
      p_autoridad_id, p_codigo, p_nombre, p_tipo, p_telefono, p_correo
    );
  END ad_autoridad;

  PROCEDURE ad_delito(
    p_delito_id   IN NUMBER,
    p_codigo      IN VARCHAR2,
    p_nombre      IN VARCHAR2,
    p_descripcion IN VARCHAR2,
    p_categoria   IN VARCHAR2,
    p_gravedad    IN VARCHAR2
  ) IS
  BEGIN
    PC_MantenerDelito.ad_delito(
      p_delito_id, p_codigo, p_nombre, p_descripcion, p_categoria, p_gravedad
    );
  END ad_delito;

  PROCEDURE ad_ubicacion(
    p_ubicacion_id IN NUMBER,
    p_codigo       IN VARCHAR2,
    p_direccion    IN VARCHAR2,
    p_barrio       IN VARCHAR2,
    p_localidad    IN VARCHAR2,
    p_lat          IN VARCHAR2,
    p_lon          IN VARCHAR2
  ) IS
  BEGIN
    PC_MantenerUbicacion.ad_ubicacion(
      p_ubicacion_id, p_codigo, p_direccion, p_barrio, p_localidad, p_lat, p_lon
    );
  END ad_ubicacion;

  PROCEDURE ad_ciudadano(
    p_ciudadano_id IN NUMBER,
    p_documento    IN VARCHAR2,
    p_nombres      IN VARCHAR2,
    p_apellidos    IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2,
    p_direccion    IN VARCHAR2
  ) IS
  BEGIN
    PC_MantenerCiudadano.ad_ciudadano(
      p_ciudadano_id, p_documento, p_nombres, p_apellidos, p_telefono, p_correo, p_direccion
    );
  END ad_ciudadano;

  PROCEDURE ad_sospechoso(
    p_sospechoso_id IN NUMBER,
    p_documento     IN VARCHAR2,
    p_alias         IN VARCHAR2,
    p_nombres       IN VARCHAR2,
    p_apellidos     IN VARCHAR2,
    p_observaciones IN VARCHAR2
  ) IS
  BEGIN
    PC_MantenerSospechoso.ad_sospechoso(
      p_sospechoso_id, p_documento, p_alias, p_nombres, p_apellidos, p_observaciones
    );
  END ad_sospechoso;

  PROCEDURE ad_incidente(
    p_incidente_id IN NUMBER,
    p_codigo       IN VARCHAR2,
    p_fecha        IN DATE,
    p_descripcion  IN VARCHAR2,
    p_severidad    IN VARCHAR2,
    p_estado       IN VARCHAR2,
    p_delito_id    IN NUMBER,
    p_ubicacion_id IN NUMBER
  ) IS
  BEGIN
    PC_RegistrarIncidente.ad_incidente(
      p_incidente_id, p_codigo, p_fecha, p_descripcion, p_severidad, p_estado, p_delito_id, p_ubicacion_id
    );
  END ad_incidente;

  PROCEDURE vincular_ciudadano_incidente(
    p_incidente_id IN NUMBER,
    p_ciudadano_id IN NUMBER
  ) IS
  BEGIN
    PC_RegistrarIncidente.ad_incidente_ciudadano(p_incidente_id, p_ciudadano_id);
  END vincular_ciudadano_incidente;

  PROCEDURE vincular_sospechoso_incidente(
    p_incidente_id  IN NUMBER,
    p_sospechoso_id IN NUMBER
  ) IS
  BEGIN
    PC_RegistrarIncidente.ad_incidente_sospechoso(p_incidente_id, p_sospechoso_id);
  END vincular_sospechoso_incidente;

  PROCEDURE ad_evidencia(
    p_evidencia_id   IN NUMBER,
    p_tipo           IN VARCHAR2,
    p_descripcion    IN VARCHAR2,
    p_fecha_registro IN DATE,
    p_ciudadano_id   IN NUMBER
  ) IS
  BEGIN
    PC_RegistrarEvidencia.ad_evidencia(
      p_evidencia_id, p_tipo, p_descripcion, p_fecha_registro, p_ciudadano_id
    );
  END ad_evidencia;

  PROCEDURE ad_denuncia(
    p_denuncia_id     IN NUMBER,
    p_numero_denuncia IN VARCHAR2,
    p_fecha_denuncia  IN DATE,
    p_detalle         IN VARCHAR2,
    p_ciudadano_id    IN NUMBER,
    p_autoridad_id    IN NUMBER,
    p_incidente_id    IN NUMBER
  ) IS
  BEGIN
    INSERT INTO Denuncia(
      DenunciaID, NumeroDenuncia, FechaDenuncia, Detalle,
      CiudadanoID, AutoridadID, IncidenteID
    ) VALUES (
      p_denuncia_id, p_numero_denuncia, p_fecha_denuncia, p_detalle,
      p_ciudadano_id, p_autoridad_id, p_incidente_id
    );
  END ad_denuncia;

  PROCEDURE ad_actuacion(
    p_actuacion_id   IN NUMBER,
    p_tipo_actuacion IN VARCHAR2,
    p_fecha          IN DATE,
    p_detalle        IN VARCHAR2,
    p_autoridad_id   IN NUMBER,
    p_incidente_id   IN NUMBER
  ) IS
  BEGIN
    INSERT INTO Actuacion(
      ActuacionID, TipoActuacion, FechaActuacion, Detalle,
      AutoridadID, IncidenteID
    ) VALUES (
      p_actuacion_id, p_tipo_actuacion, p_fecha, p_detalle,
      p_autoridad_id, p_incidente_id
    );
  END ad_actuacion;

END PA_OPERADOR;
/

/*============================================================
PA_CIUDADANO
============================================================*/
CREATE OR REPLACE PACKAGE BODY PA_CIUDADANO AS

  PROCEDURE registrar_ciudadano(
    p_ciudadano_id IN NUMBER,
    p_documento    IN VARCHAR2,
    p_nombres      IN VARCHAR2,
    p_apellidos    IN VARCHAR2,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2,
    p_direccion    IN VARCHAR2
  ) IS
  BEGIN
    PC_MantenerCiudadano.ad_ciudadano(
      p_ciudadano_id, p_documento, p_nombres, p_apellidos, p_telefono, p_correo, p_direccion
    );
  END registrar_ciudadano;

  PROCEDURE actualizar_contacto(
    p_ciudadano_id IN NUMBER,
    p_telefono     IN VARCHAR2,
    p_correo       IN VARCHAR2,
    p_direccion    IN VARCHAR2
  ) IS
    v_nombres   Ciudadano.Nombres%TYPE;
    v_apellidos Ciudadano.Apellidos%TYPE;
  BEGIN
    SELECT Nombres, Apellidos
    INTO v_nombres, v_apellidos
    FROM Ciudadano
    WHERE CiudadanoID = p_ciudadano_id;

    PC_MantenerCiudadano.mod_ciudadano(
      p_ciudadano_id,
      v_nombres,
      v_apellidos,
      p_telefono,
      p_correo,
      p_direccion
    );
  END actualizar_contacto;

  FUNCTION co_mis_incidentes(
    p_ciudadano_id IN NUMBER
  ) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    rc := PC_ConsultarIncidentes.fc_listar_por_ciudadano(p_ciudadano_id);
    RETURN rc;
  END co_mis_incidentes;

  FUNCTION co_mis_evidencias(
    p_ciudadano_id IN NUMBER
  ) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    rc := PC_RegistrarEvidencia.fc_listar_por_ciudadano(p_ciudadano_id);
    RETURN rc;
  END co_mis_evidencias;

  FUNCTION co_resumen_proceso_incidente(
    p_incidente_id IN NUMBER
  ) RETURN SYS_REFCURSOR IS
    rc SYS_REFCURSOR;
  BEGIN
    OPEN rc FOR
      SELECT *
      FROM vw_resumen_proceso_incidente
      WHERE IncidenteID = p_incidente_id;
    RETURN rc;
  END co_resumen_proceso_incidente;

END PA_CIUDADANO;
/
