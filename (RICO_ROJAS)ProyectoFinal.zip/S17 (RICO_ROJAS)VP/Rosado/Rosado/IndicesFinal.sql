/*============================================================
CREACION DE INDICES PRINCIPALES
============================================================*/

CREATE INDEX idx_incidente_fecha
ON Incidente(FechaIncidente);
/* Indice: Incidente por FechaIncidente
   Importancia: acelera consultas y reportes por rangos de fechas de incidentes */

CREATE INDEX idx_incidente_estado
ON Incidente(Estado);
/* Indice: Incidente por Estado
   Importancia: mejora filtros operativos por estado (Abierto, En proceso, Cerrado) */

CREATE INDEX idx_ubicacion_localidad
ON Ubicacion(Localidad);
/* Indice: Ubicacion por Localidad
   Importancia: acelera busquedas por localidad y soporta joins desde incidentes a ubicaciones */

CREATE INDEX idx_incidente_delito
ON Incidente(DelitoID);
/* Indice: Incidente por DelitoID
   Importancia: optimiza consultas y agrupaciones por delito y el join con la tabla Delito */

CREATE INDEX idx_denuncia_incidente
ON Denuncia(IncidenteID);
/* Indice: Denuncia por IncidenteID
   Importancia: permite recuperar rapido las denuncias asociadas a un incidente */

CREATE INDEX idx_actuacion_incidente
ON Actuacion(IncidenteID);
/* Indice: Actuacion por IncidenteID
   Importancia: acelera la consulta del historial de actuaciones de un incidente */

CREATE INDEX idx_ic_ciudadano
ON Incidente_Ciudadano(CiudadanoID);
/* Indice: Puente Incidente_Ciudadano por CiudadanoID
   Importancia: facilita encontrar todos los incidentes vinculados a un ciudadano */

CREATE INDEX idx_is_sospechoso
ON Incidente_Sospechoso(SospechosoID);
/* Indice: Puente Incidente_Sospechoso por SospechosoID
   Importancia: facilita encontrar todos los incidentes vinculados a un sospechoso */
