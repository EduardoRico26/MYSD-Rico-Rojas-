/*============================================================
FORANEAS
============================================================ */

-- UNIDAD POLICIAL → AUTORIDAD
ALTER TABLE UnidadPolicial
  ADD CONSTRAINT fk_unidadpolicial_autoridad
  FOREIGN KEY (AutoridadID)
  REFERENCES Autoridad(AutoridadID);

-- INCIDENTE → DELITO
ALTER TABLE Incidente
  ADD CONSTRAINT fk_incidente_delito
  FOREIGN KEY (DelitoID)
  REFERENCES Delito(DelitoID);

-- INCIDENTE → UBICACION
ALTER TABLE Incidente
  ADD CONSTRAINT fk_incidente_ubicacion
  FOREIGN KEY (UbicacionID)
  REFERENCES Ubicacion(UbicacionID);

-- ACTUACION → AUTORIDAD
ALTER TABLE Actuacion
  ADD CONSTRAINT fk_actuacion_autoridad
  FOREIGN KEY (AutoridadID)
  REFERENCES Autoridad(AutoridadID);

-- ACTUACION → INCIDENTE
ALTER TABLE Actuacion
  ADD CONSTRAINT fk_actuacion_incidente
  FOREIGN KEY (IncidenteID)
  REFERENCES Incidente(IncidenteID);

-- DENUNCIA → CIUDADANO
ALTER TABLE Denuncia
  ADD CONSTRAINT fk_denuncia_ciudadano
  FOREIGN KEY (CiudadanoID)
  REFERENCES Ciudadano(CiudadanoID);

-- DENUNCIA → AUTORIDAD
ALTER TABLE Denuncia
  ADD CONSTRAINT fk_denuncia_autoridad
  FOREIGN KEY (AutoridadID)
  REFERENCES Autoridad(AutoridadID);

-- DENUNCIA → INCIDENTE
ALTER TABLE Denuncia
  ADD CONSTRAINT fk_denuncia_incidente
  FOREIGN KEY (IncidenteID)
  REFERENCES Incidente(IncidenteID);

-- EVIDENCIA → CIUDADANO
ALTER TABLE Evidencia
  ADD CONSTRAINT fk_evidencia_ciudadano
  FOREIGN KEY (CiudadanoID)
  REFERENCES Ciudadano(CiudadanoID);

-- TABLAS PUENTE (* a *)
ALTER TABLE Incidente_Ciudadano
  ADD CONSTRAINT fk_ic_incidente
  FOREIGN KEY (IncidenteID)
  REFERENCES Incidente(IncidenteID);

ALTER TABLE Incidente_Ciudadano
  ADD CONSTRAINT fk_ic_ciudadano
  FOREIGN KEY (CiudadanoID)
  REFERENCES Ciudadano(CiudadanoID);

ALTER TABLE Incidente_Sospechoso
  ADD CONSTRAINT fk_is_incidente
  FOREIGN KEY (IncidenteID)
  REFERENCES Incidente(IncidenteID);

ALTER TABLE Incidente_Sospechoso
  ADD CONSTRAINT fk_is_sospechoso
  FOREIGN KEY (SospechosoID)
  REFERENCES Sospechoso(SospechosoID);
   
