/*============================================================
ROLES
============================================================*/
CREATE ROLE C##ROL_CIUDADANO;
CREATE ROLE C##ROL_OPERADOR;
CREATE ROLE C##ROL_ADMINISTRADOR;

/*============================================================
USUARIOS
============================================================*/
CREATE USER C##USUARIO_CIUDADANO IDENTIFIED BY ciudad123;
CREATE USER C##USUARIO_OPERADOR IDENTIFIED BY oper123;
CREATE USER C##USUARIO_ADMIN     IDENTIFIED BY admin123;

-- Permitir login
GRANT CREATE SESSION TO C##USUARIO_CIUDADANO;
GRANT CREATE SESSION TO C##USUARIO_OPERADOR;
GRANT CREATE SESSION TO C##USUARIO_ADMIN;

/*============================================================
ASIGNACIÓN DE ROLES
============================================================*/
GRANT C##ROL_CIUDADANO     TO C##USUARIO_CIUDADANO;
GRANT C##ROL_OPERADOR      TO C##USUARIO_OPERADOR;
GRANT C##ROL_ADMINISTRADOR TO C##USUARIO_ADMIN;

/*============================================================
PERMISOS POR ROL
============================================================*/

--------------------------------------------------------------
-- PERMISOS DEL CIUDADANO
--------------------------------------------------------------
GRANT SELECT, INSERT, UPDATE ON Ciudadano TO C##ROL_CIUDADANO;
GRANT SELECT, INSERT        ON Incidente  TO C##ROL_CIUDADANO;
GRANT SELECT, INSERT        ON Denuncia   TO C##ROL_CIUDADANO;

--------------------------------------------------------------
-- PERMISOS DEL OPERADOR
--------------------------------------------------------------
GRANT SELECT, UPDATE ON Incidente TO C##ROL_OPERADOR;
GRANT SELECT, INSERT ON Actuacion TO C##ROL_OPERADOR;

--------------------------------------------------------------
-- PERMISOS DEL ADMINISTRADOR
--------------------------------------------------------------
GRANT SELECT, INSERT, UPDATE, DELETE ON Ciudadano   TO C##ROL_ADMINISTRADOR;
GRANT SELECT, INSERT, UPDATE, DELETE ON Incidente   TO C##ROL_ADMINISTRADOR;
GRANT SELECT, INSERT, UPDATE, DELETE ON Denuncia    TO C##ROL_ADMINISTRADOR;
GRANT SELECT, INSERT, UPDATE, DELETE ON Actuacion   TO C##ROL_ADMINISTRADOR;
GRANT SELECT, INSERT, UPDATE, DELETE ON Ubicacion   TO C##ROL_ADMINISTRADOR;
GRANT SELECT, INSERT, UPDATE, DELETE ON Sospechoso  TO C##ROL_ADMINISTRADOR;
GRANT SELECT, INSERT, UPDATE, DELETE ON Delito      TO C##ROL_ADMINISTRADOR;
GRANT SELECT, INSERT, UPDATE, DELETE ON Autoridad   TO C##ROL_ADMINISTRADOR;
GRANT SELECT, INSERT, UPDATE, DELETE ON Evidencia   TO C##ROL_ADMINISTRADOR;
GRANT SELECT, INSERT, UPDATE, DELETE ON UnidadPolicial TO C##ROL_ADMINISTRADOR;
GRANT SELECT, INSERT, UPDATE, DELETE ON Incidente_Ciudadano TO C##ROL_ADMINISTRADOR;
GRANT SELECT, INSERT, UPDATE, DELETE ON Incidente_Sospechoso TO C##ROL_ADMINISTRADOR;
