/*============================================================
DISPARADORES (automatización)
============================================================ */

-- 1) FechaIncidente por defecto si no se envía
CREATE OR REPLACE TRIGGER trg_incidente_fecha
BEFORE INSERT ON Incidente
FOR EACH ROW
BEGIN
  IF :NEW.FechaIncidente IS NULL THEN
    :NEW.FechaIncidente := SYSDATE;
  END IF;
END;
/

-- 2) Estado por defecto ‘Abierto’ si no se envía
CREATE OR REPLACE TRIGGER trg_incidente_estado_default
BEFORE INSERT ON Incidente
FOR EACH ROW
BEGIN
  IF :NEW.Estado IS NULL THEN
    :NEW.Estado := 'Abierto';
  END IF;
END;
/

-- 3) Validar que FechaDenuncia >= FechaIncidente (si hay Incidente asociado)
CREATE OR REPLACE TRIGGER trg_denuncia_fecha_valida
BEFORE INSERT OR UPDATE ON Denuncia
FOR EACH ROW
DECLARE
  v_fecha_incidente  DATE;
BEGIN
  IF :NEW.IncidenteID IS NOT NULL THEN
    SELECT FechaIncidente
      INTO v_fecha_incidente
      FROM Incidente
     WHERE IncidenteID = :NEW.IncidenteID;

    IF :NEW.FechaDenuncia < v_fecha_incidente THEN
      RAISE_APPLICATION_ERROR(-20001,
        'FechaDenuncia no puede ser anterior a la FechaIncidente');
    END IF;
  END IF;
END;
/
-- Fin DISPARADORES

