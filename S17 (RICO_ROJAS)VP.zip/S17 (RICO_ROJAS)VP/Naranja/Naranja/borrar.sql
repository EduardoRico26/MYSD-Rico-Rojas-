-- 1) Limpia el RECYCLEBIN
PURGE RECYCLEBIN;
 
-- 2) Elimina TODAS las constraints (check, pk, fk, unique)
BEGIN
    FOR c IN (
        SELECT table_name, constraint_name
        FROM user_constraints
        WHERE constraint_type IN ('C','P','R','U')
    ) LOOP
        BEGIN
            EXECUTE IMMEDIATE 'ALTER TABLE ' || c.table_name || ' DROP CONSTRAINT ' || c.constraint_name;
        EXCEPTION
            WHEN OTHERS THEN NULL;
        END;
    END LOOP;
END;
/