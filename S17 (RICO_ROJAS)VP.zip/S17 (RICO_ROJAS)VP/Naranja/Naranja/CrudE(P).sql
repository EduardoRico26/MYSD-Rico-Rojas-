
--CRUDE – ESPECIFICACIÓN DE LOS PAQUETES


-- Especificación: Ciudadano
CREATE OR REPLACE PACKAGE PC_Ciudadano AS

    -- AGREGAR
    PROCEDURE ad_ciudadano(
        p_id_ciudadano IN NUMBER,
        p_documento    IN VARCHAR2,
        p_nombres      IN VARCHAR2,
        p_apellidos    IN VARCHAR2,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2,
        p_direccion    IN VARCHAR2
    );

    -- MODIFICAR
    PROCEDURE mod_ciudadano(
        p_id_ciudadano IN NUMBER,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2,
        p_direccion    IN VARCHAR2
    );

    -- ELIMINAR
    PROCEDURE del_ciudadano(
        p_id_ciudadano IN NUMBER
    );

END PC_Ciudadano;
/

-- Especificación: Autoridad

CREATE OR REPLACE PACKAGE PC_Autoridad AS

    -- AGREGAR
    PROCEDURE ad_autoridad(
        p_autoridad_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_nombre       IN VARCHAR2,
        p_tipo         IN VARCHAR2,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2
    );

    -- MODIFICAR
    PROCEDURE mod_autoridad(
        p_autoridad_id IN NUMBER,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2
    );

    -- ELIMINAR
    PROCEDURE del_autoridad(
        p_autoridad_id IN NUMBER
    );

END PC_Autoridad;
/


-- Especificación: Delito

CREATE OR REPLACE PACKAGE PC_Delito AS

    -- AGREGAR
    PROCEDURE ad_delito(
        p_delito_id   IN NUMBER,
        p_codigo      IN VARCHAR2,
        p_nombre      IN VARCHAR2,
        p_descripcion IN VARCHAR2,
        p_categoria   IN VARCHAR2,
        p_gravedad    IN VARCHAR2
    );

    -- MODIFICAR
    PROCEDURE mod_delito(
        p_delito_id   IN NUMBER,
        p_descripcion IN VARCHAR2,
        p_categoria   IN VARCHAR2,
        p_gravedad    IN VARCHAR2
    );

    -- ELIMINAR
    PROCEDURE del_delito(
        p_delito_id IN NUMBER
    );

END PC_Delito;
/

-- Especificación: Ubicacion

CREATE OR REPLACE PACKAGE PC_Ubicacion AS

    -- AGREGAR
    PROCEDURE ad_ubicacion(
        p_ubicacion_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_direccion    IN VARCHAR2,
        p_barrio       IN VARCHAR2,
        p_localidad    IN VARCHAR2
    );

    -- MODIFICAR
    PROCEDURE mod_ubicacion(
        p_ubicacion_id IN NUMBER,
        p_direccion    IN VARCHAR2,
        p_barrio       IN VARCHAR2,
        p_localidad    IN VARCHAR2
    );

    -- ELIMINAR
    PROCEDURE del_ubicacion(
        p_ubicacion_id IN NUMBER
    );

END PC_Ubicacion;
/
-- Especificación: Incidente

CREATE OR REPLACE PACKAGE PC_Incidente AS

    -- AGREGAR
    PROCEDURE ad_incidente(
        p_incidente_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_fecha        IN DATE,
        p_descripcion  IN VARCHAR2,
        p_severidad    IN VARCHAR2,
        p_estado       IN VARCHAR2,
        p_delito_id    IN NUMBER,
        p_ubicacion_id IN NUMBER
    );

    -- MODIFICAR
    PROCEDURE mod_incidente(
        p_incidente_id IN NUMBER,
        p_descripcion  IN VARCHAR2,
        p_severidad    IN VARCHAR2,
        p_estado       IN VARCHAR2
    );

    -- ELIMINAR
    PROCEDURE del_incidente(
        p_incidente_id IN NUMBER
    );

END PC_Incidente;
/