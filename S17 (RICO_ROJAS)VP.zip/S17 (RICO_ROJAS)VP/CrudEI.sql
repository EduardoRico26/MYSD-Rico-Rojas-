--Crud E /I 

-- ============================================================
-- 1) PC_Ciudadano (spec)
-- ============================================================
CREATE OR REPLACE PACKAGE PC_Ciudadano AS
    -- DML
    PROCEDURE ad_ciudadano(
        p_id_ciudadano IN NUMBER,
        p_documento    IN VARCHAR2,
        p_nombres      IN VARCHAR2,
        p_apellidos    IN VARCHAR2,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2,
        p_direccion    IN VARCHAR2
    );

    PROCEDURE mod_ciudadano(
        p_id_ciudadano IN NUMBER,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2,
        p_direccion    IN VARCHAR2
    );

    PROCEDURE del_ciudadano(
        p_id_ciudadano IN NUMBER
    );

    -- Consultas / cursores
    FUNCTION fn_existe_ciudadano(p_documento IN VARCHAR2) RETURN BOOLEAN;
    FUNCTION fn_count_ciudadanos RETURN NUMBER;
    FUNCTION fc_get_ciudadano_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION fc_listar_ciudadanos RETURN SYS_REFCURSOR;
    FUNCTION fc_buscar_por_documento(p_documento IN VARCHAR2) RETURN SYS_REFCURSOR;

END PC_Ciudadano;
/
-- ============================================================
-- 1) PC_Ciudadano (body)
-- ============================================================
CREATE OR REPLACE PACKAGE BODY PC_Ciudadano AS

    PROCEDURE ad_ciudadano(
        p_id_ciudadano IN NUMBER,
        p_documento    IN VARCHAR2,
        p_nombres      IN VARCHAR2,
        p_apellidos    IN VARCHAR2,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2,
        p_direccion    IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Ciudadano (
            CiudadanoID, Documento, Nombres, Apellidos, Telefono, Correo, Direccion
        ) VALUES (
            p_id_ciudadano, p_documento, p_nombres, p_apellidos, p_telefono, p_correo, p_direccion
        );
    END ad_ciudadano;

    PROCEDURE mod_ciudadano(
        p_id_ciudadano IN NUMBER,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2,
        p_direccion    IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Ciudadano
        SET Telefono = p_telefono,
            Correo = p_correo,
            Direccion = p_direccion
        WHERE CiudadanoID = p_id_ciudadano;
    END mod_ciudadano;

    PROCEDURE del_ciudadano(
        p_id_ciudadano IN NUMBER
    ) IS
    BEGIN
        DELETE FROM Ciudadano
        WHERE CiudadanoID = p_id_ciudadano;
    END del_ciudadano;

    FUNCTION fn_existe_ciudadano(p_documento IN VARCHAR2) RETURN BOOLEAN IS
        v_cnt INTEGER;
    BEGIN
        SELECT COUNT(*) INTO v_cnt FROM Ciudadano WHERE Documento = p_documento;
        RETURN v_cnt > 0;
    EXCEPTION WHEN OTHERS THEN
        RETURN FALSE;
    END fn_existe_ciudadano;

    FUNCTION fn_count_ciudadanos RETURN NUMBER IS
        v_cnt INTEGER;
    BEGIN
        SELECT COUNT(*) INTO v_cnt FROM Ciudadano;
        RETURN v_cnt;
    END fn_count_ciudadanos;

    FUNCTION fc_get_ciudadano_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR IS
        rc SYS_REFCURSOR;
    BEGIN
        OPEN rc FOR
        SELECT CiudadanoID, Documento, Nombres, Apellidos, Telefono, Correo, Direccion
        FROM Ciudadano
        WHERE CiudadanoID = p_id;
        RETURN rc;
    END fc_get_ciudadano_by_id;

    FUNCTION fc_listar_ciudadanos RETURN SYS_REFCURSOR IS
        rc SYS_REFCURSOR;
    BEGIN
        OPEN rc FOR
        SELECT CiudadanoID, Documento, Nombres, Apellidos, Telefono, Correo, Direccion
        FROM Ciudadano
        ORDER BY Nombres, Apellidos;
        RETURN rc;
    END fc_listar_ciudadanos;

    FUNCTION fc_buscar_por_documento(p_documento IN VARCHAR2) RETURN SYS_REFCURSOR IS
        rc SYS_REFCURSOR;
    BEGIN
        OPEN rc FOR
        SELECT CiudadanoID, Documento, Nombres, Apellidos, Telefono, Correo, Direccion
        FROM Ciudadano
        WHERE Documento = p_documento;
        RETURN rc;
    END fc_buscar_por_documento;

END PC_Ciudadano;
/
-- ============================================================
-- 2) PC_Autoridad (spec)
-- ============================================================
CREATE OR REPLACE PACKAGE PC_Autoridad AS
    -- DML
    PROCEDURE ad_autoridad(
        p_autoridad_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_nombre       IN VARCHAR2,
        p_tipo         IN VARCHAR2,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2
    );

    PROCEDURE mod_autoridad(
        p_autoridad_id IN NUMBER,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2
    );

    PROCEDURE del_autoridad(
        p_autoridad_id IN NUMBER
    );

    -- Consultas
    FUNCTION fc_get_autoridad_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION fc_listar_por_tipo(p_tipo IN VARCHAR2) RETURN SYS_REFCURSOR;
    FUNCTION fn_count_autoridades RETURN NUMBER;
    FUNCTION fn_existe_autoridad(p_codigo IN VARCHAR2) RETURN BOOLEAN;
END PC_Autoridad;
/
-- ============================================================
-- 2) PC_Autoridad (body)
-- ============================================================
CREATE OR REPLACE PACKAGE BODY PC_Autoridad AS

    PROCEDURE ad_autoridad(
        p_autoridad_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_nombre       IN VARCHAR2,
        p_tipo         IN VARCHAR2,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Autoridad (
            AutoridadID, CodigoAutoridad, Nombre, TipoAutoridad, Telefono, Correo
        ) VALUES (
            p_autoridad_id, p_codigo, p_nombre, p_tipo, p_telefono, p_correo
        );
    END ad_autoridad;

    PROCEDURE mod_autoridad(
        p_autoridad_id IN NUMBER,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Autoridad
        SET Telefono = p_telefono,
            Correo = p_correo
        WHERE AutoridadID = p_autoridad_id;
    END mod_autoridad;

    PROCEDURE del_autoridad(
        p_autoridad_id IN NUMBER
    ) IS
    BEGIN
        DELETE FROM Autoridad
        WHERE AutoridadID = p_autoridad_id;
    END del_autoridad;

    FUNCTION fc_get_autoridad_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR IS
        rc SYS_REFCURSOR;
    BEGIN
        OPEN rc FOR
        SELECT AutoridadID, CodigoAutoridad, Nombre, TipoAutoridad, Telefono, Correo
        FROM Autoridad
        WHERE AutoridadID = p_id;
        RETURN rc;
    END fc_get_autoridad_by_id;

    FUNCTION fc_listar_por_tipo(p_tipo IN VARCHAR2) RETURN SYS_REFCURSOR IS
        rc SYS_REFCURSOR;
    BEGIN
        OPEN rc FOR
        SELECT AutoridadID, CodigoAutoridad, Nombre, TipoAutoridad
        FROM Autoridad
        WHERE TipoAutoridad = p_tipo
        ORDER BY Nombre;
        RETURN rc;
    END fc_listar_por_tipo;

    FUNCTION fn_count_autoridades RETURN NUMBER IS
        v_cnt INTEGER;
    BEGIN
        SELECT COUNT(*) INTO v_cnt FROM Autoridad;
        RETURN v_cnt;
    END fn_count_autoridades;

    FUNCTION fn_existe_autoridad(p_codigo IN VARCHAR2) RETURN BOOLEAN IS
        v_cnt INTEGER;
    BEGIN
        SELECT COUNT(*) INTO v_cnt FROM Autoridad WHERE CodigoAutoridad = p_codigo;
        RETURN v_cnt > 0;
    EXCEPTION WHEN OTHERS THEN
        RETURN FALSE;
    END fn_existe_autoridad;

END PC_Autoridad;
/
-- ============================================================
-- 3) PC_Delito (spec)
-- ============================================================
CREATE OR REPLACE PACKAGE PC_Delito AS
    -- DML
    PROCEDURE ad_delito(
        p_delito_id   IN NUMBER,
        p_codigo      IN VARCHAR2,
        p_nombre      IN VARCHAR2,
        p_descripcion IN VARCHAR2,
        p_categoria   IN VARCHAR2,
        p_gravedad    IN VARCHAR2
    );

    PROCEDURE mod_delito(
        p_delito_id   IN NUMBER,
        p_descripcion IN VARCHAR2,
        p_categoria   IN VARCHAR2,
        p_gravedad    IN VARCHAR2
    );

    PROCEDURE del_delito(
        p_delito_id IN NUMBER
    );

    -- Consultas
    FUNCTION fc_get_delito_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION fc_listar_por_categoria(p_categoria IN VARCHAR2) RETURN SYS_REFCURSOR;
    FUNCTION fn_count_delitos RETURN NUMBER;
    FUNCTION fn_existe_delito(p_codigo IN VARCHAR2) RETURN BOOLEAN;
END PC_Delito;
/
-- ============================================================
-- 3) PC_Delito (body)
-- ============================================================
CREATE OR REPLACE PACKAGE BODY PC_Delito AS

    PROCEDURE ad_delito(
        p_delito_id   IN NUMBER,
        p_codigo      IN VARCHAR2,
        p_nombre      IN VARCHAR2,
        p_descripcion IN VARCHAR2,
        p_categoria   IN VARCHAR2,
        p_gravedad    IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Delito (
            DelitoID, CodigoDelito, NombreDelito, Descripcion, Categoria, Gravedad
        ) VALUES (
            p_delito_id, p_codigo, p_nombre, p_descripcion, p_categoria, p_gravedad
        );
    END ad_delito;

    PROCEDURE mod_delito(
        p_delito_id   IN NUMBER,
        p_descripcion IN VARCHAR2,
        p_categoria   IN VARCHAR2,
        p_gravedad    IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Delito
        SET Descripcion = p_descripcion,
            Categoria = p_categoria,
            Gravedad = p_gravedad
        WHERE DelitoID = p_delito_id;
    END mod_delito;

    PROCEDURE del_delito(
        p_delito_id IN NUMBER
    ) IS
    BEGIN
        DELETE FROM Delito
        WHERE DelitoID = p_delito_id;
    END del_delito;

    FUNCTION fc_get_delito_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR IS
        rc SYS_REFCURSOR;
    BEGIN
        OPEN rc FOR
        SELECT DelitoID, CodigoDelito, NombreDelito, Descripcion, Categoria, Gravedad
        FROM Delito
        WHERE DelitoID = p_id;
        RETURN rc;
    END fc_get_delito_by_id;

    FUNCTION fc_listar_por_categoria(p_categoria IN VARCHAR2) RETURN SYS_REFCURSOR IS
        rc SYS_REFCURSOR;
    BEGIN
        OPEN rc FOR
        SELECT DelitoID, CodigoDelito, NombreDelito, Categoria, Gravedad
        FROM Delito
        WHERE Categoria = p_categoria
        ORDER BY NombreDelito;
        RETURN rc;
    END fc_listar_por_categoria;

    FUNCTION fn_count_delitos RETURN NUMBER IS
        v_cnt INTEGER;
    BEGIN
        SELECT COUNT(*) INTO v_cnt FROM Delito;
        RETURN v_cnt;
    END fn_count_delitos;

    FUNCTION fn_existe_delito(p_codigo IN VARCHAR2) RETURN BOOLEAN IS
        v_cnt INTEGER;
    BEGIN
        SELECT COUNT(*) INTO v_cnt FROM Delito WHERE CodigoDelito = p_codigo;
        RETURN v_cnt > 0;
    EXCEPTION WHEN OTHERS THEN
        RETURN FALSE;
    END fn_existe_delito;

END PC_Delito;
/
-- ============================================================
-- 4) PC_Ubicacion (spec)
-- ============================================================
CREATE OR REPLACE PACKAGE PC_Ubicacion AS
    -- DML
    PROCEDURE ad_ubicacion(
        p_ubicacion_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_direccion    IN VARCHAR2,
        p_barrio       IN VARCHAR2,
        p_localidad    IN VARCHAR2
    );

    PROCEDURE mod_ubicacion(
        p_ubicacion_id IN NUMBER,
        p_direccion    IN VARCHAR2,
        p_barrio       IN VARCHAR2,
        p_localidad    IN VARCHAR2
    );

    PROCEDURE del_ubicacion(
        p_ubicacion_id IN NUMBER
    );

    -- Consultas
    FUNCTION fc_get_ubicacion_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION fc_listar_por_localidad(p_localidad IN VARCHAR2) RETURN SYS_REFCURSOR;
    FUNCTION fn_count_ubicaciones RETURN NUMBER;
END PC_Ubicacion;
/
-- ============================================================
-- 4) PC_Ubicacion (body)
-- ============================================================
CREATE OR REPLACE PACKAGE BODY PC_Ubicacion AS

    PROCEDURE ad_ubicacion(
        p_ubicacion_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_direccion    IN VARCHAR2,
        p_barrio       IN VARCHAR2,
        p_localidad    IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Ubicacion (
            UbicacionID, CodigoUbicacion, Direccion, Barrio, Localidad
        ) VALUES (
            p_ubicacion_id, p_codigo, p_direccion, p_barrio, p_localidad
        );
    END ad_ubicacion;

    PROCEDURE mod_ubicacion(
        p_ubicacion_id IN NUMBER,
        p_direccion    IN VARCHAR2,
        p_barrio       IN VARCHAR2,
        p_localidad    IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Ubicacion
        SET Direccion = p_direccion,
            Barrio = p_barrio,
            Localidad = p_localidad
        WHERE UbicacionID = p_ubicacion_id;
    END mod_ubicacion;

    PROCEDURE del_ubicacion(
        p_ubicacion_id IN NUMBER
    ) IS
    BEGIN
        DELETE FROM Ubicacion
        WHERE UbicacionID = p_ubicacion_id;
    END del_ubicacion;

    FUNCTION fc_get_ubicacion_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR IS
        rc SYS_REFCURSOR;
    BEGIN
        OPEN rc FOR
        SELECT UbicacionID, CodigoUbicacion, Direccion, Barrio, Localidad, CoordenadaLat, CoordenadaLon
        FROM Ubicacion
        WHERE UbicacionID = p_id;
        RETURN rc;
    END fc_get_ubicacion_by_id;

    FUNCTION fc_listar_por_localidad(p_localidad IN VARCHAR2) RETURN SYS_REFCURSOR IS
        rc SYS_REFCURSOR;
    BEGIN
        OPEN rc FOR
        SELECT UbicacionID, CodigoUbicacion, Direccion, Barrio, Localidad
        FROM Ubicacion
        WHERE Localidad = p_localidad
        ORDER BY Barrio, Direccion;
        RETURN rc;
    END fc_listar_por_localidad;

    FUNCTION fn_count_ubicaciones RETURN NUMBER IS
        v_cnt INTEGER;
    BEGIN
        SELECT COUNT(*) INTO v_cnt FROM Ubicacion;
        RETURN v_cnt;
    END fn_count_ubicaciones;

END PC_Ubicacion;
/
-- ============================================================
-- 5) PC_Incidente (spec)
-- ============================================================
CREATE OR REPLACE PACKAGE PC_Incidente AS
    -- DML
    PROCEDURE ad_incidente(
        p_incidente_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_fecha        IN DATE,
        p_descripcion  IN VARCHAR2,
        p_severidad    IN VARCHAR2,
        p_estado       IN VARCHAR2,
        p_delito_id    IN NUMBER,
        p_ubicacion_id IN NUMBER
    );

    PROCEDURE mod_incidente(
        p_incidente_id IN NUMBER,
        p_descripcion  IN VARCHAR2,
        p_severidad    IN VARCHAR2,
        p_estado       IN VARCHAR2
    );

    PROCEDURE del_incidente(
        p_incidente_id IN NUMBER
    );

    -- Consultas
    FUNCTION fc_get_incidente_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION fc_listar_por_estado(p_estado IN VARCHAR2) RETURN SYS_REFCURSOR;
    FUNCTION fc_listar_por_localidad(p_localidad IN VARCHAR2) RETURN SYS_REFCURSOR;
    FUNCTION fc_listar_por_rango_fecha(p_fecha_ini IN DATE, p_fecha_fin IN DATE) RETURN SYS_REFCURSOR;
    FUNCTION fn_count_incidentes_por_severidad(p_severidad IN VARCHAR2) RETURN NUMBER;
    PROCEDURE mod_estado_incidente(p_incidente_id IN NUMBER, p_estado IN VARCHAR2);
END PC_Incidente;
/
-- ============================================================
-- 5) PC_Incidente (body)
-- ============================================================
CREATE OR REPLACE PACKAGE BODY PC_Incidente AS

    PROCEDURE ad_incidente(
        p_incidente_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_fecha        IN DATE,
        p_descripcion  IN VARCHAR2,
        p_severidad    IN VARCHAR2,
        p_estado       IN VARCHAR2,
        p_delito_id    IN NUMBER,
        p_ubicacion_id IN NUMBER
    ) IS
    BEGIN
        INSERT INTO Incidente (
            IncidenteID, CodigoIncidente, FechaIncidente,
            Descripcion, Severidad, Estado, DelitoID, UbicacionID
        ) VALUES (
            p_incidente_id, p_codigo, p_fecha,
            p_descripcion, p_severidad, p_estado,
            p_delito_id, p_ubicacion_id
        );
    END ad_incidente;

    PROCEDURE mod_incidente(
        p_incidente_id IN NUMBER,
        p_descripcion  IN VARCHAR2,
        p_severidad    IN VARCHAR2,
        p_estado       IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Incidente
        SET Descripcion = p_descripcion,
            Severidad = p_severidad,
            Estado = p_estado
        WHERE IncidenteID = p_incidente_id;
    END mod_incidente;

    PROCEDURE del_incidente(
        p_incidente_id IN NUMBER
    ) IS
    BEGIN
        DELETE FROM Incidente
        WHERE IncidenteID = p_incidente_id;
    END del_incidente;

    FUNCTION fc_get_incidente_by_id(p_id IN NUMBER) RETURN SYS_REFCURSOR IS
        rc SYS_REFCURSOR;
    BEGIN
        OPEN rc FOR
        SELECT i.IncidenteID, i.CodigoIncidente, i.FechaIncidente, i.Descripcion,
               i.Severidad, i.Estado, i.DelitoID, i.UbicacionID,
               d.NombreDelito, u.Localidad
        FROM Incidente i
        LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
        LEFT JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
        WHERE i.IncidenteID = p_id;
        RETURN rc;
    END fc_get_incidente_by_id;

    FUNCTION fc_listar_por_estado(p_estado IN VARCHAR2) RETURN SYS_REFCURSOR IS
        rc SYS_REFCURSOR;
    BEGIN
        OPEN rc FOR
        SELECT i.IncidenteID, i.CodigoIncidente, i.FechaIncidente, i.Descripcion,
               i.Severidad, i.Estado, d.NombreDelito, u.Localidad
        FROM Incidente i
        LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
        LEFT JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
        WHERE i.Estado = p_estado
        ORDER BY i.FechaIncidente DESC;
        RETURN rc;
    END fc_listar_por_estado;

    FUNCTION fc_listar_por_localidad(p_localidad IN VARCHAR2) RETURN SYS_REFCURSOR IS
        rc SYS_REFCURSOR;
    BEGIN
        OPEN rc FOR
        SELECT i.IncidenteID, i.CodigoIncidente, i.FechaIncidente, i.Descripcion,
               i.Severidad, i.Estado, d.NombreDelito, u.Localidad
        FROM Incidente i
        LEFT JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
        LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
        WHERE u.Localidad = p_localidad
        ORDER BY i.FechaIncidente DESC;
        RETURN rc;
    END fc_listar_por_localidad;

    FUNCTION fc_listar_por_rango_fecha(p_fecha_ini IN DATE, p_fecha_fin IN DATE) RETURN SYS_REFCURSOR IS
        rc SYS_REFCURSOR;
    BEGIN
        OPEN rc FOR
        SELECT i.IncidenteID, i.CodigoIncidente, i.FechaIncidente, i.Descripcion,
               i.Severidad, i.Estado, d.NombreDelito, u.Localidad
        FROM Incidente i
        LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
        LEFT JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
        WHERE i.FechaIncidente BETWEEN p_fecha_ini AND p_fecha_fin
        ORDER BY i.FechaIncidente DESC;
        RETURN rc;
    END fc_listar_por_rango_fecha;

    FUNCTION fn_count_incidentes_por_severidad(p_severidad IN VARCHAR2) RETURN NUMBER IS
        v_cnt INTEGER;
    BEGIN
        SELECT COUNT(*) INTO v_cnt FROM Incidente WHERE Severidad = p_severidad;
        RETURN v_cnt;
    END fn_count_incidentes_por_severidad;

    PROCEDURE mod_estado_incidente(p_incidente_id IN NUMBER, p_estado IN VARCHAR2) IS
    BEGIN
        UPDATE Incidente
        SET Estado = p_estado
        WHERE IncidenteID = p_incidente_id;
    END mod_estado_incidente;

END PC_Incidente;
/

COMMIT;
