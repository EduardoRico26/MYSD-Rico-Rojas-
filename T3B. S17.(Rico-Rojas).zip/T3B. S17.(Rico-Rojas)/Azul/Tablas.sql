/*============================================================
CREACIÓN DE TABLAS Y ATRIBUTOS
============================================================ */

-- CIUDADANO
CREATE TABLE Ciudadano (
  CiudadanoID      NUMBER,                
  Documento        VARCHAR2(20)  NOT NULL,
  Nombres          VARCHAR2(100) NOT NULL,
  Apellidos        VARCHAR2(100) NOT NULL,
  Telefono         VARCHAR2(20),
  Correo           VARCHAR2(100),
  Direccion        VARCHAR2(150)
);

-- SOSPECHOSO
CREATE TABLE Sospechoso (
  SospechosoID     NUMBER,                 
  Documento        VARCHAR2(20)  NOT NULL,
  Alias            VARCHAR2(50),
  Nombres          VARCHAR2(100) NOT NULL,
  Apellidos        VARCHAR2(100) NOT NULL,
  Observaciones    VARCHAR2(300)
);

-- DELITO
CREATE TABLE Delito (
  DelitoID         NUMBER,                 
  CodigoDelito     VARCHAR2(20)  NOT NULL,
  NombreDelito     VARCHAR2(100) NOT NULL,
  Descripcion      VARCHAR2(400),
  Categoria        VARCHAR2(80),
  Gravedad         VARCHAR2(80)
);

-- UBICACION
CREATE TABLE Ubicacion (
  UbicacionID      NUMBER,                
  CodigoUbicacion  VARCHAR2(20)  NOT NULL,
  Direccion        VARCHAR2(150) NOT NULL,
  Barrio           VARCHAR2(100),
  Localidad        VARCHAR2(100),
  CoordenadaLat    VARCHAR2(40),
  CoordenadaLon    VARCHAR2(40)
);

-- AUTORIDAD
CREATE TABLE Autoridad (
  AutoridadID      NUMBER,                 
  CodigoAutoridad  VARCHAR2(20)  NOT NULL,
  Nombre           VARCHAR2(100) NOT NULL,
  TipoAutoridad    VARCHAR2(50),
  Telefono         VARCHAR2(20),
  Correo           VARCHAR2(100)
);

-- UNIDAD POLICIAL 
CREATE TABLE UnidadPolicial (
  UnidadPolicialID NUMBER,                 
  CodigoUnidad     VARCHAR2(20)  NOT NULL,
  NombreUnidad     VARCHAR2(100) NOT NULL,
  Direccion        VARCHAR2(150),
  AutoridadID      NUMBER                  
);

-- INCIDENTE  (tipos personalizados)
CREATE TABLE Incidente (
  IncidenteID      NUMBER,                 
  CodigoIncidente  VARCHAR2(20)  NOT NULL,
  FechaIncidente   DATE         NOT NULL,
  Descripcion      VARCHAR2(500),
  Severidad        VARCHAR2(10) NOT NULL, 
  Estado           VARCHAR2(12) NOT NULL,  
  DelitoID         NUMBER,                 
  UbicacionID      NUMBER                  
);


ALTER TABLE Incidente
  ADD CONSTRAINT chk_incidente_severidad
  CHECK (Severidad IN ('Alta','Media','Baja'));

ALTER TABLE Incidente
  ADD CONSTRAINT chk_incidente_estado
  CHECK (Estado IN ('Abierto','En proceso','Cerrado'));

-- ACTUACION  
CREATE TABLE Actuacion (
  ActuacionID      NUMBER,                
  TipoActuacion    VARCHAR2(80) NOT NULL,
  FechaActuacion   DATE,
  Detalle          VARCHAR2(400),
  AutoridadID      NUMBER,                 
  IncidenteID      NUMBER                  
);

-- DENUNCIA 
CREATE TABLE Denuncia (
  DenunciaID       NUMBER,                 
  NumeroDenuncia   VARCHAR2(20) NOT NULL,
  FechaDenuncia    DATE         NOT NULL,
  Detalle          VARCHAR2(400),
  CiudadanoID      NUMBER,                
  AutoridadID      NUMBER,                 
  IncidenteID      NUMBER                 
);

-- EVIDENCIA (asociada a Ciudadano)
CREATE TABLE Evidencia (
  EvidenciaID      NUMBER,                 
  TipoEvidencia    VARCHAR2(80) NOT NULL,
  Descripcion      VARCHAR2(400),
  FechaRegistro    DATE         NOT NULL,
  CiudadanoID      NUMBER                  
);

-- TABLAS PUENTE * a *
CREATE TABLE Incidente_Ciudadano (
  IncidenteID      NUMBER NOT NULL,
  CiudadanoID      NUMBER NOT NULL
);

CREATE TABLE Incidente_Sospechoso (
  IncidenteID      NUMBER NOT NULL,
  SospechosoID     NUMBER NOT NULL
);