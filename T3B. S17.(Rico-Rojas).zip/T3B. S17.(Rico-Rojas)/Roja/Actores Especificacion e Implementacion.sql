/*============================================================
ACTOR CIUDADANO
El ciudadano puede crear su perfil, incidentes y denuncias.
============================================================*/
CREATE OR REPLACE PACKAGE actor_ciudadano_pkg AS

    -- Crear ciudadano
    PROCEDURE ad_ciudadano(
        p_id_ciudadano IN NUMBER,
        p_documento    IN VARCHAR2,
        p_nombres      IN VARCHAR2,
        p_apellidos    IN VARCHAR2,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2,
        p_direccion    IN VARCHAR2
    );

    -- Crear incidente (el ciudadano lo crea y se asocia a él)
    PROCEDURE ad_incidente(
        p_incidente_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_fecha        IN DATE,
        p_descripcion  IN VARCHAR2,
        p_severidad    IN VARCHAR2,
        p_estado       IN VARCHAR2,
        p_ciudadano_id IN NUMBER,
        p_ubicacion_id IN NUMBER
    );

    -- Crear denuncia sobre un incidente
    PROCEDURE ad_denuncia(
        p_denuncia_id  IN NUMBER,
        p_fecha        IN DATE,
        p_mensaje      IN VARCHAR2,
        p_incidente_id IN NUMBER
    );

    -- Modificar ciudadano
    PROCEDURE mod_ciudadano(
        p_id_ciudadano IN NUMBER,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2,
        p_direccion    IN VARCHAR2
    );

    -- Modificar incidente propio
    PROCEDURE mod_incidente(
        p_incidente_id IN NUMBER,
        p_descripcion  IN VARCHAR2,
        p_severidad    IN VARCHAR2
    );

    -- Consultas (básicas, solo para completar la especificación)
    PROCEDURE con_incidentes(p_id_ciudadano IN NUMBER);
    PROCEDURE con_denuncias(p_id_ciudadano IN NUMBER);

END actor_ciudadano_pkg;
/
CREATE OR REPLACE PACKAGE BODY actor_ciudadano_pkg AS

    PROCEDURE ad_ciudadano(
        p_id_ciudadano IN NUMBER,
        p_documento    IN VARCHAR2,
        p_nombres      IN VARCHAR2,
        p_apellidos    IN VARCHAR2,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2,
        p_direccion    IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Ciudadano (
            CiudadanoID, Documento, Nombres, Apellidos,
            Telefono, Correo, Direccion
        )
        VALUES (
            p_id_ciudadano, p_documento, p_nombres, p_apellidos,
            p_telefono, p_correo, p_direccion
        );
    END ad_ciudadano;


    PROCEDURE ad_incidente(
        p_incidente_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_fecha        IN DATE,
        p_descripcion  IN VARCHAR2,
        p_severidad    IN VARCHAR2,
        p_estado       IN VARCHAR2,
        p_ciudadano_id IN NUMBER,
        p_ubicacion_id IN NUMBER
    ) IS
    BEGIN
        -- Insertar el incidente (DelitoID se deja en NULL por simplicidad)
        INSERT INTO Incidente (
            IncidenteID, CodigoIncidente, FechaIncidente,
            Descripcion, Severidad, Estado, DelitoID, UbicacionID
        )
        VALUES (
            p_incidente_id, p_codigo, p_fecha,
            p_descripcion, p_severidad, p_estado,
            NULL,                -- DelitoID
            p_ubicacion_id       -- UbicacionID
        );

        -- Asociar el incidente al ciudadano
        INSERT INTO Incidente_Ciudadano (
            IncidenteID, CiudadanoID
        )
        VALUES (
            p_incidente_id, p_ciudadano_id
        );
    END ad_incidente;


    PROCEDURE ad_denuncia(
        p_denuncia_id  IN NUMBER,
        p_fecha        IN DATE,
        p_mensaje      IN VARCHAR2,
        p_incidente_id IN NUMBER
    ) IS
    BEGIN
        -- NumeroDenuncia se genera simple: 'DEN-' || ID
        -- CiudadanoID y AutoridadID se dejan en NULL (básico)
        INSERT INTO Denuncia (
            DenunciaID, NumeroDenuncia, FechaDenuncia,
            Detalle, CiudadanoID, AutoridadID, IncidenteID
        )
        VALUES (
            p_denuncia_id,
            'DEN-' || p_denuncia_id,
            p_fecha,
            p_mensaje,
            NULL,          -- CiudadanoID (simple, se podría llenar luego)
            NULL,          -- AutoridadID
            p_incidente_id
        );
    END ad_denuncia;


    PROCEDURE mod_ciudadano(
        p_id_ciudadano IN NUMBER,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2,
        p_direccion    IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Ciudadano
        SET Telefono  = p_telefono,
            Correo    = p_correo,
            Direccion = p_direccion
        WHERE CiudadanoID = p_id_ciudadano;
    END mod_ciudadano;


    PROCEDURE mod_incidente(
        p_incidente_id IN NUMBER,
        p_descripcion  IN VARCHAR2,
        p_severidad    IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Incidente
        SET Descripcion = p_descripcion,
            Severidad   = p_severidad
        WHERE IncidenteID = p_incidente_id;
    END mod_incidente;


    PROCEDURE con_incidentes(p_id_ciudadano IN NUMBER) IS
    BEGIN
        -- Básico: aquí podrías hacer un SELECT... pero lo dejamos en NULL
        NULL;
    END con_incidentes;


    PROCEDURE con_denuncias(p_id_ciudadano IN NUMBER) IS
    BEGIN
        NULL;
    END con_denuncias;

END actor_ciudadano_pkg;
/
------------------------------------------------------------
-- ACTOR OPERADOR
-- El operador puede cambiar estados y registrar actuaciones.
------------------------------------------------------------
CREATE OR REPLACE PACKAGE actor_operador_pkg AS

    PROCEDURE mod_estado_incidente(
        p_incidente_id IN NUMBER,
        p_estado       IN VARCHAR2
    );

    PROCEDURE ad_actuacion(
        p_actuacion_id IN NUMBER,
        p_fecha        IN DATE,
        p_descripcion  IN VARCHAR2,
        p_incidente_id IN NUMBER
    );

    PROCEDURE con_incidentes_procesados;
    PROCEDURE con_actuaciones(p_incidente_id IN NUMBER);

END actor_operador_pkg;
/
CREATE OR REPLACE PACKAGE BODY actor_operador_pkg AS

    PROCEDURE mod_estado_incidente(
        p_incidente_id IN NUMBER,
        p_estado       IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Incidente
        SET Estado = p_estado
        WHERE IncidenteID = p_incidente_id;
    END mod_estado_incidente;


    PROCEDURE ad_actuacion(
        p_actuacion_id IN NUMBER,
        p_fecha        IN DATE,
        p_descripcion  IN VARCHAR2,
        p_incidente_id IN NUMBER
    ) IS
    BEGIN
        -- TipoActuacion fijo y AutoridadID en NULL (básico)
        INSERT INTO Actuacion (
            ActuacionID, TipoActuacion, FechaActuacion,
            Detalle, AutoridadID, IncidenteID
        )
        VALUES (
            p_actuacion_id,
            'Seguimiento',   -- TipoActuacion simple
            p_fecha,
            p_descripcion,
            NULL,            -- AutoridadID
            p_incidente_id
        );
    END ad_actuacion;


    PROCEDURE con_incidentes_procesados IS
    BEGIN
        NULL;
    END con_incidentes_procesados;


    PROCEDURE con_actuaciones(p_incidente_id IN NUMBER) IS
    BEGIN
        NULL;
    END con_actuaciones;

END actor_operador_pkg;
/
------------------------------------------------------------
-- ACTOR ADMINISTRADOR
-- El administrador puede crear, modificar y eliminar datos.
------------------------------------------------------------
CREATE OR REPLACE PACKAGE actor_administrador_pkg AS

    PROCEDURE ad_ubicacion(
        p_ubicacion_id IN NUMBER,
        p_direccion    IN VARCHAR2,
        p_barrio       IN VARCHAR2,
        p_ciudad       IN VARCHAR2
    );

    PROCEDURE mod_ubicacion(
        p_ubicacion_id IN NUMBER,
        p_direccion    IN VARCHAR2,
        p_barrio       IN VARCHAR2,
        p_ciudad       IN VARCHAR2
    );

    PROCEDURE del_incidente(p_incidente_id IN NUMBER);
    PROCEDURE del_denuncia(p_denuncia_id IN NUMBER);

    PROCEDURE con_estadisticas;

END actor_administrador_pkg;
/
CREATE OR REPLACE PACKAGE BODY actor_administrador_pkg AS

    PROCEDURE ad_ubicacion(
        p_ubicacion_id IN NUMBER,
        p_direccion    IN VARCHAR2,
        p_barrio       IN VARCHAR2,
        p_ciudad       IN VARCHAR2
    ) IS
    BEGIN
        -- CodigoUbicacion generado, Localidad = p_ciudad, coordenadas NULL
        INSERT INTO Ubicacion (
            UbicacionID, CodigoUbicacion, Direccion,
            Barrio, Localidad, CoordenadaLat, CoordenadaLon
        )
        VALUES (
            p_ubicacion_id,
            'UBI-' || p_ubicacion_id,
            p_direccion,
            p_barrio,
            p_ciudad,
            NULL,
            NULL
        );
    END ad_ubicacion;


    PROCEDURE mod_ubicacion(
        p_ubicacion_id IN NUMBER,
        p_direccion    IN VARCHAR2,
        p_barrio       IN VARCHAR2,
        p_ciudad       IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Ubicacion
        SET Direccion = p_direccion,
            Barrio    = p_barrio,
            Localidad = p_ciudad
        WHERE UbicacionID = p_ubicacion_id;
    END mod_ubicacion;


    PROCEDURE del_incidente(p_incidente_id IN NUMBER) IS
    BEGIN
        DELETE FROM Incidente
        WHERE IncidenteID = p_incidente_id;
    END del_incidente;


    PROCEDURE del_denuncia(p_denuncia_id IN NUMBER) IS
    BEGIN
        DELETE FROM Denuncia
        WHERE DenunciaID = p_denuncia_id;
    END del_denuncia;


    PROCEDURE con_estadisticas IS
    BEGIN
        NULL;
    END con_estadisticas;

END actor_administrador_pkg;
/
