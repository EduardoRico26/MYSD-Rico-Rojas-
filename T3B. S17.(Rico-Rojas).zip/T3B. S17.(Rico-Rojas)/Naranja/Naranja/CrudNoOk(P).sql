
 --CRUDNoOK 


-- 1. CIUDADANO — ERROR: PK duplicada (ID 10 ya existe)

BEGIN
  PC_Ciudadano.ad_ciudadano(
      10,                  -- PK DUPLICADA
      '123456789',
      'Pedro',
      'López',
      '3001112233',
      'pedro@mail.com',
      'Calle falsa 123'
  );
END;
/



-- 2. AUTORIDAD — ERROR: 
BEGIN
  PC_Autoridad.ad_autoridad(
      11,
      'AUT-11',
      NULL,                -- Nombre no puede ser NULL
      'Policía',
      '3102223344',
      'autoridad@mail.com'
  );
END;
/



-- 3. DELITO — ERROR: TEXTO DEMASIADO LARGO para el campo CATEGORIA

BEGIN
  PC_Delito.ad_delito(
      2001,
      'DEL-2001',
      'Delito Falso',
      'Prueba con categoría demasiado larga',
      RPAD('X', 200, 'X'), -- ❌ Valor supera el tamaño permitido
      'Alta'
  );
END;
/




-- 4. UBICACIÓN — ERROR: Código duplicado 

BEGIN
  PC_Ubicacion.ad_ubicacion(
      11,
      'UBI-10',            --  Código ya existe 
      'Dirección X',
      'Barrio Y',
      'Suba'
  );
END;
/
-- 5. INCIDENTE — ERROR: DelitoID no existe (FK rota)

BEGIN
  PC_Incidente.ad_incidente(
      3001,
      'INC-3001',
      SYSDATE,
      'Descripción falsa',
      'Alta',
      'Abierto',
      9999,                --  Delito inexistente rompe FK
      10
  );
END;
/



-- 6. INCIDENTE — ERROR: Ubicación no existe (FK)

BEGIN
  PC_Incidente.ad_incidente(
      3002,
      'INC-3002',
      SYSDATE,
      'Prueba Ubicación inválida',
      'Media',
      'Abierto',
      2000,
      9999                 --  Ubicación inexistente
  );
END;
/


ROLLBACK;
