
--- CRUDOK


-- 1. CIUDADANO 
BEGIN
  PC_Ciudadano.ad_ciudadano(
      10,
      '900500300', 
      'Carlos',
      'Ramírez',
      '3208881111',
      'carlos.ramirez@mail.com',
      'Calle 80 #25-10'
  );
END;
/

BEGIN
    PC_Ciudadano.mod_ciudadano(
        10,
        '3219998888',
        'carlos.ramirez.actualizado@mail.com',
        'Avenida 30 #15-20'
    );
END;
/


BEGIN
  PC_Ciudadano.ad_ciudadano(
      11,
      '800222500',
      'Laura',
      'Mendoza',
      '3107441122',
      'laura.mendoza@mail.com',
      'Carrera 45 #120-55'
  );
END;
/

BEGIN
    PC_Ciudadano.del_ciudadano(11);
END;
/


-- 2. AUTORIDAD 
BEGIN
  PC_Autoridad.ad_autoridad(
      10,
      'AUT-10',
      'Unidad de Reacción Inmediata',
      'Policía',
      '3155002200',
      'uri@policia.gov.co'
  );
END;
/


-- 3. DELITO 
BEGIN
  PC_Delito.ad_delito(
      2000,
      'DEL-2000',
      'Extorsión',
      'Delito de extorsión a comerciante',
      'Económico',
      'Alta'
  );
END;
/


-- 4. UBICACION 
BEGIN
  PC_Ubicacion.ad_ubicacion(
      10,
      'UBI-10',
      'Av. 68 #30',
      'Barrio El Real',
      'Engativa'
  );
END;
/


-- 5. INCIDENTE (ID NUEVO: 3000)

BEGIN
  PC_Incidente.ad_incidente(
      3000,
      'INC-3000',
      SYSDATE,
      'Extorsión a comerciante en su negocio',
      'Alta',
      'Abierto',
      2000,     -- Delito recién creado
      10        -- Ubicación recién creada
  );
END;
/

COMMIT;



