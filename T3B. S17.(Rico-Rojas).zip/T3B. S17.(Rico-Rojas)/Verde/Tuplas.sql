/*============================================================
TUPLAS (restricciones con varios atributos de la misma tabla)
============================================================ */

-- 1) No permitir que un incidente de Severidad 'Baja' esté 'Cerrado'
ALTER TABLE Incidente
  ADD CONSTRAINT chk_incidente_estado_severidad
  CHECK (NOT (Severidad = 'Baja' AND Estado = 'Cerrado'));
-- Regla: Severidad 'Baja' no puede estar en Estado 'Cerrado'.


-- 2) No permitir que un incidente de Severidad 'Baja' esté 'En proceso'
ALTER TABLE Incidente
  ADD CONSTRAINT chk_incidente_severidad_estado2
  CHECK (NOT (Severidad = 'Baja' AND Estado = 'En proceso'));
-- Regla: Severidad 'Baja' no debería requerir un estado 'En proceso'.


-- 3) No permitir cerrar un incidente si DelitoID es NULL
ALTER TABLE Incidente
  ADD CONSTRAINT chk_incidente_cerrado_con_delito
  CHECK (NOT (Estado = 'Cerrado' AND DelitoID IS NULL));
-- Regla: No se puede cerrar un incidente sin tener un delito asociado.

--Eliminar 
ALTER TABLE Incidente DROP CONSTRAINT chk_incidente_estado_severidad;
ALTER TABLE Incidente DROP CONSTRAINT chk_incidente_severidad_estado2;
ALTER TABLE Incidente DROP CONSTRAINT chk_incidente_cerrado_con_delito;

