/*============================================================
XDISPARADORES (eliminar disparadores creados)
============================================================ */

-- Eliminar trigger que asigna FechaIncidente por defecto
DROP TRIGGER trg_incidente_fecha;

-- Eliminar trigger que asigna Estado por defecto
DROP TRIGGER trg_incidente_estado_default;

-- Eliminar trigger que valida FechaDenuncia >= FechaIncidente
DROP TRIGGER trg_denuncia_fecha_valida;

-- Fin XDISPARADORES
