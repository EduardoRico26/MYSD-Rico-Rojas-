/*============================================================
DISPARADORES_NoOK
============================================================ */

---------------------------------------------------------------
-- NoOK 1: FechaDenuncia < FechaIncidente
-- Debe FALLAR por el trigger trg_denuncia_fecha_valida
---------------------------------------------------------------

-- Crear incidente base con fecha 2025-11-10
INSERT INTO Incidente VALUES (
  980, 'I980', DATE '2025-11-10',
  'Incidente para prueba NoOK',
  'Media', 'Abierto',
  1, 1
);

-- Intentar crear denuncia ANTES del incidente → ERROR
INSERT INTO Denuncia VALUES (
  981, 'DN981',
  DATE '2025-11-01',     -- 9 días antes → debe fallar
  'Denuncia con fecha inválida',
  1,                     -- CiudadanoID existente
  1,                     -- AutoridadID existente
  980                    -- IncidenteID
);





