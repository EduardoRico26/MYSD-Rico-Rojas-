/*============================================================
TUPLAS_OK
============================================================ */

-- OK 1: Severidad 'Baja' con Estado 'Abierto' (válido)
INSERT INTO Incidente VALUES (
  900, 'I900', DATE '2025-11-01',
  'Caso leve abierto', 'Baja', 'Abierto',
  1, 1
);

-- OK 2: Severidad 'Media' con Estado 'En proceso' (válido)
INSERT INTO Incidente VALUES (
  901, 'I901', DATE '2025-11-05',
  'Lesiones leves en proceso', 'Media', 'En proceso',
  2, 2
);

-- OK 3: Incidente Cerrado con DelitoID válido (válido)
INSERT INTO Incidente VALUES (
  902, 'I902', DATE '2025-10-10',
  'Caso cerrado con delito', 'Alta', 'Cerrado',
  3, 3
);

COMMIT;

-- Verificar los registros insertados en TUPLAS_OK
SELECT IncidenteID, Severidad, Estado
FROM Incidente
WHERE IncidenteID IN (900, 901, 902)
ORDER BY IncidenteID;
