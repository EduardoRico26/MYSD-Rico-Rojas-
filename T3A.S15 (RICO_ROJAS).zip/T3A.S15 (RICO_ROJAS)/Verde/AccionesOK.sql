/*============================================================
ACCIONES_OK
============================================================ */

-- ============================================================
-- OK 1: ON DELETE SET NULL (Incidente → Ubicacion)
-- Si se borra la ubicación, los incidentes quedan con UbicacionID = NULL
-- ============================================================

-- Crear ubicación temporal
INSERT INTO Ubicacion VALUES (999, 'U999', 'Dirección temporal', 'BarrioX', 'LocalidadX', NULL, NULL);

-- Crear incidente que usa esa ubicación
INSERT INTO Incidente VALUES (
  950, 'I950', DATE '2025-11-01',
  'Incidente para probar SET NULL',
  'Media', 'Abierto',
  1, 999  -- UbicacionID que luego borraremos
);

-- Borrar la Ubicación → debe poner UbicacionID = NULL en el incidente
DELETE FROM Ubicacion WHERE UbicacionID = 999;

-- Verificar
SELECT IncidenteID, UbicacionID
FROM Incidente
WHERE IncidenteID = 950;



-- ============================================================
-- OK 2: ON DELETE CASCADE (Denuncia → Incidente)
-- Si se borra el incidente, se borran también sus denuncias
-- ============================================================

-- Crear nuevo incidente
INSERT INTO Incidente VALUES (
  960, 'I960', DATE '2025-10-10',
  'Incidente para probar CASCADE en Denuncia',
  'Alta', 'Abierto',
  1, 1
);

-- Crear denuncia asociada
INSERT INTO Denuncia VALUES (
  990, 'DN990', DATE '2025-10-11',
  'Denuncia ligada al incidente 960',
  1, 1, 960
);

-- Borrar incidente → debe borrar la denuncia relacionada
DELETE FROM Incidente WHERE IncidenteID = 960;

-- Verificar (no debe existir la denuncia 990)
SELECT *
FROM Denuncia
WHERE DenunciaID = 990;



-- ============================================================
-- OK 3: ON DELETE CASCADE (Actuacion → Incidente)
-- Si se borra el incidente, se borran también sus actuaciones
-- ============================================================

-- Crear incidente para probar
INSERT INTO Incidente VALUES (
  970, 'I970', DATE '2025-09-09',
  'Incidente para CASCADE en Actuacion',
  'Alta', 'En proceso',
  2, 2
);

-- Actuación asociada
INSERT INTO Actuacion VALUES (
  880, 'Prueba', DATE '2025-09-10',
  'Actuación ligada al incidente 970',
  1, 970
);

-- Borrar incidente → debe borrar actuación 880
DELETE FROM Incidente WHERE IncidenteID = 970;

-- Verificar (no debe existir la actuación 880)
SELECT *
FROM Actuacion
WHERE ActuacionID = 880;

COMMIT;
