------------------------------------------------------------------
-- DATOS BASE COMUNES PARA LAS DOS PRUEBAS
------------------------------------------------------------------

-- CORRER ANTES: 
-- 1) CREACIÓN DE TABLAS  
-- 2) PK, FK, CHECK  
-- 3) TABLAS PUENTE  
-- 4) PAQUETES + PACKAGE BODY

-- Delito genérico de hurto
INSERT INTO Delito (DelitoID, CodigoDelito, NombreDelito, Descripcion, Categoria, Gravedad)
VALUES (1, 'DLT-001', 'Hurto callejero', 'Robo de pertenencias en vía pública', 'Patrimonial', 'Media');

-- Ubicación genérica en el centro de la ciudad
INSERT INTO Ubicacion (UbicacionID, CodigoUbicacion, Direccion, Barrio, Localidad, CoordenadaLat, CoordenadaLon)
VALUES (10, 'UBI-010', 'Calle 15 #20-10', 'Centro', 'Bogotá', '4.6100', '-74.0820');

-- Autoridad que recibe denuncias
INSERT INTO Autoridad (AutoridadID, CodigoAutoridad, Nombre, TipoAutoridad, Telefono, Correo)
VALUES (1, 'AUT-001', 'CAI Centro', 'Policía Nacional', '3000000000', 'caicentro@policia.gov.co');

COMMIT;

------------------------------------------------------------------
-- PRIMERA PRUEBA DE ACEPTACIÓN
------------------------------------------------------------------
-- COMO: Ciudadano
-- QUIERO: Registrar un incidente de robo en la vía pública y radicar una denuncia
-- PARA PODER: Dejar constancia formal del hecho para que la autoridad pueda atender el caso.
--
-- HISTORIA:
-- Juan Pérez, ciudadano de 30 años, sufre el robo de su celular mientras camina por el centro
-- de la ciudad. Registra sus datos, reporta el incidente y radica la denuncia en el sistema.
------------------------------------------------------------------

-- PASO 1: Crear el ciudadano
BEGIN
    actor_ciudadano_pkg.ad_ciudadano(
        p_id_ciudadano => 101,
        p_documento    => '1002456789',
        p_nombres      => 'Juan',
        p_apellidos    => 'Pérez Gómez',
        p_telefono     => '3004558822',
        p_correo       => 'juan.perez@mail.com',
        p_direccion    => 'Calle 15 #20-10'
    );
END;
/

-- Verificar ciudadano
SELECT * FROM Ciudadano WHERE CiudadanoID = 101;

-- PASO 2: Registrar el incidente de robo
BEGIN
    actor_ciudadano_pkg.ad_incidente(
        p_incidente_id => 2001,
        p_codigo       => 'INC-001',
        p_fecha        => SYSDATE,
        p_descripcion  => 'Robo de celular en la vía pública cerca al CAI Centro.',
        p_severidad    => 'Alta',
        p_estado       => 'Abierto',
        p_ciudadano_id => 101,  
        p_ubicacion_id => 10    
    );
END;
/

-- Verificar incidente
SELECT * FROM Incidente       WHERE IncidenteID = 2001;
-- Verificar relación incidente-ciudadano (tabla puente)
SELECT * FROM Incidente_Ciudadano WHERE IncidenteID = 2001;

-- PASO 3: Radicar la denuncia asociada al incidente
BEGIN
    actor_ciudadano_pkg.ad_denuncia(
        p_denuncia_id  => 5001,
        p_fecha        => SYSDATE,
        p_mensaje      => 'Denuncio el robo de mi celular. Adjunto descripción detallada.',
        p_incidente_id => 2001
    );

    -- (Opcional) Consultar incidentes y denuncias del ciudadano
    actor_ciudadano_pkg.con_incidentes(p_id_ciudadano => 101);
    actor_ciudadano_pkg.con_denuncias(p_id_ciudadano  => 101);
END;
/

-- Verificar denuncia
SELECT * FROM Denuncia WHERE DenunciaID = 5001;

------------------------------------------------------------------
-- SEGUNDA PRUEBA DE ACEPTACIÓN
------------------------------------------------------------------
-- COMO: Operador y Administrador del sistema
-- QUIERO: Actualizar el estado del incidente, registrar una actuación y luego
--         cerrar el caso eliminando la denuncia cuando se resuelve
-- PARA PODER: Mantener el historial del caso y limpiar denuncias ya atendidas.
------------------------------------------------------------------

-- PASO 4 (Operador): Cambiar el estado del incidente a "En proceso"
BEGIN
    actor_operador_pkg.mod_estado_incidente(
        p_incidente_id => 2001,
        p_estado       => 'En proceso'
    );
END;
/

-- Verificar cambio de estado del incidente
SELECT IncidenteID, CodigoIncidente, Estado
FROM Incidente
WHERE IncidenteID = 2001;

-- PASO 5 (Operador): Registrar una actuación sobre el incidente
BEGIN
    actor_operador_pkg.ad_actuacion(
        p_actuacion_id => 3001,
        p_fecha        => SYSDATE,
        p_descripcion  => 'Se visitó el lugar, se entrevistó al ciudadano y se revisaron cámaras cercanas.',
        p_incidente_id => 2001
    );
END;
/

-- Verificar actuación registrada
SELECT * FROM Actuacion WHERE ActuacionID = 3001;

-- PASO 6 (Administrador): Corregir datos de la ubicación
BEGIN
    actor_administrador_pkg.mod_ubicacion(
        p_ubicacion_id => 10,
        p_direccion    => 'Carrera 8 #12-30',
        p_barrio       => 'Centro',
        p_ciudad       => 'Bogotá'   -- el package usa lo que necesite internamente
    );
END;
/

-- Verificar ubicación actualizada
SELECT * FROM Ubicacion WHERE UbicacionID = 10;

-- PASO 7 (Administrador): Eliminar la denuncia ya atendida
BEGIN
    actor_administrador_pkg.del_denuncia(
        p_denuncia_id => 5001
    );

    -- (Opcional) Consultar estadísticas generales
    actor_administrador_pkg.con_estadisticas;
END;
/

-- Verificar que la denuncia fue eliminada
SELECT * FROM Denuncia WHERE DenunciaID = 5001;

COMMIT;

------------------------------------------------------------------
-- ELIMINAR DATOS DE PRUEBA (SEGURIDAD PARA EJECUTAR OTRA VEZ)
------------------------------------------------------------------

-- 1) BORRAR DENUNCIAS (si existen)
DELETE FROM Denuncia WHERE DenunciaID = 5001;

-- 2) BORRAR ACTUACIONES
DELETE FROM Actuacion WHERE ActuacionID = 3001;

-- 3) BORRAR RELACIONES TABLAS PUENTE
DELETE FROM Incidente_Ciudadano WHERE IncidenteID = 2001;
DELETE FROM Incidente_Sospechoso WHERE IncidenteID = 2001;

-- 4) BORRAR INCIDENTES
DELETE FROM Incidente WHERE IncidenteID = 2001;

-- 5) BORRAR CIUDADANO DE PRUEBA
DELETE FROM Ciudadano WHERE CiudadanoID = 101;

-- 6) BORRAR DATOS BASE
DELETE FROM Delito WHERE DelitoID = 1;
DELETE FROM Ubicacion WHERE UbicacionID = 10;
DELETE FROM Autoridad WHERE AutoridadID = 1;

COMMIT
