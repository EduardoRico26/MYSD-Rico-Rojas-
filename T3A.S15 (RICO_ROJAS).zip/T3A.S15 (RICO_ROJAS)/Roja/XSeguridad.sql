/*============================================================
XSEGURIDAD 
============================================================*/

------------------------------------------------------------
-- 1. ELIMINACIÓN DE PAQUETES
------------------------------------------------------------

-- Ciudadano
DROP PACKAGE BODY actor_ciudadano_pkg;
DROP PACKAGE      actor_ciudadano_pkg;

-- Operador
DROP PACKAGE BODY actor_operador_pkg;
DROP PACKAGE      actor_operador_pkg;

-- Administrador
DROP PACKAGE BODY actor_administrador_pkg;
DROP PACKAGE      actor_administrador_pkg;


------------------------------------------------------------
-- 2. QUITAR ROLES A LOS USUARIOS 
------------------------------------------------------------
REVOKE C##ROL_CIUDADANO     FROM C##USUARIO_CIUDADANO;
REVOKE C##ROL_OPERADOR      FROM C##USUARIO_OPERADOR;
REVOKE C##ROL_ADMINISTRADOR FROM C##USUARIO_ADMIN;


------------------------------------------------------------
-- 3. ELIMINACIÓN DE PERMISOS DE LOS ROLES (OBJETO)
------------------------------------------------------------

-- Permisos del Ciudadano
REVOKE SELECT, INSERT, UPDATE ON Ciudadano FROM C##ROL_CIUDADANO;
REVOKE SELECT, INSERT        ON Incidente FROM C##ROL_CIUDADANO;
REVOKE SELECT, INSERT        ON Denuncia  FROM C##ROL_CIUDADANO;

-- Permisos del Operador
REVOKE SELECT, UPDATE ON Incidente FROM C##ROL_OPERADOR;
REVOKE SELECT, INSERT ON Actuacion FROM C##ROL_OPERADOR;



------------------------------------------------------------
-- 4. ELIMINACIÓN DE USUARIOS
------------------------------------------------------------
DROP USER C##USUARIO_CIUDADANO CASCADE;
DROP USER C##USUARIO_OPERADOR CASCADE;
DROP USER C##USUARIO_ADMIN CASCADE;


------------------------------------------------------------
-- 5. ELIMINACIÓN DE ROLES
------------------------------------------------------------
DROP ROLE C##ROL_CIUDADANO;
DROP ROLE C##ROL_OPERADOR;
DROP ROLE C##ROL_ADMINISTRADOR;
