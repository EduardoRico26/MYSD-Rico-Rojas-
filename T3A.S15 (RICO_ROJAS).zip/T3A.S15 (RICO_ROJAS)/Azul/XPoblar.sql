/*=============================================
XPOBLAR
============================================= */

DELETE FROM Incidente_Ciudadano;
DELETE FROM Incidente_Sospechoso;
DELETE FROM Evidencia;
DELETE FROM Denuncia;
DELETE FROM Actuacion;
DELETE FROM UnidadPolicial;
DELETE FROM Incidente;
DELETE FROM Autoridad;
DELETE FROM Ciudadano;
DELETE FROM Sospechoso;
DELETE FROM Delito;
DELETE FROM Ubicacion;

COMMIT;

/*============================================================
VERIFICAR POBLAR
============================================================ */
SELECT COUNT(*) AS c_incidentes FROM Incidente;
SELECT COUNT(*) AS c_ubicaciones FROM Ubicacion;
SELECT COUNT(*) AS c_delitos FROM Delito;
SELECT COUNT(*) AS c_ciudadanos FROM Ciudadano;
SELECT COUNT(*) AS c_sospechosos FROM Sospechoso;
SELECT COUNT(*) AS c_autoridades FROM Autoridad;
SELECT COUNT(*) AS c_unidades_policiales FROM UnidadPolicial;
SELECT COUNT(*) AS c_actuaciones FROM Actuacion;
SELECT COUNT(*) AS c_denuncias FROM Denuncia;
SELECT COUNT(*) AS c_evidencias FROM Evidencia;

-- Tablas puente
SELECT COUNT(*) AS c_incidente_ciudadano FROM Incidente_Ciudadano;
SELECT COUNT(*) AS c_incidente_sospechoso FROM Incidente_Sospechoso;
