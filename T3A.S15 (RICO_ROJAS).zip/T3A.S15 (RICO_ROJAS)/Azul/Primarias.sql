/*============================================================
PRIMARIAS 
============================================================ */

-- CIUDADANO
ALTER TABLE Ciudadano
  ADD CONSTRAINT pk_ciudadano PRIMARY KEY (CiudadanoID);

-- SOSPECHOSO
ALTER TABLE Sospechoso
  ADD CONSTRAINT pk_sospechoso PRIMARY KEY (SospechosoID);

-- DELITO
ALTER TABLE Delito
  ADD CONSTRAINT pk_delito PRIMARY KEY (DelitoID);

-- UBICACION
ALTER TABLE Ubicacion
  ADD CONSTRAINT pk_ubicacion PRIMARY KEY (UbicacionID);

-- AUTORIDAD
ALTER TABLE Autoridad
  ADD CONSTRAINT pk_autoridad PRIMARY KEY (AutoridadID);

-- UNIDAD POLICIAL
ALTER TABLE UnidadPolicial
  ADD CONSTRAINT pk_unidad_policial PRIMARY KEY (UnidadPolicialID);

-- INCIDENTE
ALTER TABLE Incidente
  ADD CONSTRAINT pk_incidente PRIMARY KEY (IncidenteID);

-- ACTUACION
ALTER TABLE Actuacion
  ADD CONSTRAINT pk_actuacion PRIMARY KEY (ActuacionID);

-- DENUNCIA
ALTER TABLE Denuncia
  ADD CONSTRAINT pk_denuncia PRIMARY KEY (DenunciaID);

-- EVIDENCIA
ALTER TABLE Evidencia
  ADD CONSTRAINT pk_evidencia PRIMARY KEY (EvidenciaID);

-- TABLAS * a * 
ALTER TABLE Incidente_Ciudadano
  ADD CONSTRAINT pk_incidente_ciudadano PRIMARY KEY (IncidenteID, CiudadanoID);

ALTER TABLE Incidente_Sospechoso
  ADD CONSTRAINT pk_incidente_sospechoso PRIMARY KEY (IncidenteID, SospechosoID);

   
   