/*============================================================
UNICAS
============================================================ */
   

-- CIUDADANO: Documento único
ALTER TABLE Ciudadano
  ADD CONSTRAINT uq_ciudadano_documento UNIQUE (Documento);

-- SOSPECHOSO: Documento único
ALTER TABLE Sospechoso
  ADD CONSTRAINT uq_sospechoso_documento UNIQUE (Documento);

-- DELITO: Código único
ALTER TABLE Delito
  ADD CONSTRAINT uq_delito_codigo UNIQUE (CodigoDelito);

-- UBICACION: Código único
ALTER TABLE Ubicacion
  ADD CONSTRAINT uq_ubicacion_codigo UNIQUE (CodigoUbicacion);

-- AUTORIDAD: Código único
ALTER TABLE Autoridad
  ADD CONSTRAINT uq_autoridad_codigo UNIQUE (CodigoAutoridad);

-- UNIDAD POLICIAL: Código único
ALTER TABLE UnidadPolicial
  ADD CONSTRAINT uq_unidadpolicial_codigo UNIQUE (CodigoUnidad);

-- INCIDENTE: Código único
ALTER TABLE Incidente
  ADD CONSTRAINT uq_incidente_codigo UNIQUE (CodigoIncidente);

-- DENUNCIA: Número de denuncia único
ALTER TABLE Denuncia
  ADD CONSTRAINT uq_denuncia_numero UNIQUE (NumeroDenuncia);


   