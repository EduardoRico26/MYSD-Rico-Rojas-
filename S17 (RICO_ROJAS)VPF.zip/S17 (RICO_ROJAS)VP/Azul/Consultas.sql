/*============================================================
CONSULTAS
============================================================ */

-- Gerencial 1: Incidentes por localidad en 2025
SELECT
  u.Localidad,
  COUNT(*) AS Total_Incidentes
FROM Incidente i
JOIN Ubicacion u ON u.UbicacionID = i.UbicacionID
LEFT JOIN Delito d ON d.DelitoID = i.DelitoID
WHERE i.FechaIncidente >= DATE '2025-01-01'
  AND i.FechaIncidente <  DATE '2025-12-31' + 1
  -- AND d.NombreDelito = 'Robo'   -- CAMBIAR LO DE "" POR EL TIPO DE DELITO A FILTRAR 
GROUP BY u.Localidad
ORDER BY Total_Incidentes DESC;




-- Gerencial 2: Porcentaje de cierre por tipo de delito en 2025
SELECT
  d.NombreDelito,
  COUNT(i.IncidenteID) AS Total_Incidentes,
  SUM(CASE WHEN i.Estado = 'Cerrado' THEN 1 ELSE 0 END) AS Cerrados,
  ROUND(
    (SUM(CASE WHEN i.Estado = 'Cerrado' THEN 1 ELSE 0 END) / COUNT(i.IncidenteID)) * 100,
    2
  ) AS Porcentaje_Cierre
FROM Incidente i
JOIN Delito d ON d.DelitoID = i.DelitoID
WHERE i.FechaIncidente >= DATE '2025-01-01'
  AND i.FechaIncidente <  DATE '2025-12-31' + 1
GROUP BY d.NombreDelito
ORDER BY Porcentaje_Cierre DESC;


-- Operativa: Incidentes por categoría y gravedad del delito
SELECT
  d.Categoria,
  d.Gravedad AS GravedadDelito,
  COUNT(i.IncidenteID) AS Total_Incidentes
FROM Incidente i
JOIN Delito d ON d.DelitoID = i.DelitoID
GROUP BY d.Categoria, d.Gravedad
ORDER BY d.Categoria, d.Gravedad;
