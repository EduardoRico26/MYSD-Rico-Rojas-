/*============================================================
ACCIONES (acciones de referencia con ON DELETE)
============================================================ */

-- 1) Incidente → Ubicacion: si se borra la ubicación, el incidente queda sin UbicacionID
ALTER TABLE Incidente
  DROP CONSTRAINT fk_incidente_ubicacion;

ALTER TABLE Incidente
  ADD CONSTRAINT fk_incidente_ubicacion
  FOREIGN KEY (UbicacionID)
  REFERENCES Ubicacion(UbicacionID)
  ON DELETE SET NULL;
  
-- Regla: si se borra la Ubicación, los Incidentes quedan con UbicacionID = NULL

-- 2) Denuncia → Incidente: si se borra el incidente, se borran sus denuncias
ALTER TABLE Denuncia
  DROP CONSTRAINT fk_denuncia_incidente;

ALTER TABLE Denuncia
  ADD CONSTRAINT fk_denuncia_incidente
  FOREIGN KEY (IncidenteID)
  REFERENCES Incidente(IncidenteID)
  ON DELETE CASCADE;
-- Regla: al eliminar un incidente, se eliminan también sus denuncias.


-- 3) Actuacion → Incidente: si se borra el incidente, se borran sus actuaciones
ALTER TABLE Actuacion
  DROP CONSTRAINT fk_actuacion_incidente;

ALTER TABLE Actuacion
  ADD CONSTRAINT fk_actuacion_incidente
  FOREIGN KEY (IncidenteID)
  REFERENCES Incidente(IncidenteID)
  ON DELETE CASCADE;
-- Regla: al eliminar un incidente, se eliminan también todas sus actuaciones.
