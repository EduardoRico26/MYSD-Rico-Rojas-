/*============================================================
TUPLAS_NoOK
============================================================ */

-- NoOK 1: Viola chk_incidente_estado_severidad
-- Severidad 'Baja' con Estado 'Cerrado' → PROHIBIDO
INSERT INTO Incidente VALUES (
  910, 'I910', DATE '2025-10-01',
  'Caso inválido: baja y cerrado',
  'Baja', 'Cerrado',
  1, 1
);


-- NoOK 2: Viola chk_incidente_severidad_estado2
-- Severidad 'Baja' con Estado 'En proceso' → PROHIBIDO
INSERT INTO Incidente VALUES (
  911, 'I911', DATE '2025-10-05',
  'Caso inválido: baja en proceso',
  'Baja', 'En proceso',
  1, 1
);


-- NoOK 3: Viola chk_incidente_cerrado_con_delito
-- Estado 'Cerrado' sin DelitoID → PROHIBIDO
INSERT INTO Incidente VALUES (
  912, 'I912', DATE '2025-09-20',
  'Caso inválido: cerrado sin delito',
  'Alta', 'Cerrado',
  NULL,   -- DelitoID nulo → prohibido
  1
);
