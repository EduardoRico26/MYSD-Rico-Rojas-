/*============================================================
SEGURIDAD OK — PRUEBA DE LOS PAQUETES
============================================================*/

/*============================================================
0) DATOS NECESARIOS PARA QUE NO DEN ERROR LOS INSERT
============================================================*/

-- Insertar ubicación mínima (la tabla NO tiene Ciudad)
INSERT INTO Ubicacion (UbicacionID, CodigoUbicacion, Direccion)
VALUES (10, 'UBI-10', 'Dirección inicial');

-- Insertar delito mínimo
INSERT INTO Delito (DelitoID, CodigoDelito, NombreDelito)
VALUES (1, 'D001', 'Robo');

COMMIT;


/*============================================================
1) CIUDADANO — Puede crear su propio perfil, incidentes y denuncias.
============================================================*/

-- a) Crear su propio perfil
BEGIN
    actor_ciudadano_pkg.ad_ciudadano(
        p_id_ciudadano => 101,
        p_documento    => '1002456789',
        p_nombres      => 'Juan Carlos',
        p_apellidos    => 'Rojas Pérez',
        p_telefono     => '3004558822',
        p_correo       => 'juan.rojas@mail.com',
        p_direccion    => 'Calle 15 #20-10'
    );
END;
/

-- b) Crear un incidente propio
BEGIN
    actor_ciudadano_pkg.ad_incidente(
        p_incidente_id => 2001,
        p_codigo       => 'INC-001',
        p_fecha        => SYSDATE,
        p_descripcion  => 'Robo en la vía pública',
        p_severidad    => 'Alta',
        p_estado       => 'Abierto',
        p_ciudadano_id => 101,
        p_ubicacion_id => 10
    );
END;
/

-- c) Crear una denuncia del ciudadano
BEGIN
    actor_ciudadano_pkg.ad_denuncia(
        p_denuncia_id  => 5001,
        p_fecha        => SYSDATE,
        p_mensaje      => 'Adjunto video de cámara de seguridad.',
        p_incidente_id => 2001
    );
END;
/

/*============================================================
2) OPERADOR — Puede actualizar estado y registrar actuaciones.
============================================================*/

-- a) Cambiar estado del incidente
BEGIN
    actor_operador_pkg.mod_estado_incidente(
        p_incidente_id => 2001,
        p_estado       => 'En proceso'
    );
END;
/

-- b) Registrar actuación
BEGIN
    actor_operador_pkg.ad_actuacion(
        p_actuacion_id => 3001,
        p_fecha        => SYSDATE,
        p_descripcion  => 'Se verificó el lugar y se confirmaron los hechos.',
        p_incidente_id => 2001
    );
END;
/

/*============================================================
3) ADMINISTRADOR — Puede modificar y eliminar denuncias.
============================================================*/

-- a) Modificar la ubicación
BEGIN
    actor_administrador_pkg.mod_ubicacion(
        p_ubicacion_id => 10,
        p_direccion    => 'Calle 9 #10-22',
        p_barrio       => 'San Victorino',
        p_ciudad       => 'Bogotá'   -- Ignorado en el body porque Ubicacion NO tiene Ciudad
    );
END;
/

-- b) Eliminar la denuncia
BEGIN
    actor_administrador_pkg.del_denuncia(
        p_denuncia_id => 5001
    );
END;
/

/*============================================================
VERIFICAR QUE TODO FUNCIONÓ 
============================================================*/

--------------------------------------------------------------
-- 1) Verificar ciudadano creado
--------------------------------------------------------------
SELECT * 
FROM Ciudadano 
WHERE CiudadanoID = 101;

--------------------------------------------------------------
-- 2) Verificar incidente creado y asociado al ciudadano
--------------------------------------------------------------
SELECT * 
FROM Incidente 
WHERE IncidenteID = 2001;

SELECT * 
FROM Incidente_Ciudadano 
WHERE IncidenteID = 2001;

--------------------------------------------------------------
-- 3) Verificar denuncia creada (si no ha sido eliminada)
--------------------------------------------------------------
SELECT * 
FROM Denuncia 
WHERE DenunciaID = 5001;

--------------------------------------------------------------
-- 4) Verificar cambio de estado hecho por el operador
--------------------------------------------------------------
SELECT Estado 
FROM Incidente 
WHERE IncidenteID = 2001;

--------------------------------------------------------------
-- 5) Verificar actuación creada por el operador
--------------------------------------------------------------
SELECT * 
FROM Actuacion 
WHERE ActuacionID = 3001;

--------------------------------------------------------------
-- 6) Verificar que la ubicación fue modificada por el admin
--------------------------------------------------------------
SELECT * 
FROM Ubicacion 
WHERE UbicacionID = 10;

--------------------------------------------------------------
-- 7) Verificar que la denuncia fue eliminada por el admin
--------------------------------------------------------------
SELECT * 
FROM Denuncia 
WHERE DenunciaID = 5001;

