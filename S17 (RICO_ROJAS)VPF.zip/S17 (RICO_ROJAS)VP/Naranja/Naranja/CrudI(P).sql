
--CRUDI – IMPLEMENTACIÓN DE LOS PAQUETES

-- Implementación: Ciudadano

CREATE OR REPLACE PACKAGE BODY PC_Ciudadano AS

    -- AGREGAR
    PROCEDURE ad_ciudadano(
        p_id_ciudadano IN NUMBER,
        p_documento    IN VARCHAR2,
        p_nombres      IN VARCHAR2,
        p_apellidos    IN VARCHAR2,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2,
        p_direccion    IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Ciudadano VALUES (
            p_id_ciudadano, p_documento, p_nombres, p_apellidos,
            p_telefono, p_correo, p_direccion
        );
    END;

    -- MODIFICAR
    PROCEDURE mod_ciudadano(
        p_id_ciudadano IN NUMBER,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2,
        p_direccion    IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Ciudadano
        SET Telefono = p_telefono,
            Correo = p_correo,
            Direccion = p_direccion
        WHERE CiudadanoID = p_id_ciudadano;
    END;

    -- ELIMINAR
    PROCEDURE del_ciudadano(
        p_id_ciudadano IN NUMBER
    ) IS
    BEGIN
        DELETE FROM Ciudadano
        WHERE CiudadanoID = p_id_ciudadano;
    END;

END PC_Ciudadano;
/
-- Implementación: Autoridad

CREATE OR REPLACE PACKAGE BODY PC_Autoridad AS

    -- AGREGAR
    PROCEDURE ad_autoridad(
        p_autoridad_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_nombre       IN VARCHAR2,
        p_tipo         IN VARCHAR2,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Autoridad VALUES (
            p_autoridad_id, p_codigo, p_nombre, p_tipo,
            p_telefono, p_correo
        );
    END;

    -- MODIFICAR
    PROCEDURE mod_autoridad(
        p_autoridad_id IN NUMBER,
        p_telefono     IN VARCHAR2,
        p_correo       IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Autoridad
        SET Telefono = p_telefono,
            Correo   = p_correo
        WHERE AutoridadID = p_autoridad_id;
    END;

    -- ELIMINAR
    PROCEDURE del_autoridad(
        p_autoridad_id IN NUMBER
    ) IS
    BEGIN
        DELETE FROM Autoridad
        WHERE AutoridadID = p_autoridad_id;
    END;

END PC_Autoridad;
/
-- Implementación: Delito

CREATE OR REPLACE PACKAGE BODY PC_Delito AS

    -- AGREGAR
    PROCEDURE ad_delito(
        p_delito_id  IN NUMBER,
        p_codigo     IN VARCHAR2,
        p_nombre     IN VARCHAR2,
        p_descripcion IN VARCHAR2,
        p_categoria  IN VARCHAR2,
        p_gravedad   IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Delito VALUES (
            p_delito_id, p_codigo, p_nombre,
            p_descripcion, p_categoria, p_gravedad
        );
    END;

    -- MODIFICAR
    PROCEDURE mod_delito(
        p_delito_id   IN NUMBER,
        p_descripcion IN VARCHAR2,
        p_categoria   IN VARCHAR2,
        p_gravedad    IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Delito
        SET Descripcion = p_descripcion,
            Categoria   = p_categoria,
            Gravedad    = p_gravedad
        WHERE DelitoID = p_delito_id;
    END;

    -- ELIMINAR
    PROCEDURE del_delito(
        p_delito_id IN NUMBER
    ) IS
    BEGIN
        DELETE FROM Delito
        WHERE DelitoID = p_delito_id;
    END;

END PC_Delito;
/
-- Implementación: Ubicacion

CREATE OR REPLACE PACKAGE BODY PC_Ubicacion AS

    -- AGREGAR
    PROCEDURE ad_ubicacion(
        p_ubicacion_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_direccion    IN VARCHAR2,
        p_barrio       IN VARCHAR2,
        p_localidad    IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Ubicacion (
            UbicacionID, CodigoUbicacion, Direccion, Barrio, Localidad
        )
        VALUES (
            p_ubicacion_id, p_codigo, p_direccion, p_barrio, p_localidad
        );
    END;

    -- MODIFICAR
    PROCEDURE mod_ubicacion(
        p_ubicacion_id IN NUMBER,
        p_direccion    IN VARCHAR2,
        p_barrio       IN VARCHAR2,
        p_localidad    IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Ubicacion
        SET Direccion = p_direccion,
            Barrio    = p_barrio,
            Localidad = p_localidad
        WHERE UbicacionID = p_ubicacion_id;
    END;

    -- ELIMINAR
    PROCEDURE del_ubicacion(
        p_ubicacion_id IN NUMBER
    ) IS
    BEGIN
        DELETE FROM Ubicacion
        WHERE UbicacionID = p_ubicacion_id;
    END;

END PC_Ubicacion;
/
-- Implementación: Incidente

CREATE OR REPLACE PACKAGE BODY PC_Incidente AS

    -- AGREGAR
    PROCEDURE ad_incidente(
        p_incidente_id IN NUMBER,
        p_codigo       IN VARCHAR2,
        p_fecha        IN DATE,
        p_descripcion  IN VARCHAR2,
        p_severidad    IN VARCHAR2,
        p_estado       IN VARCHAR2,
        p_delito_id    IN NUMBER,
        p_ubicacion_id IN NUMBER
    ) IS
    BEGIN
        INSERT INTO Incidente (
            IncidenteID, CodigoIncidente, FechaIncidente,
            Descripcion, Severidad, Estado, DelitoID, UbicacionID
        )
        VALUES (
            p_incidente_id, p_codigo, p_fecha,
            p_descripcion, p_severidad, p_estado,
            p_delito_id, p_ubicacion_id
        );
    END;

    -- MODIFICAR
    PROCEDURE mod_incidente(
        p_incidente_id IN NUMBER,
        p_descripcion  IN VARCHAR2,
        p_severidad    IN VARCHAR2,
        p_estado       IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Incidente
        SET Descripcion = p_descripcion,
            Severidad   = p_severidad,
            Estado      = p_estado
        WHERE IncidenteID = p_incidente_id;
    END;

    -- ELIMINAR
    PROCEDURE del_incidente(
        p_incidente_id IN NUMBER
    ) IS
    BEGIN
        DELETE FROM Incidente
        WHERE IncidenteID = p_incidente_id;
    END;

END PC_Incidente;


